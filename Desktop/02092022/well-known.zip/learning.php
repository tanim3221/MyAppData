<?php
error_reporting(0);
session_start();
require __DIR__ . "/inc/redirect.php";
require __DIR__ . '/inc/header.php';

$batch = $_SESSION['batch'];
$get_batch = $_GET['batch'];

if (isset($_GET['update_files_info']) && isset($_GET['id']) && isset($_SESSION['student_id']) || isset($_GET['del_files_admin']) && isset($_GET['id']) && isset($_SESSION['student_id'])) {
	$sql = "SELECT * FROM learning WHERE id='" . $_GET['id'] . "'";

	$stmt = $connPdo->prepare($sql);
	$up = $stmt->execute();
	$row_update = $stmt->fetch();
}
?>

<div class="container loogedin_info_edit_left_right">

	<?php if (isset($_GET['view_files_book'])) {
		$get_cat = $_GET['file_cat'];
		$get_course_code = $_GET['course_code'];
		$get_year = $_GET['recommanded_year'];
		if (($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev') && isset($_GET['all_files'])) {
			$sql = "SELECT DISTINCT(course_code), course_name FROM learning WHERE course_code != '' ORDER BY course_code ASC";
		} /*elseif (($loggedin['role']=='admin' || $loggedin['role']=='dev') && isset($_GET['all_files'])) {
	$sql = "SELECT * FROM learning WHERE hide='0' AND approve='1' ORDER BY id DESC";
} */ else if (isset($_GET['file_cat'])) {
			$sql = "SELECT * FROM learning WHERE hide='0' AND approve='1' AND cat like '%{$get_cat}%' ORDER BY id DESC";
		} else if (isset($_GET['course_code'])) {
			$sql = "SELECT * FROM learning WHERE hide='0' AND approve='1' AND course_code like '%{$get_course_code}%' ORDER BY id DESC";
		} else if (isset($_GET['recommanded_year'])) {
			$sql = "SELECT * FROM learning WHERE hide='0' AND approve='1' AND recommanded_year like '%{$get_year}%' ORDER BY id DESC";
		} else {
			$sql = "SELECT DISTINCT(course_code), course_name FROM learning WHERE course_code != '' ORDER BY course_code ASC";
			// $sql = "SELECT * FROM learning WHERE hide='0' AND approve='1' ORDER BY id DESC";
		}

		$stmt2 = $connPdo->prepare($sql);
		$stmt2->execute();
		$numRows2 = $stmt2->rowCount();
		if ($numRows2 > 0) { ?>
			<div class="row">
				<div class="col-md-12">
					<div class="form-group">
						<input type="text" class="form-control border" placeholder="  Filter book files..." id="sort_search">
					</div>
				</div>
				<?php if (!isset($_GET['all_files'])) { ?>
					<div class="col-md-2 all_files_btn">
						<a href="learning.php?view_files_book&all_files" class="btn btn-success btn-block">All Files</a>
					</div>
				<?php } ?>
			</div>
			<div class="card-columns learn_card_row">
				<div id="accordion">
					<?php
					foreach ($stmt2 as $row) {
						$fileCount = $filesData->getFilesByCodeCount($row['course_code']);
					?>
						<div class="card learn_card_class_ac">
							<div class="card-header">
								<a class="card-link" data-toggle="collapse" href="#collapse<?= $row['course_code'] ?>">
									<?= $row['course_name'] ?> - <?= $row['course_code'] ?> <span class="float-right"><?= $fileCount ?> File(s)</span>
								</a>
							</div>
							<div id="collapse<?= $row['course_code'] ?>" class="collapse" data-parent="#accordion">
								<div class="card-body">
									<div class="card-columns learn_card_row_main">
										<?php
										$filesByCode = $filesData->getFilesByCode($row['course_code']);
										foreach ($filesByCode as $row) {
											include __DIR__ . '/file_card.php';
										}
										?>
									</div>
								</div>
							</div>
						</div>
					<?php  } ?>
				</div>
			<?php
		} else {
			echo "<div class='alert alert-danger'>No files found</div>";
		}
	} elseif (isset($_GET['book_files_up'])) { ?>
			<div class="row">
				<div class="col-md-6">
					<div class="card" style="border: none;">
						<div class="card-header "><i class="bullet-info fas fa-file mr-2 text-default"></i>Update file details of <b> <?= str_replace('_', ' ', str_replace("-", " ", $_GET['title'])) ?></b></div>
						<div class="card-body">
							<div class="row">
								<form id="updateFileForm">
									<div class="row">
										<div class="col-md-12">
											<div class="form-group">
												<label>File Name </label>
												<input class="form-control" type="text" value="<?php echo str_replace('-', ' ', $row_update['title']); ?>" name="title">
											</div>
										</div>
										<input class="form-control" type="hidden" name="update_add_files_info" value="true">
										<input class="form-control" type="hidden" name="id" value="<?= $row_update['id'] ?>">
										<input class="form-control" type="hidden" name="batch" value="<?= $row_update['batch'] ?>">
										<input class="form-control" type="hidden" name="student_id" value="<?= $row_update['student_id'] ?>">

										<div class="col-md-6">
											<div class="form-group">
												<label>Course Name</label>
												<select class="selectpicker form-control" data-container="body" data-live-search="true" data-hide-disabled="true" id="files_course_select" name="course_code">
													<option value="">Choose Course Name</option>
													<?php
													$sql = "SELECT * FROM course_list ORDER BY course_code";
													$stmt2 = $connPdo->prepare($sql);
													$stmt2->execute();
													foreach ($stmt2 as $row) {
													?>
														<option value="<?php echo $row['course_code']; ?>**<?php echo $row['course_name']; ?>" <?php echo $row['course_code'] == $row_update['course_code'] ? ' selected="selected"' : ''; ?>><?php echo $row['course_name']; ?> (<?php echo $row['course_code']; ?>)</option>
													<?php } ?>
													<!--<option value="add_new">Add New</option> -->
												</select>
											</div>
										</div>

										<div class="col-md-6" id="old_cat">
											<div class="form-group">
												<label>Files Category</label>
												<input class="form-control" type="text" value="<?php echo str_replace('-', ' ', $row_update['cat']); ?>" name="cat" required>

												<?php /*<select class="selectpicker form-control" data-container="body" data-live-search="true" data-hide-disabled="true" id="files_cat_select" name="cat">
											<option value="">Choose file category</option> 
											<?php
												$sql = "SELECT DISTINCT(cat) FROM learning WHERE cat != '' ORDER BY cat";
												$result = $conn->query($sql);
												while($row = $result->fetch_assoc()) { ?>
												<option value="<?php echo $row ['cat'];?>"<?php echo $row['cat'] == $row_update['cat'] ? ' selected="selected"' : '';?>><?php echo str_replace('-', ' ',$row ['cat']);?></option>
												<?php }?>
												<!--<option value="add_new">Add New</option> -->
											</select> */ ?>
											</div>
										</div>

										<div class="col-md-6" id="new_cat" style="display:none;">
											<div class="form-group">
												<label>Add New Category </label>
												<input class="form-control" id="new_cat_input" type="text">
											</div>
										</div>
										<div class="col-md-6" id="old_year">
											<div class="form-group">
												<label>Recommanded Year</label>
												<input class="form-control" type="text" value="<?php echo str_replace('-', ' ', $row_update['recommanded_year']); ?>" name="recommanded_year" required>
												<?php /* <select class="selectpicker form-control" data-container="body" data-live-search="true" data-hide-disabled="true" id="files_year_select" name="recommanded_year">
										<option value="">Recommanded Academic Year</option> 
										<?php
											$sql = "SELECT DISTINCT(recommanded_year) FROM learning WHERE recommanded_year != '' ORDER BY recommanded_year";
											$result = $conn->query($sql);
											while($row = $result->fetch_assoc()) { ?>
											<option value="<?php echo $row ['recommanded_year'];?>"<?php echo $row['recommanded_year'] == $row_update['recommanded_year'] ? ' selected="selected"' : '';?>><?php echo str_replace('-', ' ',$row ['recommanded_year']);?></option>
											<?php }?>
											<!--<option value="add_new">Add New</option> -->
										</select>*/ ?>
											</div>
										</div>
										<div class="col-md-6" id="new_year" style="display:none;">
											<div class="form-group">
												<label>Add New Year Semester </label>
												<input class="form-control" type="text" id="new_year_input">
											</div>
										</div>

										<?php if ($row_update['link'] == '1') { ?>
											<div class="col-md-12" id="file_link_upload">
												<div class="form-group">
													<label>File link</label>
													<textarea rows="6" class="form-control" type="url" id="file_link_upload_input" name="refer_link"><?php echo $row_update['refer_link']; ?></textarea>
												</div>
											</div>
										<?php } ?>
										<div class="col-md-6">
											<div class="form-group">
												<label>Approve or not</label>
												<select class="form-control" id="approve" name="approve">
													<option value="0" <?php echo $row_update['approve'] == '0' ? ' selected="selected"' : ''; ?>>Not Approve</option>
													<option value="1" <?php echo $row_update['approve'] == '1' ? ' selected="selected"' : ''; ?>>Approve </option>
												</select>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>Pinned Option </label>
												<select class="form-control" id="pinned" name="pinned">
													<option value="0" <?php echo $row_update['pinned'] == '0' ? ' selected="selected"' : ''; ?>> Not Pinned </option>
													<option value="1" <?php echo $row_update['pinned'] == '1' ? ' selected="selected"' : ''; ?>> Pinned</option>
												</select>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>Showing Option</label>
												<select class="form-control" id="hide" name="hide">
													<option value="0" <?php echo $row_update['hide'] == '0' ? ' selected="selected"' : ''; ?>>Public</option>
													<option value="1" <?php echo $row_update['hide'] == '1' ? ' selected="selected"' : ''; ?>>Private </option>
												</select>
											</div>
										</div>

										<div class="col-md-12">
											<div class="form-group">
												<button id="updateFileBtn" class="border-0 btn-block block-main-btn btn btn-success">Update </button>
											</div>
										</div>
									</div>
								</form>

							</div>
						</div>
					</div>
				</div>
				<div class="col-md-6 edit_side_file">
					<?php
					$get_cat = $_GET['file_cat'];
					$get_year = $_GET['recommanded_year'];
					$sql = "SELECT * FROM learning ORDER BY id DESC";
					$stmt2 = $connPdo->prepare($sql);
					$stmt2->execute();
					$numRows2 = $stmt2->rowCount();
					if ($numRows2 > 0) { ?>
						<div class="card-columns learn_card_row">
							<?php
							foreach ($stmt2 as $row) {
								include 'file_card.php';
							}
							?>
						</div>

					<?php } ?>

				</div>
			</div>

		<?php } ?>

			</div>
</div>
<?php require 'inc/footer.php'; ?>