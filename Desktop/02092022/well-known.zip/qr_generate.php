<?php
session_start();
error_reporting(0);
require __DIR__. '/controller/conn.php';
require __DIR__. '/controller/data.php';
require __DIR__. '/controller/others.php';
require __DIR__.'/phpqrcode/qrlib.php';
$conn = $pdo->mysqli();
$data = new Data();
$others = new Others();
$batch = $_SESSION['batch'];
$get_batch = $_GET['batch'];

if (isset($_SESSION['student_id'])) {
	$loggedin = $data->batchData($batch, $_SESSION['student_id'], 'student_id');
	$loggedinInfoInsert = array(
		'name' => $loggedin['name'],
		'batch' => $loggedin['batch'],
		'student_id' => $loggedin['student_id']
	);
}

if (isset($_GET['id']) && isset($_GET['students']) && isset($_GET['batch'])) {
	$row = $data->batchData($get_batch, $_GET['id'], 'id');

	$details_activity = 'View details information of <b>' . $row['name'] . ' (' . $row['batch'] . ')</b>';
	$insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
	$student_id = $row['student_id'];
	$hall_chk = $others->getHallName($student_id);
	if ($hall_chk=='0') {
		$hall = $row['hall'];
		$hall_name = (!empty($hall)) ? str_replace('_', ' ', $row['hall']) : 'Hall not yet specified';
	} else {
		$hall_name = $hall_chk;
	}

	$fb_id = $row['fb_id'];
	$facebook_url = $others->get_facebook_url($fb_id);

	# QR Code for Indvidual Profile

	// $text= "BEGIN:VCARD VERSION:3.0";
	// $text .= "N:".$row['name'];
	// $text .= "FN:".$row['name'];
	// $text .= "ORG:".$hall_name; 
	// $text .= "TITLE:";
	// $text .= "ADR:;;;;;;".$row['address'];
	// $text .= "TEL; WORK; VOICE:".$row['phone'];
	$text = $row['phone'];
	// $text .= "EMAIL; WORK; INTERNET:".$row['email'];
	// $text .= "URL:";
	// $text .= "END:VCARD";
	$path = 'phpqrcode/qr_code'; 
	$qr_file = $path.uniqid().".png"; 
	$ecc = 'L'; 
	$pixel_Size = 3; 
	$frame_Size = 3; 
	QRcode::png($text, $qr_file, $ecc, $pixel_Size, $frame_size); 
	
	# QR Code for Indvidual Profile
?>

	<div class="row inside_spin">
		<div class="spinner_log">
			<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
		</div>
		<div class="col-md-3 image_pro">

			<?php
			$img = $row['photo'];
			if (empty($img)) { ?>
				<img src='ais-assets/icon/demo.png'>
			<?php } else { ?>
				<img src='image/<?= $row['photo'] ?>'>
			<?php } ?>
			<div class="media contact-info mt-3">
				<span class="contact-info__icon view social">
					<a class="mr-2" target='_blank' href="https://facebook.com/<?= $facebook_url ?>"><i class="fab fa-facebook-square"></i></a>
					<a href="https://m.me/<?= $facebook_url ?>"><i class="fab fa-facebook-messenger"></i></a>
				</span>
			</div>
			<!-- <div class="qr_code">
                <center><img id='qr_code_img' style='width: 115px!important;height: 115px!important;border-radius: 0!important;padding: 7px;border: 1px solid;margin: 15px;' src='<?=$qr_file?>' alt='Scan to get mobile number'></center>
            </div> -->
			<?php if ($row['showing'] == '1') { ?>
				<span href="#" class="btn btn-success btn-sm lock_status"><i class="fas fa-lock-open"></i></span>
			<?php } else {	?>
				<span href="#" class="btn btn-danger btn-sm lock_status"><i class="fas fa-lock"></i></span>
			<?php } ?>
		</div>


		<div class="col-md-9">
			<h4 class="text-capitalize"><b><?= ucwords(strtolower($row['name'])) ?></b><br><small><?= $row['name_bangla'] ?></small></h4>
			<i class="fas fa-id-card mr-2"></i><?= $row['student_id'] ?>

			<span class="batch_session">
				<span class="batch text-white bg-success mr-1">
					<?= $row['batch'] ?>
				</span>
				<span class="session text-white bg-primary">
					<?= $row['session'] ?>
				</span>
			</span>
			<hr>
			<?php
			$birthday = $row['birth'];
			if (!empty($birthday)) {
				$date_name = date('l', strtotime($birthday));
				$month = date('F', strtotime($birthday));
				$date = date('d', strtotime($birthday));
				$year = date('Y', strtotime($birthday));
			?>

				<div class="media contact-info">
					<span class="contact-info__icon view"><i class="fas fa-birthday-cake"></i></span>
					<div class="media-body view text-capitalize">
						<p><?php echo "" . $date_name . ", " . $month . " " . $date . ", " . $year . ""; ?> </p>

					</div>
				</div>
			<?php } ?>
			<div class="media contact-info">
				<span class="contact-info__icon view blood"><i class="fas fa-tint"></i></span>
				<div class="media-body view text-capitalize">
					<p><?= $row['blood'] ?> </p>
				</div>
			</div>

			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-phone"></i></span>
				<div class="media-body view text-capitalize">
					<p><a href="tel:<?= $row['phone'] ?>"> <?= $row['phone'] ?> </a> </p>
				</div>
			</div>
			<?php
			$email_id = $row['email'];
			if (!empty($email_id)) { ?>
				<div class="media contact-info">
					<span class="contact-info__icon view"><i class="fas fa-envelope"></i></span>
					<div class="media-body view text-lowercase">
						<p><a href="mailto:<?= $row['email'] ?>"> <?= ucwords(strtolower($row['email'])) ?> </a> </p>
					</div>
				</div>
			<?php } ?>

			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-hotel"></i></span>
				<div class="media-body view">
					<p><?= $hall_name ?></p>
				</div>
			</div>
			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-map-marker-alt"></i></span>
				<div class="media-body view text-capitalize">
					<p><?= ucwords(strtolower($row['address'])) ?><br><?= $row['address_bangla'] ?></p>
				</div>
			</div>

			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-city"></i></span>
				<div class="media-body view text-capitalize">
					<p><?= ucwords(strtolower($row['district'])) ?></p>
				</div>
			</div>
		</div>
	</div>

<?php } else if (isset($_GET['id']) && isset($_GET['teachers'])) {
	$row = $data->batchData('teacher', $_GET['id'], 'id');
	$details_activity = 'View details teacher information of <b>' . $row['name'] . ' (' . $row['designation'] . ')</b>';
	$insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
	$fb_id = $row['fb_id'];
	$facebook_url = $others->get_facebook_url($fb_id);
?>

	<div class="row inside_spin">
		<div class="spinner_log">
			<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
		</div>
		<div class="col-md-3 image_pro">
			<?php
			$img = $row['photo'];
			if (empty($img)) { ?>
				<img src='ais-assets/icon/demo.png'>
			<?php } else { ?>
				<img src='image/<?= $row['photo'] ?>'>
			<?php } ?>
			<div class="media contact-info mt-3">
				<span class="contact-info__icon view social">
					<a class="mr-2" target='_blank' href="https://facebook.com/<?= $facebook_url ?>"><i class="fab fa-facebook-square"></i></a>
					<a href="https://m.me/<?= $facebook_url ?>"><i class="fab fa-facebook-messenger"></i></a>
				</span>
			</div>
		</div>

		<div class="col-md-9">
			<h4 class="text-capitalize"><b><?= $row['name'] ?></b></h4>
			<i class="fas fa-university mr-2"></i><?= $row['designation'] ?>
			<hr>
			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-phone"></i></span>
				<div class="media-body view text-capitalize">
					<p><a href="tel:<?= $row['phone'] ?>"> <?= $row['phone'] ?> </a> </p>
				</div>
			</div>

			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-envelope"></i></span>
				<div class="media-body view text-lowercase">
					<p><a href="mailto:<?= $row['email'] ?>"> <?= $row['email'] ?> </a> </p>
				</div>
			</div>

			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-user-graduate"></i></span>
				<div class="media-body view text-capitalize">
					<p><?= $row['edu'] ?></p>
				</div>
			</div>
			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-map-marker-alt"></i></span>
				<div class="media-body view text-capitalize">
					<p><?= ucwords(strtolower($row['per_addr'])) ?></p>
				</div>
			</div>
		</div>
	</div>

<?php } else if (isset($_GET['id']) && isset($_GET['office_stuff'])) {
	$row = $data->batchData('office_stuff', $_GET['id'], 'id');
	$details_activity = 'View details Office Stuff information of <b>' . $row['name'] . ' (' . $row['designation'] . ')</b>';
	$insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
	$fb_id = $row['fb_id'];
	$facebook_url = $others->get_facebook_url($fb_id);
?>

	<div class="row inside_spin">
		<div class="spinner_log">
			<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
		</div>
		<div class="col-md-3 image_pro">
			<?php
			$img = $row['photo'];
			if (empty($img)) { ?>
				<img src='ais-assets/icon/demo.png'>
			<?php } else { ?>
				<img src='image/<?= $row['photo'] ?>'>
			<?php } ?>
			<div class="media contact-info mt-3">
				<span class="contact-info__icon view social">
					<a class="mr-2" target='_blank' href="https://facebook.com/<?= $facebook_url ?>"><i class="fab fa-facebook-square"></i></a>
					<a href="https://m.me/<?= $facebook_url ?>"><i class="fab fa-facebook-messenger"></i></a>
				</span>
			</div>
		</div>

		<div class="col-md-9">
			<h4 class="text-capitalize"><b><?= $row['name'] ?></b></h4>
			<i class="fas fa-university mr-2"></i><?= $row['designation'] ?>
			<hr>
			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-phone"></i></span>
				<div class="media-body view text-capitalize">
					<p><a href="tel:<?= $row['phone'] ?>"> <?= $row['phone'] ?> </a> </p>
				</div>
			</div>

			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-envelope"></i></span>
				<div class="media-body view text-lowercase">
					<p><a href="mailto:<?= $row['email'] ?>"> <?= $row['email'] ?> </a> </p>
				</div>
			</div>
			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-map-marker-alt"></i></span>
				<div class="media-body view text-capitalize">
					<p><?= ucwords(strtolower($row['per_addr'])) ?></p>
				</div>
			</div>
		</div>
	</div>

<?php } elseif (isset($_GET['login_info_batch_wise']) && isset($_GET['batch'])) {

	$details_activity = 'Login information view of batch <b>(' . $_GET['batch'] . ')</b>';
	$insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
?>
	<table id='ais_family_web' class='table usersinfo ais_family_login'>
		<thead>
			<tr>
				<th>#</th>
				<th>ID</th>
				<th>Name</th>
				<th>Batch</th>
				<th>Refer Website</th>
				<th>Device Type</th>
				<th>IP Address</th>
				<th>Location</th>
				<th>Capital</th>
				<th>Country</th>
				<th>ISP</th>
				<th>Time</th>
				<th>Details</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php
			function gen()
			{
				for ($i = 1; $i < 1000; $i++) {
					//$rand = str_pad(dechex(rand(0x000000, 0xFFFFFF)), 6, 0, STR_PAD_LEFT);
					//$rand = '#' . dechex(rand(0,10000000));
					$rand = '#' . substr(str_shuffle('0123456789ABCDEF'), 0, 6);
					echo "'" . $rand . "',";
				}
			}

			function gen_fixed()
			{
				for ($i = 1; $i < 1000; $i++) {
					echo "'#fff',";
				}
			}
			$now = date("d-m-Y");
			if (isset($_GET['actual_view'])) {
				$sql = "SELECT * , {$get_batch}.name FROM login LEFT JOIN {$get_batch} ON login.student_id = {$get_batch}.student_id WHERE login.batch = '" . $get_batch . "' GROUP BY login.student_id ORDER by RIGHT(login.student_id,3) ASC";
			} else if (isset($_GET['today_view'])) {
				$sql = "SELECT * , {$get_batch}.name FROM login LEFT JOIN {$get_batch} ON login.student_id = {$get_batch}.student_id WHERE login.batch = '" . $get_batch . "' AND login.time like '%{$now}%' GROUP BY login.student_id ORDER by RIGHT(login.student_id,3) ASC";
			} else {
				$sql = "SELECT login.id, login.student_id, login.http, login.batch,login.device,login.region,login.country,login.country_flag,login.capital,login.isp, login.details, login.ip, login.time, login.action, {$get_batch}.name FROM login INNER JOIN  {$get_batch} ON login.student_id = {$get_batch}.student_id WHERE login.batch = '" . $get_batch . "' ORDER by login.id DESC";
				//$sql = "SELECT * FROM login WHERE batch = '".$get_batch."' ORDER by id DESC";
			}

			$result = mysqli_query($conn, $sql);
			$count = 1;
			while ($row = mysqli_fetch_assoc($result)) { ?>

				<tr>
					<td data-label='#'><?= $count ?></td>
					<td data-label='ID' class="usersid text-bold"><?= $row['student_id'] ?></td>
					<td data-label='Name'><?= $row['name'] ?></td>
					<td data-label='Batch'><?= $row['batch'] ?></td>
					<td data-label='Refer URL'><?= $row['http'] ?></td>
					<td data-label='Device'><?= $row['device'] ?></td>
					<td data-label='IP'><?= $row['ip'] ?></td>
					<td data-label='Location'><?= $row['region'] ?>, <?= $row['country'] ?> <img style="width:20px; height:15px" class="rounded" src="<?= $row['country_flag'] ?>"></td>
					<td data-label='Capital'><?= $row['capital'] ?> </td>
					<td data-label='Country'><?= $row['country'] ?> </td>
					<td data-label='ISP'><?= $row['isp'] ?></td>
					<td data-label='Time'><?= $row['time'] ?></td>
					<td><?= $row['details'] ?></td>
					<td data-label='Action'><?= $row['action'] ?></td>
				</tr>

			<?php $count = $count + 1;
			} 
mysqli_close($conn);
?>
		</tbody>
	</table>

	<script>
		$(function() {
			var tableRows = $(".usersinfo tbody tr"); //find all the rows
			var bgColors = [<?= gen_fixed(); ?>];
			var colors = [<?= gen(); ?>];
			var rowValues = {};
			tableRows.each(function() {
				var rowValue = $(this).find(".usersid").html();
				if (!rowValues[rowValue]) {
					var rowComposite = new Object();
					rowComposite.count = 1;
					rowComposite.row = this;
					rowComposite.color = colors.shift();
					rowComposite.bgColor = bgColors.shift();
					rowValues[rowValue] = rowComposite;
				} else {
					var rowComposite = rowValues[rowValue];
					rowComposite.count++;
					$(this).css('color', rowComposite.color);
					$(this).css('backgroundColor', rowComposite.bgColor);
					$(rowComposite.row).css('color', rowComposite.color);
					$(rowComposite.row).css('backgroundColor', rowComposite.bgColor);
				}
			});
		});
	</script>
	<?php } elseif (isset($_GET['admin_info_show']) && isset($_GET['batch'])) {
	if (isset($_GET['report_info'])) { ?>
		<h4><b>Admin info of your Batch</b></h4>
	<?php } else { ?>
		<h4><b>Admin info of <?= $get_batch ?> Batch</b></h4>
	<?php }  ?>

	<?php
	$sql = "SELECT * FROM {$get_batch} WHERE (role='admin' OR role='dev') ORDER BY RIGHT(student_id,5) ASC";
	$result = mysqli_query($conn, $sql);
	while ($row = mysqli_fetch_assoc($result)) { 
		$fb_id = $row['fb_id'];
		$facebook_url = $others->get_facebook_url($fb_id);
		?>
		<div class="card-body row admin_info_row">
			<div class="col-md-2">
				<?php $img = $row['photo'];
				if (empty($img)) { ?>
					<div class='avatar'><a class='fb_id' target='_blank' href='https://www.facebook.com/<?= $facebook_url ?>'><img src='ais-assets/icon/demo.png'><img class='img-top' src='ais-assets/icon/fb.png'></a></div>
				<?php } else { ?>
					<div class='avatar'><a class='fb_id' target='_blank' href='https://www.facebook.com/<?= $facebook_url ?>'><img src='image/<?= $row['photo'] ?>'><img class='img-top' src='ais-assets/icon/fb.png'></a></div>
				<?php } ?>
			</div>
			<div class="col-md-10">
				<h5 class="card-title"><b><?= $row['name_bangla'] ?></b></h5>
				<p class="card-text">
					<?php if (isset($_GET['report_info'])) { ?>
						<i class="fas fa-id-card mr-2"></i><?= $row['student_id'] ?>
						<br>
					<?php } ?>
					<i class="fas fa-envelope mr-2"></i><a href='mailto:<?= $row['email'] ?>'><?= $row['email'] ?></a>
					<br>
					<i class="fas fa-phone-square-alt mr-2"></i><a href='tel:<?= $row['phone'] ?>'><?= $row['phone'] ?></a>
				</p>
			</div>
		</div>
	<?php } 
mysqli_close($conn);
?>
	<?php } else if (isset($_GET['mybatchlogin']) && isset($_GET['logininfoid'])) {
		
		$login_id = $_GET['logininfoid'];
		$sql = "SELECT {$batch}.name, {$batch}.photo, login.student_id,login.region, login.city, login.capital, login.country, login.isp, login.latitude, login.longitude, login.batch, login.details, login.device, login.time, login.http, login.action, login.ip FROM login  INNER JOIN
		{$batch} ON login.student_id = {$batch}.student_id WHERE login.batch ='{$batch}' AND login.id='{$login_id}' ORDER BY login.id DESC";
		$result = $conn->query($sql);
		$row = $result->fetch_assoc();?>
		
		<table class="table">
			<tr>
				<td align="left"><b>Name: </b><?=$row['name']?></td>
				<td align="center"><b>Student ID: </b><?=$row['student_id']?></td>
				<td align="center"><b>Batch: </b><?=$row['batch']?></td> 
				<td align="right"><b>Time: </b><?=$row['time']?></td>
			</tr>
			<tr>
				<td align="left"><b>Region: </b><?=$row['region']?></td>
				<td align="left"><b>City: </b><?=$row['city']?></td>
				<td align="left"><b>Capital: </b><?=$row['capital']?></td> 
				<td align="left"><b>Country: </b><?=$row['country']?></td>
			</tr>
			<tr>
				<td align="left"><b>Device: </b><?=$row['device']?></td>
				<td align="center"><b>IP: </b><?=$row['ip']?></td> 
				<td align="center"><b>ISP: </b><?=$row['isp']?></td> 
				<td align="center"><b>URL: </b><?=$row['http']?></td> 
			</tr>
			<tr>
				<td align="center" colspan="4"><a target="_blank" href="https://www.google.com/maps/place/<?=$row['latitude']?>+<?=$row['longitude']?>">Google Map Location</a></td>
			</tr>
			<tr>
				<td align="center" colspan="4"><?=$row['details']?></td>
			</tr>
		</table>

<?php } else if (isset($_GET['search_history_home'])) {
	$logId = $loggedin['student_id'];
	// $serSql = "SELECT * FROM search WHERE student_id=" . $logId . " AND date IN (SELECT MAX(date) FROM search GROUP BY keywords, key_cat)";
	$serSql = "SELECT * FROM search where student_id=" . $logId . " AND id in (SELECT max(id) FROM search GROUP BY keywords, key_cat) order by id desc";
	
	$resSql = mysqli_query($conn, $serSql);
	//$row = mysqli_fetch_array($result);
	while ($row_search = mysqli_fetch_assoc($resSql)) { ?>
	<div class="mt-2">
		<a href="home.php?query=<?=$row_search['keywords']?>&category=<?=$row_search['key_cat']?>#search_results">
			<?=$row_search['keywords'].' - '.$row_search['key_cat']?>
		</a>
	</div>
		<!-- echo $row_search['keywords'].' - '.$row_search['key_cat'].'<hr>'; -->
<?php } 
mysqli_close($conn);
?>
<?php  } else if (isset($_GET['activitty_info_date_wise'])) {

	$sql1 = "SELECT * FROM activity_log WHERE student_id=" . $loggedin['student_id'] . " GROUP BY DATE_FORMAT(date, '%Y-%m-%d') ORDER BY date DESC ";
	$result1 = mysqli_query($conn, $sql1);
	//$row = mysqli_fetch_array($result);
	while ($row_aa = mysqli_fetch_assoc($result1)) {

	?>

		<table class="view_activity_log">
			<div class="log_title font-weight-bold">
				<?= date('d F, Y', strtotime($row_aa['date'])) ?>
			</div>
			<div class="deatsil_view_log">
				<?php
				$day = date('d', strtotime($row_aa['date']));
				$month = date('m', strtotime($row_aa['date']));
				$year = date('Y', strtotime($row_aa['date']));
				$sql = "SELECT * FROM activity_log WHERE DAY(date)=" . $day . " AND MONTH(date)=" . $month . " AND YEAR(date)=" . $year . " AND student_id=" . $loggedin['student_id'] . " ORDER BY date DESC";
				$result = mysqli_query($conn, $sql);
				//$row_bb = mysqli_fetch_array($result);
				while ($row_bb = mysqli_fetch_assoc($result)) {
					$timePer = date('h:i:s A', strtotime($row_bb['date']));
				?>
					<div class="details_per" style="font-size:13px">
						- [<?= $timePer ?>] <?= $row_bb['details'] ?>
					</div>
				<?php } 
					mysqli_close($conn);
?>
			</div>
		</table>
		<hr>
<?php }
mysqli_close($conn);

} ?>
<script>
	$(document).ready(function() {
		var table = $('#ais_family_web').DataTable({
			responsive: true,
			lengthMenu: [
				[10, 25, 50, 100, -1],
				[10, 25, 50, 100, "All"]
			],
		});
		new $.fn.dataTable.FixedHeader(table);
	});
</script>