<?php
session_start();
error_reporting(0);
require_once __DIR__ . '/controller/conn.php';
require __DIR__ . '/controller/data.php';
// require __DIR__ . '/inc/head.php';
require __DIR__ . '/controller/others.php';
require __DIR__ . '/controller/photo.php';
require __DIR__ . '/controller/mobile_detect.php';
include __DIR__ . './PHPMailer/PHPMailerAutoload.php';
require __DIR__ . '/controller/mail.php';
require __DIR__ . '/phpqrcode/qrlib.php';
// include __DIR__.'/inc/header.php';

$connPdo = $pdo->open();
$detect = new Mobile_Detect();

$data = new Data();
$others = new Others();
$mailSend = new Mail();
$photoData = new Photo();
$batchData = $others->getBatch();
$courseList = $others->getCourse();
$course_year = $others->getCourseYear();
$getAlbum = $photoData->getAlbum();
$birth_data = $others->getBirthdayDate();
$birth_coming = $others->getUpcomingBirthdayDate();
$megaMenu = $others->getMegaMenu();
$AllStdInfo = $data->getAllBatch(); // get all student info of all batch
$permission = $others->getCheckList(); // get distinct checklist - only param value.
$hallNames = $others->getLog('hall', 'name_en ASC');
$BloodList = $others->getLog('blood', 'short_text ASC');
$districtAll =$others->getLog('district', 'name ASC');
$batchDataAll = $others->getBatchAll(); //get only Batch Name



$batch = $_SESSION['batch'];
$get_batch = $_GET['batch'];

if (isset($_SESSION['student_id'])) {
	$loggedin = $data->batchData($batch, $_SESSION['student_id'], 'student_id');
	$loggedinInfoInsert = array(
		'name' => $loggedin['name'],
		'batch' => $loggedin['batch'],
		'student_id' => $loggedin['student_id']
	);
}

if (isset($_GET['id']) && isset($_GET['students']) && isset($_GET['batch'])) {
	$row = $data->batchData($get_batch, $_GET['id'], 'id');

	$details_activity = 'View details information of <b>' . $row['name'] . ' (' . $row['batch'] . ')</b>';
	$insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
	$student_id = $row['student_id'];
	$hall_chk = $others->getHallName(substr($student_id, 2, 3));
	if ($hall_chk == '0') {
		$hall = $row['hall'];
		$hall_name = (!empty($hall)) ? str_replace('_', ' ', $row['hall']) : 'Hall not yet specified';
	} else {
		$hall_name = $hall_chk;
	}

	$fb_id = $row['fb_id'];
	$facebook_url = $others->get_facebook_url($fb_id);

	# QR Code for Indvidual Profile

	// $text= "BEGIN:VCARD VERSION:3.0";
	// $text .= "N:".$row['name'];
	// $text .= "FN:".$row['name'];
	// $text .= "ORG:".$hall_name; 
	// $text .= "TITLE:";
	// $text .= "ADR:;;;;;;".$row['address'];
	// $text .= "TEL; WORK; VOICE:".$row['phone'];
	$text = "Name: ".$row['name']."\n";
	$text .= "Phone: ".$row['phone']."\n";
	$text .= "Email: ".$row['email']."\n";
	$text .= "Batch: ".$row['batch']."\n";
	$text .= "Blood: ".$row['blood']."\n";
	// $text .= "EMAIL; WORK; INTERNET:".$row['email'];
	// $text .= "URL:";
	// $text .= "END:VCARD";
	$path = 'phpqrcode/qr_code/';
	$qr_file = $path . uniqid() . ".png";
	$ecc = 'L';
	$pixel_Size = 3;
	$frame_Size = 3;
	QRcode::png($text, $qr_file, $ecc, $pixel_Size, $frame_size);

	# QR Code for Indvidual Profile
?>

	<div class="row inside_spin">
		<div class="spinner_log">
			<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
		</div>
		<div class="col-md-3 image_pro">

			<?php
			$img = $row['photo'];
			if (empty($img)) { ?>
				<img src='ais-assets/icon/demo.png'>
			<?php } else { ?>
				<img src='image/<?= $row['photo'] ?>'>
			<?php } ?>
			<div class="media contact-info mt-3">
				<span class="contact-info__icon view social">
					<a class="mr-2" target='_blank' href="https://facebook.com/<?= $facebook_url ?>"><i class="fab fa-facebook-square"></i></a>
					<a href="https://m.me/<?= $facebook_url ?>"><i class="fab fa-facebook-messenger"></i></a>
				</span>
			</div>
			<div class="qr_code">
                <center><img id='qr_code_img' src='<?= $qr_file ?>' alt='Scan to get mobile number'></center>
            </div>
			<?php if ($row['showing'] == '1') { ?>
				<span class="btn btn-success btn-sm lock_status"><i class="fas fa-lock-open"></i></span>
			<?php } else {	?>
				<span class="btn btn-danger btn-sm lock_status"><i class="fas fa-lock"></i></span>
			<?php } ?>
		</div>


		<div class="col-md-9">
			<h4 class="text-capitalize"><b><?= ucwords(strtolower($row['name'])) ?></b><br><small><?= $row['name_bangla'] ?></small></h4>
			<i class="fas fa-id-card mr-2"></i><?= $row['student_id'] ?>

			<span class="batch_session">
				<span class="batch text-white bg-success mr-1">
					<?= $row['batch'] ?>
				</span>
				<span class="session text-white bg-primary">
					<?= $row['session'] ?>
				</span>
			</span>
			<hr>
			<?php
			$birthday = $row['birth'];
			if (!empty($birthday)) {
				$date_name = date('l', strtotime($birthday));
				$month = date('F', strtotime($birthday));
				$date = date('d', strtotime($birthday));
				$year = date('Y', strtotime($birthday));
			?>

				<div class="media contact-info">
					<span class="contact-info__icon view"><i class="fas fa-birthday-cake"></i></span>
					<div class="media-body view text-capitalize">
						<p><?php echo "" . $date_name . ", " . $month . " " . $date . ", " . $year . ""; ?> </p>

					</div>
				</div>
			<?php } ?>
			<div class="media contact-info">
				<span class="contact-info__icon view blood"><i class="fas fa-tint"></i></span>
				<div class="media-body view text-capitalize">
					<p><?= $row['blood'] ?> </p>
				</div>
			</div>

			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-phone"></i></span>
				<div class="media-body view text-capitalize">
					<p><a href="tel:<?= $row['phone'] ?>"> <?= $row['phone'] ?> </a> </p>
				</div>
			</div>
			<?php
			$email_id = $row['email'];
			if (!empty($email_id)) { ?>
				<div class="media contact-info">
					<span class="contact-info__icon view"><i class="fas fa-envelope"></i></span>
					<div class="media-body view text-lowercase">
						<p><a href="mailto:<?= $row['email'] ?>"> <?= ucwords(strtolower($row['email'])) ?> </a> </p>
					</div>
				</div>
			<?php } ?>

			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-hotel"></i></span>
				<div class="media-body view">
					<p><a href="dataview.php?view_batch&customize_data_view&batch=<?= $_GET['batch'] ?>&hall_code=<?= substr($row['student_id'], 2, 3) ?>"><?= $hall_name ?></a><small> (Click to view all)</small></p>
				</div>
			</div>
			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-map-marker-alt"></i></span>
				<div class="media-body view text-capitalize">
					<p><?= ucwords(strtolower($row['address'])) ?><br><?= $row['address_bangla'] ?></p>
				</div>
			</div>

			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-city"></i></span>
				<div class="media-body view">
					<p><a href="dataview.php?view_batch&customize_data_view&batch=<?= $_GET['batch'] ?>&district=<?= $row['district'] ?>"><?= ucwords(strtolower($row['district'])) ?></a><small> (Click to view all)</small></p>
				</div>
			</div>
		</div>
	</div>

<?php
	$connPdo = null;
} else if (isset($_GET['id']) && isset($_GET['teachers'])) {
	$row = $data->batchData('teacher', $_GET['id'], 'id');
	$details_activity = 'View details teacher information of <b>' . $row['name'] . ' (' . $row['designation'] . ')</b>';
	$insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
	$fb_id = $row['fb_id'];
	$facebook_url = $others->get_facebook_url($fb_id);
?>

	<div class="row inside_spin">
		<div class="spinner_log">
			<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
		</div>
		<div class="col-md-3 image_pro">
			<?php
			$img = $row['photo'];
			if (empty($img)) { ?>
				<img src='ais-assets/icon/demo.png'>
			<?php } else { ?>
				<img src='image/<?= $row['photo'] ?>'>
			<?php } ?>
			<div class="media contact-info mt-3">
				<span class="contact-info__icon view social">
					<a class="mr-2" target='_blank' href="https://facebook.com/<?= $facebook_url ?>"><i class="fab fa-facebook-square"></i></a>
					<a href="https://m.me/<?= $facebook_url ?>"><i class="fab fa-facebook-messenger"></i></a>
				</span>
			</div>
		</div>

		<div class="col-md-9">
			<h4 class="text-capitalize"><b><?= $row['name'] ?></b></h4>
			<i class="fas fa-university mr-2"></i><?= $row['designation'] ?>
			<hr>
			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-phone"></i></span>
				<div class="media-body view text-capitalize">
					<p><a href="tel:<?= $row['phone'] ?>"> <?= $row['phone'] ?> </a> </p>
				</div>
			</div>

			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-envelope"></i></span>
				<div class="media-body view text-lowercase">
					<p><a href="mailto:<?= $row['email'] ?>"> <?= $row['email'] ?> </a> </p>
				</div>
			</div>

			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-user-graduate"></i></span>
				<div class="media-body view text-capitalize">
					<p><?= $row['edu'] ?></p>
				</div>
			</div>
			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-map-marker-alt"></i></span>
				<div class="media-body view text-capitalize">
					<p><?= ucwords(strtolower($row['per_addr'])) ?></p>
				</div>
			</div>
		</div>
	</div>

<?php $connPdo = null;
} else if (isset($_GET['id']) && isset($_GET['office_stuff'])) {
	$row = $data->batchData('office_stuff', $_GET['id'], 'id');
	$details_activity = 'View details Office Stuff information of <b>' . $row['name'] . ' (' . $row['designation'] . ')</b>';
	$insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
	$fb_id = $row['fb_id'];
	$facebook_url = $others->get_facebook_url($fb_id);
?>

	<div class="row inside_spin">
		<div class="spinner_log">
			<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
		</div>
		<div class="col-md-3 image_pro">
			<?php
			$img = $row['photo'];
			if (empty($img)) { ?>
				<img src='ais-assets/icon/demo.png'>
			<?php } else { ?>
				<img src='image/<?= $row['photo'] ?>'>
			<?php } ?>
			<div class="media contact-info mt-3">
				<span class="contact-info__icon view social">
					<a class="mr-2" target='_blank' href="https://facebook.com/<?= $facebook_url ?>"><i class="fab fa-facebook-square"></i></a>
					<a href="https://m.me/<?= $facebook_url ?>"><i class="fab fa-facebook-messenger"></i></a>
				</span>
			</div>
		</div>

		<div class="col-md-9">
			<h4 class="text-capitalize"><b><?= $row['name'] ?></b></h4>
			<i class="fas fa-university mr-2"></i><?= $row['designation'] ?>
			<hr>
			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-phone"></i></span>
				<div class="media-body view text-capitalize">
					<p><a href="tel:<?= $row['phone'] ?>"> <?= $row['phone'] ?> </a> </p>
				</div>
			</div>

			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-envelope"></i></span>
				<div class="media-body view text-lowercase">
					<p><a href="mailto:<?= $row['email'] ?>"> <?= $row['email'] ?> </a> </p>
				</div>
			</div>
			<div class="media contact-info">
				<span class="contact-info__icon view"><i class="fas fa-map-marker-alt"></i></span>
				<div class="media-body view text-capitalize">
					<p><?= ucwords(strtolower($row['per_addr'])) ?></p>
				</div>
			</div>
		</div>
	</div>

<?php $connPdo = null;
} else if (isset($_GET['login_info_batch_wise']) && isset($_GET['batch'])) {

	$details_activity = 'Login information view of batch <b>(' . $_GET['batch'] . ')</b>';
	$insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
?>
	<table id='ais_family_web' class='table usersinfo ais_family_login'>
		<thead>
			<tr>
				<th>#</th>
				<th>ID</th>
				<th>Name</th>
				<th>Batch</th>
				<th>Refer Website</th>
				<th>Device Type</th>
				<th>IP Address</th>
				<!-- <th>Location</th>
				<th>Capital</th>
				<th>Country</th>
				<th>ISP</th> -->
				<th>Time</th>
				<th>Details</th>
				<th>Action</th>
			</tr>
		</thead>
		<tbody>
			<?php
			function gen()
			{
				for ($i = 1; $i < 1000; $i++) {
					//$rand = str_pad(dechex(rand(0x000000, 0xFFFFFF)), 6, 0, STR_PAD_LEFT);
					//$rand = '#' . dechex(rand(0,10000000));
					$rand = '#' . substr(str_shuffle('0123456789ABCDEF'), 0, 6);
					echo "'" . $rand . "',";
				}
			}

			function gen_fixed()
			{
				for ($i = 1; $i < 1000; $i++) {
					echo "'#fff',";
				}
			}
			$now = date("Y-m-d");
			if (isset($_GET['actual_view'])) {
				$sql = "SELECT * , {$get_batch}.name FROM login LEFT JOIN {$get_batch} ON login.student_id = {$get_batch}.student_id WHERE login.batch = '" . $get_batch . "' GROUP BY login.student_id ORDER by RIGHT(login.student_id,3) ASC";
			} else if (isset($_GET['today_view'])) {
				$sql = "SELECT * , {$get_batch}.name FROM login LEFT JOIN {$get_batch} ON login.student_id = {$get_batch}.student_id WHERE login.batch = '" . $get_batch . "' AND DATE(login.time) = '" . $now . "' GROUP BY login.student_id ORDER by RIGHT(login.student_id,3) ASC";
			} else {
				$sql = "SELECT login.id, login.student_id, login.http, login.batch,login.device,login.region,login.country,login.country_flag,login.capital,login.isp, login.details, login.ip, login.time, login.action, {$get_batch}.name FROM login INNER JOIN  {$get_batch} ON login.student_id = {$get_batch}.student_id WHERE login.batch = '" . $get_batch . "' ORDER by login.id DESC";
				//$sql = "SELECT * FROM login WHERE batch = '".$get_batch."' ORDER by id DESC";
			}

			$stmt = $connPdo->prepare($sql);
			$stmt->execute();
			$count = 1;
			foreach ($stmt as $row) { ?>

				<tr>
					<td data-label='#'><?= $count ?></td>
					<td data-label='ID' class="usersid text-bold"><?= $row['student_id'] ?></td>
					<td data-label='Name'><?= $row['name'] ?></td>
					<td data-label='Batch'><?= $row['batch'] ?></td>
					<td data-label='Refer URL'><?= $row['http'] ?></td>
					<td data-label='Device'><?= $row['device'] ?></td>
					<td data-label='IP'><?= $row['ip'] ?></td>
					<!-- <td data-label='Location'><?= $row['region'] ?>, <?= $row['country'] ?> <img style="width:20px; height:15px" class="rounded" src="<?= $row['country_flag'] ?>"></td>
					<td data-label='Capital'><?= $row['capital'] ?> </td>
					<td data-label='Country'><?= $row['country'] ?> </td>
					<td data-label='ISP'><?= $row['isp'] ?></td> -->
					<td data-label='Time'><?= $row['time'] ?></td>
					<td><?= $row['details'] ?></td>
					<td data-label='Action'><?= $row['action'] ?></td>
				</tr>

			<?php
				$count = $count + 1;
			}					?>
		</tbody>
	</table>

	<script>
		$(function() {
			var tableRows = $(".usersinfo tbody tr"); //find all the rows
			var bgColors = [<?= gen_fixed(); ?>];
			var colors = [<?= gen(); ?>];
			var rowValues = {};
			tableRows.each(function() {
				var rowValue = $(this).find(".usersid").html();
				if (!rowValues[rowValue]) {
					var rowComposite = new Object();
					rowComposite.count = 1;
					rowComposite.row = this;
					rowComposite.color = colors.shift();
					rowComposite.bgColor = bgColors.shift();
					rowValues[rowValue] = rowComposite;
				} else {
					var rowComposite = rowValues[rowValue];
					rowComposite.count++;
					$(this).css('color', rowComposite.color);
					$(this).css('backgroundColor', rowComposite.bgColor);
					$(rowComposite.row).css('color', rowComposite.color);
					$(rowComposite.row).css('backgroundColor', rowComposite.bgColor);
				}
			});
		});
	</script>
	<?php
	$connPdo = null;
} else if (isset($_GET['admin_info_show']) && isset($_GET['batch']) && (isset($_SESSION['student_id']) || !$detect->isMobile())) {
	if (isset($_GET['report_info'])) { ?>
		<h4 class="text-uppercase"><b>Admin info of your Batch</b></h4>
	<?php } else { ?>
		<h4 class="text-uppercase"><b>Admin info of <?= $get_batch ?> Batch</b></h4>
	<?php }  ?>

	<?php
	$sql = "SELECT * FROM {$get_batch} WHERE (role='admin' OR role='dev') ORDER BY RIGHT(student_id,5) ASC";
	$stmt = $connPdo->prepare($sql);
	$stmt->execute();

	foreach ($stmt as $row) {
		$fb_id = $row['fb_id'];
		$facebook_url = $others->get_facebook_url($fb_id);
	?>
		<div class="card-body row admin_info_row">
			<div class="col-md-2">
				<?php $img = $row['photo'];
				if (empty($img)) { ?>
					<div class='avatar'><a class='fb_id' target='_blank' href='https://www.facebook.com/<?= $facebook_url ?>'><img src='ais-assets/icon/demo.png'><img class='img-top' src='ais-assets/icon/fb.png'></a></div>
				<?php } else { ?>
					<div class='avatar'><a class='fb_id' target='_blank' href='https://www.facebook.com/<?= $facebook_url ?>'><img src='image/<?= $row['photo'] ?>'><img class='img-top' src='ais-assets/icon/fb.png'></a></div>
				<?php } ?>
			</div>
			<div class="col-md-10">
				<h5 class="card-title"><b><?= $row['name'] ?></b></h5>
				<p class="card-text">
					<?php if (isset($_GET['report_info'])) { ?>
						<i class="fas fa-id-card mr-2"></i><?= $row['student_id'] ?>
						<br>
					<?php } ?>
					<i class="fas fa-envelope mr-2"></i><a href='mailto:<?= $row['email'] ?>'><?= $row['email'] ?></a>
					<br>
					<i class="fas fa-phone-square-alt mr-2"></i><a href='tel:<?= $row['phone'] ?>'><?= $row['phone'] ?></a>
				</p>
			</div>
		</div>
	<?php }
	$connPdo = null;	?>
<?php $connPdo = null;
} else if (isset($_GET['openCourseChangeWindow']) && isset($_GET['id'])) {
	$row = $data->batchData('course_list', $_GET['id'], 'id');
?>
	<form id="formCourse">
		<div class="form-group">
			<label>Course Code</label>
			<input type='text' class='form-control' name='course_code' value='<?= $row["course_code"] ?>' required='required'>
		</div>
		<div class="form-group">
			<label>Course Name</label>
			<input type='text' class='form-control' name='course_name' value='<?= $row["course_name"] ?>' required='required'>
		</div>

		<div class="form-group">
			<label>Course Year</label>
			<select name="year" class="custom-select">
				<option value="">Choose Year</option>
				<option value="1st Year" <?= $row["year"] == '1st Year' ? 'selected' : '' ?>>1st Year
				</option>
				<option value="2nd Year" <?= $row["year"] == '2nd Year' ? 'selected' : '' ?>>2nd Year
				</option>
				<option value="3rd Year" <?= $row["year"] == '3rd Year' ? 'selected' : '' ?>>3rd Year
				</option>
				<option value="4th Year" <?= $row["year"] == '4th Year' ? 'selected' : '' ?>>4th Year
				</option>
				<option value="MBA" <?= $row["year"] == 'MBA' ? 'selected' : '' ?>>MBA
				</option>
			</select>
		</div>

		<div class="form-group">
			<label>Course Semester</label>
			<select name="semester" class="custom-select">
				<option value="">Choose Semester</option>
				<option value="1st Semester" <?= $row["semester"] == '1st Semester' ? 'selected' : '' ?>>1st
					Semester</option>
				<option value="2nd Semester" <?= $row["semester"] == '2nd Semester' ? 'selected' : '' ?>>2nd
					Semester</option>
			</select>
		</div>
		<input type="hidden" name="change_course_value" value="true">
		<input type="hidden" name="id" value="<?= $row['id'] ?>">
		<div class="form-group text-center">
			<button id="clickCourseAdd" class="border-0 btn-block block-main-btn btn btn-success text-uppercase">
				<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span>
				<span class="MainBtnText">Update</span>
			</button>
			<!-- <button id="clickCourseAdd" class='border-0 btn-block block-main-btn btn btn-success btn-sm'>Update </button>
			<button class="border-0 btn-block block-sec-btn btn btn-danger btn-sm" data-dismiss="modal" aria-hidden="true"> CLOSE </button> -->
		</div>
	</form>
<?php $connPdo = null;
} else if (isset($_GET['openDistrictChangeWindow']) && isset($_GET['id'])) {
	$row = $data->batchData('district', $_GET['id'], 'id');
?>
	<form id="formDistrict">
		<div class="form-group">
			<label>Enter District Name</label>
			<input type='text' class='form-control' name='district' value='<?= $row["name"] ?>' required='required'>
			<input type='hidden' name='change_district_value' value='true'>
			<input type='hidden' name='id' value='<?= $row["id"] ?>'>
		</div>

		<div class="form-group">
			<label>Enter District (Bangla)</label>
			<input type='text' class='form-control' name='district_bn' value='<?= $row["name_bn"] ?>' required='required'>
		</div>
		<div class="form-group">
			<label>Enter Division</label>
			<input type='text' class='form-control' name='division' value='<?= $row["division"] ?>' required='required'>
		</div>
		<div class="form-group text-center">
			<button id="clickDistrictAdd" class="border-0 btn-block block-main-btn btn btn-success text-uppercase">
				<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span>
				<span class="MainBtnText">Update</span>
			</button>
			<!-- <button id="clickDistrictAdd" class='border-0 btn-block block-main-btn btn btn-success btn-sm'>Update</button>
			<button class="border-0 btn-block block-sec-btn btn btn-danger btn-sm" data-dismiss="modal" aria-hidden="true"> CLOSE </button> -->
		</div>
	</form>

<?php $connPdo = null;
} else if (isset($_GET['openUpdateNoticeWindow']) && isset($_GET['id'])) {
	$id = $_GET['id'];
	$row = $data->batchData("notice", $id, 'id');
?>
	<form id="updateNoticeForm">
		<div class="row">
			<div class="col-md-12">
				<div class="form-group">
					<label>
						Title
					</label>
					<input type="text" class="form-control" name="title" placeholder="Title Here..." value="<?php echo $row['title'] ?>">
				</div>
			</div>
			<div class="col-md-12">
				<div class="form-group">
					<label>
						Message
					</label>
					<textarea rows="10" type="text" id="message_notice" class="form-control" name="message" placeholder="Write notice ..."><?php echo $row['message'] ?></textarea>
				</div>
			</div>
			<div class="col-md-12">
				<div class="form-group">
					<label>
						Showing Option
					</label>
					<select class="form-control" name="active">
						<option class="text-success" value="1" <?php echo $row['active'] == '1' ? ' selected="selected"' : ''; ?>>Public</option>
						<option class="text-danger" value="0" <?php echo $row['active'] == '0' ? ' selected="selected"' : ''; ?>>Private</option>
					</select>
				</div>
			</div>
			<input type="hidden" value="true" name="update_notice">
			<input type="hidden" value="<?php echo $row['batch'] ?>" name="batch">
			<input type="hidden" value="<?php echo $row['id'] ?>" name="id">
			<div class="col-md-12">
				<div class="form-group">
					<button class="border-0 btn-block block-main-btn btn btn-success btn-sm" id="updateNoticeBtn">Update</button>
				</div>
			</div>
		</div>
	</form>
<?php } else if (isset($_GET['openDeleteNoticeWindow']) && isset($_GET['id'])) {
	$id = $_GET['id'];
	$row = $data->batchData("notice", $id, 'id');
?>
	<form id="deleteNoticeForm">
		<input type="hidden" value="<?= $row["id"] ?>" name="id">
		<input type="hidden" value="<?= $row["batch"] ?>" name="batch">
		<input type="hidden" value="true" name="notice_delete">
		<div class="text-center">
			<h2 class="bold view_email"> <?= $row["title"] ?></h2>
			<h4 class="bold view_email"> <?= $row["message"] ?></h4>
			<small class="bold view_email"> By <?= $row["name"] ?></small>
		</div>
		<button id="deleteNoticeBtn" class="mt-2 border-0 btn btn-danger btn-block block-main-btn"> Delete</button>
	</form>
<?php } else if (isset($_GET['openStmtFileWindowDelete']) && isset($_GET['id'])) {
	$id = $_GET['id'];
	$row = $data->batchData("statement", $id, 'id');
?>
	<form id="deletestmtForm">
		<input type="hidden" value="<?= $row["id"] ?>" name="id">
		<input type="hidden" value="true" name="statementDelete">
		<div class="text-center">
			<h2 class="bold view_email"> <?= $row["narration"] ?></h2>
			<h6 class="bold view_email"> <?= $row["added_by"] ?></h6>
			<small class="bold view_email"><?= $row["date_added"] ?></small>
		</div>
		<button id="deletestmtBtn" class="mt-2 border-0 btn btn-danger btn-block block-main-btn"> Delete</button>
	</form>
<?php } else if (isset($_GET['openPublicNoticeWindow']) && isset($_GET['id'])) {
	$id = $_GET['id'];
	$row = $data->batchData("notice", $id, 'id');
?>
	<form id="publicNoticeForm">
		<input type="hidden" value="<?= $row["id"] ?>" name="id">
		<input type="hidden" value="<?= $row["batch"] ?>" name="batch">
		<input type="hidden" value="true" name="notice_public">
		<div class="text-center">
			<h2 class="bold view_email"> <?= $row["title"] ?></h2>
			<h4 class="bold view_email"> <?= $row["message"] ?></h4>
			<small class="bold view_email"> By <?= $row["name"] ?></small>
		</div>
		<button id="publicNoticeBtn" class="mt-2 border-0 btn btn-success btn-block block-main-btn"> Change to Public</button>
	</form>
<?php } else if (isset($_GET['openPrivateNoticeWindow']) && isset($_GET['id'])) {
	$id = $_GET['id'];
	$row = $data->batchData("notice", $id, 'id');
?>
	<form id="privateNoticeForm">
		<input type="hidden" value="<?= $row["id"] ?>" name="id">
		<input type="hidden" value="<?= $row["batch"] ?>" name="batch">
		<input type="hidden" value="true" name="notice_private">
		<div class="text-center">
			<h2 class="bold view_email"> <?= $row["title"] ?></h2>
			<h4 class="bold view_email"> <?= $row["message"] ?></h4>
			<small class="bold view_email"> By <?= $row["name"] ?></small>
		</div>
		<button id="privateNoticeBtn" class="mt-2 border-0 btn btn-danger btn-block block-main-btn"> Change to Private</button>
	</form>
<?php } else if (isset($_GET['openDeleteFileWindow']) && isset($_GET['id'])) {
	$id = $_GET['id'];
	$row = $data->batchData("learning", $id, 'id');
?>
	<form id="deleteFileForm">
		<input type="hidden" value="<?= $row["id"] ?>" name="id">
		<input type="hidden" value="<?= $row["batch"] ?>" name="batch">
		<input type="hidden" value="true" name="files_delete">
		<div class="text-center">
			<h3 class="bold view_email"> <?= str_replace("-", " ", $row['title']) ?></h3>
			<h4 class="bold view_email"> <?= $row["course_name"] ?></h4>
			<small class="bold view_email"> By <?= $row["name"] ?></small>
		</div>
		<button id="deleteFileBtn" class="border-0 btn btn-danger btn-block block-main-btn"> Delete</button>
	</form>
<?php } else if (isset($_GET['openDeleteReportWindow']) && isset($_GET['id'])) {
	$id = $_GET['id'];
	$row = $data->batchData("report_issue", $id, 'id');
	$stdInfo = $data->batchData($row['batch'], $row['student_id'], 'student_id');

?>
	<form id="deleteReportForm">
		<input type="hidden" value="<?= $row["id"] ?>" name="id">
		<input type="hidden" value="true" name="DeleteReportIssued">
		<div class="text-center">
			<h2 class="bold view_email"> <?= $row["batch"] ?></h2>
			<h4 class="bold view_email"> <?= $row["student_id"] ?></h4>
			<small class="bold view_email"> By <?= $stdInfo["name"] ?> (<?= $row["time"] ?>)</small>

		</div>

		<button id="deleteReportBtn" class="border-0 btn btn-danger btn-block block-main-btn mt-2"> Delete</button>

	</form>
<?php } else if (isset($_GET['openResolvedReportWindow']) && isset($_GET['id'])) {
	$id = $_GET['id'];
	$row = $data->batchData("report_issue", $id, 'id');
	$stdInfo = $data->batchData($row['batch'], $row['student_id'], 'student_id');
?>
	<form id="resolvedReportForm">
		<input type="hidden" value="<?= $row["id"] ?>" name="id">
		<input type="hidden" value="true" name="ResolvedReportIssued">
		<div class="text-center">
			<h2 class="bold view_email"> <?= $row["subject"] ?></h2>
			<h4 class="bold view_email"> <?= $row["student_id"] ?> (<?= $row["batch"] ?>)</h4>
			<small class="bold view_email"> By <?= $stdInfo["name"] ?> (<?= $row["time"] ?>)</small>
		</div>
		<button id="resolvedReportBtn" class="border-0 btn btn-success btn-block block-main-btn mt-2"> Change to Resolved</button>
	</form>
<?php } else if (isset($_GET['openNotResolvedReportWindow']) && isset($_GET['id'])) {
	$id = $_GET['id'];
	$row = $data->batchData("report_issue", $id, 'id');
	$stdInfo = $data->batchData($row['batch'], $row['student_id'], 'student_id');
?>
	<form id="NotresolvedReportForm">
		<input type="hidden" value="<?= $row["id"] ?>" name="id">
		<input type="hidden" value="true" name="NotResolvedReportIssued">
		<div class="text-center">
			<h2 class="bold view_email"> <?= $row["subject"] ?></h2>
			<h4 class="bold view_email"> <?= $row["student_id"] ?> (<?= $row["batch"] ?>)</h4>
			<small class="bold view_email"> By <?= $stdInfo["name"] ?> (<?= $row["time"] ?>)</small>
		</div>
		<button id="NotresolvedReportBtn" class="border-0 btn btn-warning btn-block block-main-btn mt-2"> Changed to Reissued</button>
	</form>
<?php } else if (isset($_GET['openDeleteFaqsWindow']) && isset($_GET['id'])) {
	$id = $_GET['id'];
	$row = $data->batchData("faq", $id, 'id');
?>
	<form id="deleteFaqsForm">
		<input type="hidden" value="<?= $row["id"] ?>" name="id">
		<input type="hidden" value="true" name="faqs_delete">
		<div class="text-center">
			<h2 class="bold view_email"> <?= $row["title"] ?></h2>
			<small class="bold view_email"> By <?= $row["name"] ?></small>
		</div>
		<button id="deleteFaqsBtn" class="border-0 btn btn-danger btn-block block-main-btn mt-2"> Delete</button>
	</form>
<?php } else if (isset($_GET['openDeleteMegaLinkWindow']) && isset($_GET['id'])) {
	$id = $_GET['id'];
	$row = $data->batchData("mega_menu", $id, 'id');
?>
	<form id="deleteMegaForm">
		<input type="hidden" value="<?= $row["id"] ?>" name="id">
		<input type="hidden" value="true" name="mega_link_delete">
		<div class="text-center">
			<h2 class="bold view_email"> <?= $row["title"] ?></h2>
			<h4 class="bold view_email"> <?= $row["link"] ?></h4>
			<small class="bold view_email"> By <?= $row["added_by"] ?></small>
		</div>
		<button id="deleteMegaBtn" class="border-0 btn btn-danger btn-block block-main-btn mt-2"> Delete</button>

	</form>
<?php } else if (isset($_GET['openGenaerateLinkWindow']) && isset($_GET['student_id']) && isset($_GET['batch']) && isset($_GET['email'])) {
	$id = $_GET['id'];
	$batch = $_GET['batch'];
	$row = $data->batchData($batch, $id, 'id');
?>
	<form id="generateKeyInfoForm">
		<input type="hidden" value="<?= $row["student_id"] ?>" name="student_id">
		<input type="hidden" value="<?= $row["email"] ?>" name="email">
		<input type="hidden" value="<?= $row["batch"] ?>" name="batch">
		<input type="hidden" value="true" name="admin_generate_link_add_info">
		<div class="text-center">
			<h2 class="bold view_email"> <?= $row["batch"] ?></h2>
			<h4 class="bold view_email"> <?= $row["name"] ?></h4>
			<h5 class="bold view_email"><?= $row["email"] ?></h5>
		</div>
		<button id="generateKeyInfoBtn" class="border-0 btn btn-success btn-block block-main-btn mt-2"> Generate Link</button>

	</form>
<?php } else if (isset($_GET['openSendLinkWindow']) && isset($_GET['student_id']) && isset($_GET['batch']) && isset($_GET['email'])) {
	$id = $_GET['id'];
	$batch = $_GET['batch'];
	$row = $data->batchData($batch, $id, 'id');
?>
	<form id="getAddReqForm">
		<input type="hidden" value="<?= $row["student_id"] ?>" name="student_id">
		<input type="hidden" value="<?= $row["email"] ?>" name="email">
		<input type="hidden" value="<?= $row["batch"] ?>" name="batch">
		<input type="hidden" value="true" name="getAddInfoReq">
		<div class="text-center">
			<h2 class="bold view_email"> <?= $row["batch"] ?></h2>
			<h4 class="bold view_email"> <?= $row["name"] ?></h4>
			<h5 class="bold view_email"><?= $row["email"] ?></h5>
		</div>
		<button id="getAddReqBtn" class="border-0 btn btn-success btn-block block-main-btn mt-2"> Send Request</button>
	</form>
<?php } else if (isset($_GET['openMailIdChangeWindow']) && isset($_GET['student_id']) && isset($_GET['batch']) && isset($_GET['email'])) {
	$id = $_GET['id'];
	$batch = $_GET['batch'];
	$email = $_GET['email'];
	$student_id = $_GET['student_id'];
	$row = $data->batchData($batch, $id, 'id');
?>
	<form id="changeMailIdForm">
		<div class="form-group">
			<label>Student ID</label>
			<input type="text" class="form-control" value="<?= $student_id ?>" name="student_id">
		</div>
		<div class="form-group">
			<label>Email</label>
			<input type="text" class="form-control" value="<?= $email ?>" name="email">
		</div>
		<input type="hidden" value="<?= $row["batch"] ?>" name="batch">
		<input type="hidden" value="<?= $id ?>" name="id">
		<input type="hidden" value="true" name="change_mail_id_only">
		<div class="form-group mt-3">
			<small>N.B. You can only change the email and student ID instead of changing / deleting a person's entire profile.</small>
			<button id="changeMailIdBtn" class="mt-3 btn-block block-main-btn btn btn-success btn-flat">Change</button>
		</div>
	</form>
<?php } else if (isset($_GET['openTeacherDeleteWindow']) && isset($_GET['id'])) {

	$id = $_GET['id'];
	$row = $data->batchData("teacher", $id, 'id');
?>
	<form id="deleteTeacherForm">
		<input type="hidden" value="<?= $row["id"] ?>" name="id">
		<input type="hidden" value="true" name="teachers_delete">
		<div class="text-center">
			<h2 class="bold view_email"> <?= $row["name"] ?></h2>
			<h6 class="bold view_email"> <?= $row["designation"] ?></h6>
		</div>
		<button id="deleteTeacherBtn" class="border-0 btn btn-danger btn-block block-main-btn mt-2"> Delete</button>
	</form>

<?php } else if (isset($_GET['openStaffDeleteWindow']) && isset($_GET['id'])) {

	$id = $_GET['id'];
	$row = $data->batchData("office_stuff", $id, 'id');
?>
	<form id="deleteStaffForm">
		<input type="hidden" value="<?= $row["id"] ?>" name="id">
		<input type="hidden" value="true" name="office_stuff_delete">
		<div class="text-center">
			<h2 class="bold view_email"> <?= $row["name"] ?></h2>
			<h6 class="bold view_email"> <?= $row["designation"] ?></h6>
		</div>
		<button id="deleteStaffBtn" class="border-0 btn btn-danger btn-block block-main-btn mt-2"> Delete</button>
	</form>

<?php } else if (isset($_GET['openDeleteBatchDataWindow']) && isset($_GET['batch']) && isset($_GET['id'])) {
	$id = $_GET['id'];
	$batch = $_GET['batch'];
	$row = $data->batchData($batch, $id, 'id');
?>
	<form id="deleteBatchDataForm">
		<input type="hidden" value="<?= $row["id"] ?>" name="id">
		<input type="hidden" value="<?= $row["batch"] ?>" name="batch">
		<input type="hidden" value="true" name="del_batch_info">
		<input type="hidden" value="delete" name="action">
		<div class="text-center">
			<p><b><?= $row["batch"] ?> Batch</b></p>
			<h2 class="bold view_email"> <?= $row["name"] ?></h2>
			<h4 class="bold view_email"> <?= $row["student_id"] ?></h4>
			<h6 class="bold view_email"> <?= $row["email"] ?></h6>
		</div>
		<button id="deleteBatchDataBtn" class="border-0 btn btn-danger btn-block block-main-btn mt-2"> Delete</button>

	</form>
<?php } else if (isset($_GET['deleteSqlBackup']) && isset($_GET['file'])) {
	$file = $_GET['file'];
	$path    = './backup/log';
	$fileDir = $path . "/" . $file;
	$date = date("d-m-Y h:i A", filemtime($fileDir));
	$size = number_format(filesize($fileDir) / 1024, 2);
?>
	<form id="deleteSqlBackupForm">
		<input type="hidden" value="true" name="deleteSqlBackup">
		<input type="hidden" value="<?= $file ?>" name="file">
		<div class="text-center">
			<h2 class="bold view_email text-danger"> SQL Backup File</h2>
			<h4 class="bold view_email"> <?= $size ?> KB</h4>
			<h6 class="bold view_email"> <?= $date ?></h6>
			<h5 class="bold view_email"> <?= $file ?></h5>
		</div>
		<button id="deleteSqlBackupBtn" class="border-0 btn btn-danger btn-block block-main-btn mt-2"> Delete</button>
	</form>
<?php } else if (isset($_GET['openAddMailWindow'])) {
	$row = $data->batchData('sys_mail_setup', $_GET['id'], 'id');
?>

	<?php if (isset($_GET['delete_mail'])) { ?>
		<!-- Delete -->
		<form id="deleteMailForm">
			<input type="hidden" value="true" name="delete_mail_sys">
			<input type="hidden" value="<?= $row["id"] ?>" name="id">
			<input type="hidden" value="<?= $row["email"] ?>" name="email">
			<div class="text-center">
				<p>DELETE</p>
				<h2 class="bold view_email"> <?= $row["email"] ?></h2>
			</div>

			<button id="deleteMailBtn" class="border-0 btn btn-danger btn-block block-main-btn mt-2"> Delete</button>
		</form>


	<?php } elseif (isset($_GET['activate_mail'])) { ?>
		<!-- Status -->
		<form id="activateMailForm">
			<input type="hidden" value="true" name="change_mail_status">
			<input type="hidden" value="<?= $row["id"] ?>" name="id">
			<input type="hidden" value="<?= $row["email"] ?>" name="email">
			<div class="text-center">
				<p>ACTIVATE</p>
				<h2 class="bold"><?= $row["email"] ?></h2>
			</div>
			<button id="activateMailBtn" class="border-0 btn btn-success btn-block block-main-btn mt-2"> Activate</button>
		</form>

	<?php } elseif (isset($_GET['add_mail']) || isset($_GET['update_mail'])) { ?>

		<form id="addMailForm">
			<div class="row">
				<input type='hidden' name='change_mail_value' value='true'>
				<input type='hidden' name='id' value='<?= ($row["id"] == "" ? "add" : $row["id"]) ?>'>

				<div class="col-sm-12">
					<div class="form-group">
						<label>Email</label>
						<input type="email" class="form-control" value='<?= $row["email"] ?>' name="email" required>
					</div>
				</div>
				<div class="col-sm-12">
					<div class="form-group">
						<label>Password</label>
						<input type="password" class="form-control" value='<?= $row["password"] ?>' name="password" required>
					</div>
				</div>
				<div class="col-sm-12">
					<div class="form-group">
						<label>Email Host</label>
						<input type="text" class="form-control" value='<?= $row["host"] ?>' name="host" required>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="form-group">
						<label>SMTP</label>
						<input type="text" class="form-control" value='<?= $row["smtp"] ?>' name="smtp" required>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="form-group">
						<label>Port</label>
						<input type="number" class="form-control" value='<?= $row["port"] ?>' name="port" required>
					</div>
				</div>
			</div>
			<button id="addMailBtn" class="border-0 btn btn-success btn-block block-main-btn mt-2" name="email_add"> Add/Update</button>

		</form>
	<?php } ?>

<?php
} else if (isset($_GET['openHallChangeWindow'])) {
	$row = $data->batchData('hall', $_GET['id'], 'id');
?>
	<form id="formUpdateHall">
		<div class="form-group">
			<label>Hall Name (Bangla)</label>
			<input type='text' class='form-control' name='name_bn' value='<?= $row["name_bn"] ?>' required='required'>
			<input type='hidden' name='change_hall_value' value='true'>
			<input type='hidden' name='id' value='<?= ($row["id"] == "" ? "add" : $row["id"]) ?>'>
		</div>

		<div class="form-group">
			<label>Hall Name (English)</label>
			<input type='text' class='form-control' name='name_en' value='<?= $row["name_en"] ?>' required='required'>
		</div>
		<div class="form-group">
			<label>Hall Code</label>
			<input type='text' class='form-control' name='code' value='<?= $row["code"] ?>' required='required'>
		</div>
		<div class="form-group text-center">
			<button id="clickHallUpdate" class="border-0 btn-block block-main-btn btn btn-success text-uppercase">
				<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span>
				<span class="MainBtnText">Update/Add</span>
			</button>
			<!-- <button id="clickHallUpdate" class='border-0 btn-block block-main-btn btn btn-success btn-sm'>Update/Add</button>
			<button class="border-0 btn-block block-sec-btn btn btn-danger btn-sm" data-dismiss="modal" aria-hidden="true"> CLOSE </button> -->
		</div>
	</form>

<?php $connPdo = null;
} else if (isset($_GET['openAddAdminWindow'])) { ?>

	<form id="formUpdateAdmin">
		<div class="form-group">
			<label>Student Name</label>
			<!-- <select class="selectpicker form-control" data-live-search="true" data-hide-disabled="true" name="student_batch" > -->
			<select class="custom-select" id='student_batch_Std' name="student_batch">
				<option value="">Select Student</option>
				<?php
				foreach ($AllStdInfo as $row) {
					echo '<option value="' . $row["id"] . '/' . $row["student_id"] . '/' . $row["batch"] . '/' . $row["name"] . '">' . $row["batch"] . ' || ' . $row["name"] . ' || ' . $row["student_id"] . '</option>';
				}
				?>
			</select>
			<input type='hidden' name='add_new_admin' value='true'>
		</div>

		<div class="form-group">
			<label>Role</label>
			<select class="custom-select" name="role_admin">
				<option value="" <?php echo $_GET['current_role'] == '' ? ' selected="selected"' : ''; ?>>General</option>
				<option value="admin" <?php echo $_GET['current_role'] == 'admin' ? ' selected="selected"' : ''; ?>>Admin</option>
				<option value="dev" <?php echo $_GET['current_role'] == 'dev' ? ' selected="selected"' : ''; ?>>Controller</option>
			</select>
		</div>
		<div class="form-group text-center">
			<button id="clickAddBtnAdmin" class="border-0 btn-block block-main-btn btn btn-success text-uppercase">
				<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span>
				<span class="MainBtnText">Update/Add</span>
			</button>
			<!-- <button id="clickAddBtnAdmin" class='border-0 btn-block block-main-btn btn btn-success btn-sm'>Add/Update</button>
			<button class="border-0 btn-block block-sec-btn btn btn-danger btn-sm" data-dismiss="modal" aria-hidden="true"> CLOSE </button> -->
		</div>
	</form>

<?php $connPdo = null;
} else if (isset($_GET['openPassChangeWindow']) && isset($_GET['batch'])) {
	$row = $data->batchData($get_batch, $_GET['id'], 'id');
?>


	<form id="formPassChng">
		<div class="form-group">
			<label>
				Enter Password
			</label>
			<input type='password' class='form-control' name='Password' value='<?= $row["Password"] ?>' required='required'>
		</div>
		<div class="form-group">
			<input type='hidden' name='id' value='<?= $row["id"] ?>'>
			<input type='hidden' name='get_student_id' value='<?= $row["student_id"] ?>'>
			<input type='hidden' name='get_batch' value='<?= $row["batch"] ?>'>
			<input type='hidden' name='get_name' value='<?= $row["name"] ?>'>
			<input type='hidden' name='change_pass_only' value='true'>
			<button id="clickPassChng" class='border-0 btn-block block-main-btn btn btn-success btn-sm'> Change</button>
			<!-- <button class="border-0 btn-block block-sec-btn btn btn-danger btn-sm" data-dismiss="modal" aria-hidden="true">CLOSE </button> -->
		</div>
	</form>
<?php $connPdo = null;
} else if (isset($_GET['deleteDatabaseTable']) && isset($_GET['batch'])) {
	$batch = $_GET['batch'];
	$sql = "DROP TABLE " . $batch . "; DELETE FROM batch WHERE batch='" . $batch . "'";
	$stmt = $connPdo->prepare($sql);
	$stmt->execute();
	$connPdo = null;
} else if (isset($_GET['viewMailWindow']) && isset($_GET['batch']) && isset($_GET['email'])) {
	$batch = $_GET['batch'];
	$email = $_GET['email'];

?>

	<div class="deleteWindow">

		<form id="custom_mail_form">
			<div class="form-group">
				<label>
					Enter your details message
					<br>
					<small>Mail to: <?= $_GET['email'] ?> [<?= $_GET['batch'] ?>]</small>
				</label>
				<input type="hidden" name="sendMailCustom" value="true" id="hideMailId">
				<input type="hidden" name="email" value="<?= $email ?>" id="hideEmail">
				<input type="hidden" name="batch" value="<?= $batch ?>" id="hideBatch">
				<input type="text" class="form-control mb-2" name="mailSub" id="mailSub" placeholder="Enter your subject" required>
				<textarea type="text" rows="10" class="form-control" id="mailBody" name="mailBody" placeholder="Please type your message here..." required></textarea>
			</div>
			<div class="spinner_log">
				<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
			</div>
			<button type="button" id="executeSendMail" data-email="<?= $email ?>" data-batch="<?= $batch ?>" class="border-0 btn-block block-main-btn btn btn-success btn-sm">Send Mail</button>
		</form>
	</div>

	<script>
		$(document).ready(function() {
			$('#mailBody').summernote({
				height: 300,
				inheritPlaceholder: true,
				minHeight: null,
				maxHeight: null,
				focus: false,
				toolbar: [
					['style', ['style']],
					['font', ['bold', 'underline', 'clear']],
					['color', ['color']],
					['para', ['ul', 'ol', 'paragraph']],
					// ['table', ['table']],
					['insert', ['link']],
					['view', ['fullscreen', 'codeview']]
				]
			});
		});
	</script>

<?php } else if (isset($_GET['viewDeleteTableWindow']) && isset($_GET['batch'])) {
	$batch = $_GET['batch'];
?>

	<div class="deleteWindow">
		<div class="spinner_log">
			<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
		</div>
		<form>
			<div class="form-group">
				<label>
					Enter <b><?= $batch ?></b> to delete database table
				</label>
				<input type="text" class="form-control" id="batchInputValue" name="batch" placeholder="Enter <?= $batch ?>" required>
			</div>
			<button type="button" id="executeDeleteBatchTable" data-batch="<?= $batch ?>" class="border-0 btn-block block-main-btn btn btn-danger btn-sm">Delete <?= $batch ?></button>
		</form>
	</div>

<?php
	$connPdo = null;
} else if (isset($_GET['viewDeleteHallWindow']) && isset($_GET['id']) && isset($_GET['code'])) {
	$code = $_GET['code'];
	$id = $_GET['id'];
	$hall_row = $data->batchData("hall", $id, "id");
?>
	<div class="deleteWindow">
		<div class="spinner_log">
			<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
		</div>
		<form id="formDeleteHall">
			<div class="form-group">
				<label>
					Enter <b><?= $code ?></b> to delete hall [<?= $hall_row['name_bn'] ?>]
				</label>
				<input type="text" class="form-control" name="code" placeholder="Enter <?= $code ?>" required>
				<input type="hidden" name="deleteHallName" value="true">
				<input type="hidden" name="id" value="<?= $id ?>">
				<input type="hidden" name="code_org" value="<?= $code ?>">
			</div>
			<button type="button" id="executeDeleteHall" class="border-0 btn-block block-main-btn btn btn-danger btn-sm">Delete <?= $code ?></button>
		</form>
	</div>

<?php
	$connPdo = null;
} else if (isset($_GET['viewRoleAdminWindow']) && ($loggedin['role'] == "dev")  && isset($_GET['id']) && isset($_GET['batch'])) {
	$id = $_GET['id'];
	$batch = $_GET['batch'];
	$data = $data->batchData($batch, $id, 'id');
	$name = $data['name'];
	$student_id = $data['student_id'];

	$checkListData = json_decode($data['checklist'], true);

	// foreach ($checkListData as $key => $row){
	// 	echo $key;
	// }
?>
	<form id="checkListForm">
		<div class="card-columns">

			<?php
			foreach ($permission as $row) {
				$param = $row['param'];
			?>
				<div class="card">
					<div class="card-body" style="overflow: auto;">
						<h5 class="card-title text-default font-weight-bold"><?= ucwords($param) ?></h5>
						<hr>
						<p class="card-text">
							<?php
							// echo "<h5><b>" . ucwords($param) . "</b></h5><hr>";
							$param = $others->getCheckListDisct($param);
							foreach ($param as $nameData) {
								$mainValueCheck = trim($nameData['name']) . "-" . trim($nameData['param']);
							?>
						<div class="form-group form-check">
							<div class="pretty p-default p-curve">
								<input type="checkbox" class="form-check-input" name="<?= $mainValueCheck ?>" <?= array_key_exists($mainValueCheck, $checkListData) ? "checked" : "" ?> />
								<div class="state p-primary-o">
									<label><?= ucwords(str_replace("-", " ", $nameData['name'])) ?> (<?= ucwords($nameData['param']) ?>)</label>
								</div>
							</div>
							<?php /*
							<div class="pretty p-svg p-curve">
								<input type="checkbox" class="form-check-input" name="<?= $mainValueCheck ?>" <?= array_key_exists($mainValueCheck, $checkListData) ? "checked" : "" ?> />
								<div class="state p-success">
									<!-- svg path -->
									<svg class="svg svg-icon" viewBox="0 0 20 20">
										<path d="M7.629,14.566c0.125,0.125,0.291,0.188,0.456,0.188c0.164,0,0.329-0.062,0.456-0.188l8.219-8.221c0.252-0.252,0.252-0.659,0-0.911c-0.252-0.252-0.659-0.252-0.911,0l-7.764,7.763L4.152,9.267c-0.252-0.251-0.66-0.251-0.911,0c-0.252,0.252-0.252,0.66,0,0.911L7.629,14.566z" style="stroke: white;fill:white;"></path>
									</svg>
									<label><?= ucwords(str_replace("-", " ", $nameData['name'])) ?> (<?= ucwords($nameData['param']) ?>)</label>
								</div>
							</div>
							*/ ?>
						</div>
					<?php } ?>

					</p>
					</div>
				</div>

			<?php } ?>
		</div>

		<input type="hidden" name="checkListUpdateBatch" value="true">
		<input type="hidden" name="batch" value="<?= $batch ?>">
		<input type="hidden" name="id" value="<?= $id ?>">
		<div class="col-md-12">
			<div class="form-group">
				<button id="checkListBtn" class="border-0 btn-block block-main-btn btn btn-sm btn-default text-uppercase">
					<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span>
					<span class="MainBtnText">Save</span>
				</button>
				<!-- <button id="checkListBtn" class="border-0 btn-block block-main-btn btn btn-success btn-sm">Save</button> -->
			</div>
		</div>
	</form>
<?php
} else if (isset($_GET['viewDeleteAdminWindow']) && isset($_GET['id']) && isset($_GET['batch'])) {

	$id = $_GET['id'];
	$batch = $_GET['batch'];
	$data = $data->batchData($batch, $id, 'id');
	$name = $data['name'];
	$student_id = $data['student_id'];

?>
	<div class="deleteWindow">
		<div class="spinner_log">
			<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
		</div>
		<form id="formDeleteAdmin">
			<div class="form-group">
				<label>
					Enter <b><?= $student_id ?></b> to remove from admin
				</label>
				<input type="text" class="form-control" name="student_id" placeholder="Enter <?= $student_id ?>" required>
				<input type="hidden" name="deleteAdminName" value="true">
				<input type="hidden" name="id" value="<?= $id ?>">
				<input type="hidden" name="batch" value="<?= $batch ?>">
				<input type="hidden" name="name" value="<?= $name ?>">
				<input type="hidden" name="student_id_main" value="<?= $student_id ?>">
			</div>
			<button type="button" id="executeDeleteAdmin" class="border-0 btn-block block-main-btn btn btn-danger btn-sm">Delete <?= $student_id ?></button>
		</form>
	</div>

<?php
	$connPdo = null;
} else if (isset($_GET['userLoggedOut']) && isset($_SESSION['student_id'])) {

	$data = $data->batchData($_SESSION['batch'], $_SESSION['student_id'], 'student_id');
	$name = $data['name'];

?>
	<div class="deleteWindow">
		<div class="spinner_log">
			<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
		</div>
		<form id="formUserLogout">
			<div class="form-group text-center">
				<p>
					Hi <b><?= ucwords(strtolower($name)) ?></b>,<br>
				<h4>Are you sure want to LogOut?</h4>
				</p>
				<input type="hidden" name="userLogout" value="true">
			</div>
			<button id="btnUserLogout" class="border-0 btn-block block-main-btn btn btn-default text-uppercase">
				<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span>
				<span class="MainBtnText">Yes</span>
			</button>
		</form>
	</div>

<?php
	$connPdo = null;
} else if (isset($_GET['updateLoggedUserPass']) && $_SESSION['student_id']) { ?>

	<form id="userLoggedPassForm">
		<div class="form-group">
			<label>
				Current Password
			</label>
			<input type="password" class="form-control" placeholder="Current Password" name="pass" class="form-control mb" required>
		</div>
		<div class="form-group">
			<label>
				New Password <small>(Please enter password carefully)</small>
			</label>
			<input type="text" class="form-control" placeholder="New Password" name="newpass" class="form-control mb" required>
		</div>
		<div class="form-group">
			<label>
				Confirm New Password
			</label>
			<input type="text" class="form-control" placeholder="Confirm New Password" name="confirmpass" class="form-control mb" required>
		</div>
		<input type="hidden" name="userLoggedPassUpdate" value="true">
		<div class="form-group">
			<button id="userLoggedPassBtn" class="border-0 btn-block block-main-btn btn btn-success text-uppercase">
				<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span>
				<span class="MainBtnText">Save</span>
			</button>
			<!-- <button class="border-0 btn-block block-main-btn btn btn-success btn-sm" id="userLoggedPassBtn">Save</button> -->
		</div>
	</form>

<?php
} else if (isset($_GET['updateLoggedUserPhoto']) && $_SESSION['student_id']) { ?>

	<div class="photo-change">
		<div class="img-view">
			<?php
			$photo = $loggedin['photo'];
			if (empty($photo)) { ?> <img src="ais-assets/icon/demo.png" width="100px" id="profile-img-tag-pro">
			<?php	} else { ?> <img src="image/<?php echo $loggedin['photo']; ?>" width="100px" id="profile-img-tag-pro">
			<?php	}    ?>
		</div>
		<br>
		<div class="img-input">
			<!-- <form method="POST" onSubmit="return Validate();" action="usersloggedin.php" enctype="multipart/form-data">  -->
			<form id="userLoggedPhotoForm" onSubmit="return Validate();">
				<span id="error_pro" style="color: red;"></span>
				<div class="form-group">
					<input class="choose-file form-control" type="file" name="image" onchange="loadPro(event)" id="image_pro" required>
				</div>
				<input type="hidden" name="changePhoto" value="myOwnPhoto">
				<div class="form-group">
					<!-- <button type="submit" onclick="return confirm('Do you want to change photo?')" class="border-0 btn-block block-main-btn btn btn-success btn-sm ">Save</button> -->
					<button id="userLoggedPhotoBtn" class="border-0 btn-block block-main-btn btn btn-success text-uppercase">
						<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span>
						<span class="MainBtnText">Save</span>
					</button>
					<!-- <button id="userLoggedPhotoBtn" class="border-0 btn-block block-main-btn btn btn-success btn-sm ">Save</button> -->
				</div>
			</form>
		</div>
	</div>
<?php

} else if (isset($_GET['getMyOwnPassResetRequest']) && !isset($_SESSION['student_id'])) { ?>

	<form id="reset_pass_req_form">
		<div class="form-group">
			<label>
				Batch
			</label>
			<?php include 'batch.php'; ?>
		</div>
		<div class="form-group">
			<label>
				Enter your email address
			</label>
			<input class="form-control" type="email" name="email" placeholder="abc@email.com" required>
		</div>
		<input type="hidden" name="get_pass_reset_request" value="true">
		<div class="form-group">
			<button id="getPassReqBtn" class="border-0 btn-block block-main-btn btn btn-success text-uppercase">
				<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span>
				<span class="MainBtnText">Send Link</span>
			</button>
		</div>
	</form>

<?php
} else if (isset($_GET['getMyOwnRequest']) && !isset($_SESSION['student_id'])) { ?>

	<form id="getAddReqForm">
		<div class="form-group">
			<label class="label" for="login">Batch</label>
			<?php include 'batch.php'; ?>
		</div>
		<div class="form-group">
			<label class="label">Student ID</label>
			<input class="form-control" type="tel" inputmode="numeric" pattern="[0-9]*" id="login" name="student_id" placeholder="e.g. 1610000000" />
		</div>
		<div class="form-group">
			<label class="label">Enter your email address</label>
			<input class="form-control" type="email" id="email" name="email" placeholder="abc@email.com" />
		</div>
		<input type="hidden" name="getAddInfoReq" value="true">
		<div class="form-group">
			<small>N.B. After clicking this button you will receive a link in your mail to update your information.</small>
			<button id="getAddReqBtn" class="mt-3 border-0 btn-block block-main-btn btn btn-success text-uppercase">
				<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span>
				<span class="MainBtnText">GET REQUEST</span>
			</button>
		</div>
	</form>

<?php
} else if (isset($_GET['AddNewStaffInfo']) && isset($_SESSION['student_id']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')) { ?>

	<form onSubmit="return Validate();" id="addNewStaffForm">
		<div class=" text-center mb-4">
			<img src="ais-assets/icon/demo.png" width="100px" id="profile-img-tag">
		</div>
		<div class="img-input">

			<div class="form-group">
				<span id="errorName5" style="color: red;"></span>
				<label>Profile Photo</label>

				<input class="form-control" type="file" name="image" onchange="loadFile(event)" id="image">
			</div>
		</div>

		<div class="row">
			<div class="col-md-12">
				<div class="form-group">
					<label>Name</label>
					<input type="text" name="name" value="<?php echo $_POST['name']; ?>" class="form-control" required>
				</div>
			</div>
			<div class="col-md-12">
				<div class="form-group">
					<label>Designation</label>
					<input type="text" name="designation" value="<?php echo $_POST['designation']; ?>" class="form-control">
				</div>
			</div>
			<div class="col-md-12">
				<div class="form-group">
					<label>
						Facebook Link
					</label>
					<input type="url" class="form-control" name="fb_id" placeholder="Facebook Link" value="<?php echo  $_POST['fb_id']; ?>">
				</div>
			</div>
			<div class="col-md-12">
				<div class="form-group">
					<label>Phone</label>
					<input type="text" name="phone" value="<?php echo  $_POST['phone']; ?>" class="form-control" required>
				</div>
			</div>
			<div class="col-md-12">
				<div class="form-group">
					<label>Email</label>
					<input type="text" name="email" value="<?php echo  $_POST['email']; ?>" class="form-control">
				</div>
			</div>
			<div class="col-md-12">
				<div class="form-group">
					<label>Address</label>
					<textarea type="text" rows="5" name="per_addr" class="form-control" placeholder="Address..." value=""></textarea>
				</div>
			</div>
			<input type="hidden" name="newStaffInfoAdd" value="true">
			<div class="col-md-12">
				<div class="form-group">
					<button id="addNewStaffBtn" class="border-0 btn-block block-main-btn btn btn-success btn-sm">Add</button>
				</div>
			</div>
		</div>
	</form>

<?php
} else if (isset($_GET['AddNewTeachersInfo']) && isset($_SESSION['student_id']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')) { ?>

	<form onSubmit="return Validate();" id="addNewTeacherForm">
		<div class=" text-center mb-4">
			<img src="ais-assets/icon/demo.png" width="100px" id="profile-img-tag">
		</div>
		<div class="img-input">
			<div class="form-group">
				<span id="errorName5" style="color: red;"></span>
				<label>Profile Photo</label>
				<input class="form-control" type="file" name="image" onchange="loadFile(event)" id="image">
			</div>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="form-group">
					<label>Name</label>
					<input type="text" name="name" value="<?php echo $_POST['name']; ?>" class="form-control" required>
				</div>
			</div>
			<div class="col-md-12">
				<div class="form-group">
					<label>Designation</label>
					<input type="text" name="designation" value="<?php echo $_POST['designation']; ?>" class="form-control" required>
				</div>
			</div>
			<div class="col-md-12">
				<div class="form-group">
					<label>
						Facebook Link
					</label>
					<input type="url" class="form-control" name="fb_id" placeholder="Facebook Link" value="<?php echo  $_POST['fb_id']; ?>">
				</div>
			</div>

			<div class="col-md-12">
				<div class="form-group">
					<label>Educaion</label>
					<textarea rows="5" type="text" name="edu" class="form-control" required><?php echo  $_POST['edu']; ?> </textarea>
				</div>
			</div>
			<div class="col-md-12">
				<div class="form-group">
					<label>Phone</label>
					<input type="text" name="phone" value="<?php echo  $_POST['phone']; ?>" class="form-control" required>
				</div>
			</div>
			<div class="col-md-12">
				<div class="form-group">
					<label>Email</label>
					<input type="text" name="email" value="<?php echo  $_POST['email']; ?>" class="form-control" required>
				</div>
			</div>
			<div class="col-md-12">
				<div class="form-group">
					<label>Address</label>
					<textarea type="text" rows="5" name="per_addr" class="form-control" placeholder="Address..." value="" required></textarea>
				</div>
			</div>
			<input type="hidden" name="newTeacherInfoAdd" value="true">
			<div class="col-md-12">
				<div class="form-group">
					<button id="addNewTeacherBtn" class="border-0 btn-block block-main-btn btn btn-success btn-sm">Add</button>
				</div>
			</div>
		</div>

	</form>

<?php
} else if (isset($_GET['addBatchFriends']) && isset($_SESSION['student_id']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')) { ?>

	<form id="add_request_form">
		<div class="form-group">
			<label class="label">Student ID</label>
			<input class="form-control" type="tel" inputmode="numeric" pattern="[0-9]*" id="login" name="student_id" placeholder="e.g. 1610000000" />
		</div>
		<div class="form-group">
			<label class="label">Enter your friend's email </label>
			<input class="form-control" type="email" id="email" name="email" placeholder="abc@email.com" />
		</div>
		<input type="hidden" name="batch" value="<?= $loggedin['batch'] ?>">
		<input type="hidden" name="session" value="<?= $loggedin['session'] ?>">
		<input type="hidden" name="send_add_info_req" value="true">

		<div class="form-group">
			<button id="sendAddReqBtn" class="border-0 btn-block block-main-btn btn btn-success text-uppercase">
				<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span>
				<span class="MainBtnText">SEND REQUEST</span>
			</button>
		</div>
	</form>

<?php
} else if (isset($_GET['viewSqlRawData']) && isset($_SESSION['student_id']) && $loggedin['role'] == 'dev') { ?>

	<div class="spinner_log">
		<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
	</div>

<?php
	$path = "./backup/log/";
	$file = $_GET['file'];
	ob_start();
	readgzfile($path . $file);
	ob_end_flush();

	// $data = gzfile($path.$file);
	// $data = implode($data);
	// echo $data;

} else if (isset($_GET['updateLoggedUserInfo']) && isset($_SESSION['student_id'])) {

	if (($loggedin['frnds'] == '1') && ($batch == '19th')) {
		$student_id = $loggedin['student_id'];
		$sql = "SELECT 19th.student_id, 19th.name, 19th.phone,19th.photo,19th.father_name,19th.blood,19th.birth,19th.address,19th.district,19th.address_bangla, 19th.name_bangla, 19th.email, iconic19.prefer,iconic19.id, iconic19.details, iconic19.father_phone FROM 19th INNER JOIN  iconic19 ON {$student_id} = iconic19.student_id WHERE 19th.batch = '19th' AND 19th.frnds = '1'";
		$stmt = $connPdo->prepare($sql);
		$stmt->execute();
		$loggedin_frnds = $stmt->fetch();

		$navItem = ' <ul class="nav nav-pills" role="tablist">
			<li class="nav-item">
			<a class="nav-link active" data-toggle="pill" href="#myPro">My Profile Info</a>
			</li>
			<li class="nav-item">
				<a class="nav-link" data-toggle="pill" href="#myPersonal">My Details Info</a>
			</li>
		</ul>';
	}
?>
	<?= $navItem ?>
	<!-- Tab panes -->
	<div class="tab-content">
		<div id="myPro" class="tab-pane active">
			<!-- <h5>My Profile Info</h5> -->
			<p>
			<form id="userLoggedInfoForm">
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label>
								Student ID
							</label>
							<input type="tel" class="form-control" name="student_id" placeholder="Student ID" value="<?php echo $loggedin['student_id']; ?>" maxlength="10" readonly>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>
								Profile Visibility
							</label>
							<select class="form-control" name="show" disabled="disabled">
								<option class="text-danger" value="0" <?php echo $loggedin['showing'] == '0' ? ' selected="selected"' : ''; ?>>Private</option>
								<option class="text-success" value="1" <?php echo $loggedin['showing'] == '1' ? ' selected="selected"' : ''; ?>>Public</option>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>
								Name (English)
							</label>
							<input type="text" class="form-control" name="name" placeholder="Name (English)" value="<?php echo $loggedin['name']; ?>" required>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>
								Name (Bangla)
							</label>
							<input type="text" class="form-control" name="name_bangla" placeholder="Name (Bangla)" value="<?php echo $loggedin['name_bangla']; ?>" required>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>
								Birth Day
							</label>
							<input type="date" class="form-control" name="birth" placeholder="Birth Day" value="<?php echo $loggedin['birth']; ?>" required>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>
								Father Name
							</label>
							<input type="text" class="form-control" name="father_name" placeholder="Father Name" value="<?php echo $loggedin['father_name']; ?>" required>
						</div>
					</div>
					<div class="col-md-12">
						<div class="form-group">
							<label>
								Facebook Link
							</label>
							<input type="url" class="form-control" name="fb_id" placeholder="Facebook Link" value="<?php echo $loggedin['fb_id']; ?>">
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>
								Blood Group
							</label>
							<select name="blood" class="custom-select" required>
								<option value="">Select your blood group</option>
								<option value="A+" <?php echo $loggedin['blood'] == 'A+' ? ' selected="selected"' : ''; ?>>A+</option>
								<option value="A-" <?php echo $loggedin['blood'] == 'A-' ? ' selected="selected"' : ''; ?>>A-</option>
								<option value="AB+" <?php echo $loggedin['blood'] == 'AB+' ? ' selected="selected"' : ''; ?>>AB+</option>
								<option value="AB-" <?php echo $loggedin['blood'] == 'AB-' ? ' selected="selected"' : ''; ?>>AB-</option>
								<option value="B+" <?php echo $loggedin['blood'] == 'B+' ? ' selected="selected"' : ''; ?>>B+</option>
								<option value="B-" <?php echo $loggedin['blood'] == 'B-' ? ' selected="selected"' : ''; ?>>B-</option>
								<option value="O+" <?php echo $loggedin['blood'] == 'O+' ? ' selected="selected"' : ''; ?>>O+</option>
								<option value="O-" <?php echo $loggedin['blood'] == 'O-' ? ' selected="selected"' : ''; ?>>O-</option>
							</select>
							<!--
						<input type="text" class="form-control" name="blood" placeholder="<?= _BLOOD ?>" value="<?php echo $loggedin['blood']; ?>" required> -->
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>
								Email
							</label>
							<input type="email" class="form-control" name="email" placeholder="Email" value="<?php echo $loggedin['email']; ?>" required>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>
								Mobile
							</label>
							<input type="tel" class="form-control" name="phone" placeholder="Mobile" value="<?php echo $loggedin['phone']; ?>" maxlength="11" required>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>
								District
							</label>
							<select class="form-control" data-live-search="true" data-hide-disabled="true" name="district" required>
								<option value="">Select your district</option>
								<?php
								$sql = "SELECT * FROM district ORDER BY name ASC";
								$stmt = $connPdo->prepare($sql);
								$stmt->execute();
								foreach ($stmt as $row) {
									$select = $loggedin['district'] == $row['name'] ? 'selected="selected"' : '';
									echo '<option value="' . $row['name'] . '" ' . $select . '>' . $row['name'] . '</option>';
								}
								?>
							</select>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>
								Address (Bangla)
							</label>
							<textarea rows="6" type="text" class="form-control" name="address_bangla" placeholder="Address (Bangla)" value="<?php echo $loggedin['address_bangla']; ?>" required><?php echo $loggedin['address_bangla']; ?></textarea>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label>
								Address (English)
							</label>
							<textarea rows="6" type="text" class="form-control" name="address" placeholder="Address (English)" value="<?php echo $loggedin['address']; ?>" required><?php echo $loggedin['address']; ?></textarea>
						</div>
					</div>
					<input type="hidden" name="userLoggedInfoUpdate" value="true">
					<div class="col-md-12">
						<div class="form-group">
							<button id="userLoggedInfoBtn" class="border-0 btn-block block-main-btn btn btn-success text-uppercase">
								<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span>
								<span class="MainBtnText">Save</span>
							</button>
							<!-- <button id="userLoggedInfoBtn" class="border-0 btn-block block-main-btn btn btn-success btn-sm" onclick="return confirm('Do you want to update information?')">Save</button> -->
							<!-- <a type="button" class="border-0 btn-block block-sec-btn btn btn-danger btn-sm" href="home.php">
							Cancel
						</a> -->
						</div>
					</div>
				</div>

			</form>
			</p>
		</div>
		<?php
		if (($loggedin['frnds'] == '1') && ($batch == '19th')) {
		?>
			<div id="myPersonal" class="tab-pane fade"><br>
				<!-- <h5>Only for you (Secure)</h5> -->
				<p>
				<form id="userSecureInfoForm">
					<div class="row">
						<div class="col-md-6">
							<div class="form-group">
								<label>
									Father Mobile
								</label>
								<input type="text" class="form-control" name="father_phone" placeholder="Father Mobile" value="<?php echo $loggedin_frnds['father_phone']; ?>" required>
							</div>
						</div>
						<input type="hidden" name="userLoggedSecureInfo" value="true">
						<input type="hidden" name="student_id" value="<?= $loggedin['student_id'] ?>">
						<div class="col-md-6">
							<div class="form-group">
								<label>
									Prefer Vahicle
								</label>
								<input type="text" class="form-control" name="prefer" placeholder="Prefer Vahicle" value="<?php echo $loggedin_frnds['prefer']; ?>" required>
							</div>
						</div>
						<div class="col-md-12">
							<div class="form-group">
								<label>
									Details Address
								</label>
								<textarea type="text" class="form-control" id="details_address" rows="8" name="details" placeholder="Details Address" required><?php echo $loggedin_frnds['details']; ?></textarea>
							</div>
						</div>

						<div class="col-md-12">
							<div class="form-group">
								<!-- <input type="submit" class="border-0 btn-block block-main-btn btn btn-success btn-sm" name="info_modify_details" value="Update Information" onclick="return confirm('Do you want to update information?')"> -->
								<button id="userSecureInfoBtn" class="border-0 btn-block block-main-btn btn btn-success text-uppercase">
									<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span>
									<span class="MainBtnText">Save</span>
								</button>
								<!-- <a type="button" class="border-0 btn-block block-sec-btn btn btn-danger btn-sm" href="home.php">
							Cancel
						</a> -->
							</div>
						</div>
					</div>

				</form>
				</p>
				<script>
					$(document).ready(function() {
						$('#details_address').summernote({
							height: 300,
							minHeight: null,
							maxHeight: null,
							focus: false,
							inheritPlaceholder: true,
							toolbar: [
								['style', ['style']],
								['font', ['bold', 'underline', 'clear']],
								['color', ['color']],
								['para', ['ul', 'ol', 'paragraph']],
								// ['table', ['table']],
								['insert', ['link']],
								['view', ['fullscreen', 'codeview']]
							]
						});
					});
				</script>
			</div>
		<?php } ?>
	</div>


<?php
} else if (isset($_GET['addNoticeForm'])) {
?>
	<form id="addBatchNoticeForm">
		<div class="row">
			<div class="col-md-12">
				<div class="form-group">
					<label>
						Title
					</label>
					<input type="text" class="form-control" name="title" placeholder="Title Here..." value="<?php echo $_POST['title']; ?>">
				</div>
			</div>
			<div class="col-md-12">
				<div class="form-group">
					<label>
						Message
					</label>
					<textarea rows="10" type="text" id="message_notice" class="form-control" name="message" placeholder="Write notice ..."><?php echo $_POST['message']; ?></textarea>
				</div>
			</div>
			<div class="col-md-12">
				<div class="form-group">
					<label>
						Showing Option
					</label>
					<select class="form-control" name="active">
						<option class="text-success" value="1" <?php echo $_POST['active'] == '1' ? ' selected="selected"' : ''; ?>>Public
						</option>
						<option class="text-danger" value="0" <?php echo $_POST['active'] == '0' ? ' selected="selected"' : ''; ?>>Private
						</option>

					</select>
				</div>
			</div>
			<input type="hidden" value="true" name="add_batch_notice">
			<input type="hidden" value="<?= $loggedin['batch'] ?>" name="batch">
			<div class="col-md-12">
				<div class="form-group">
					<button id="addBatchNoticeBtn" class="border-0 btn-block block-main-btn btn btn-success btn-sm">Add Notice</button>
				</div>
			</div>
		</div>
	</form>
<?php
	$connPdo = null;
} else if (isset($_GET['openStmtFileWindow']) && isset($_GET['id']) && isset($_SESSION['student_id'])) {

	$id = $_GET['id'];
	$data = $data->batchData("statement", $id, "id");
	$file_url = "/files/" . $data['file'] . "";

	echo "<iframe id='iframe_view_file' height='100%' width='100%' src='web/viewer.html?file=" . $file_url . "' style='border:none;'></iframe>";
} else if (isset($_GET['openFileViewWindow']) && isset($_GET['id']) && isset($_SESSION['student_id'])) {
	$id = $_GET['id'];
	$sql = "SELECT * FROM learning WHERE id=$id";
	$stmt = $connPdo->prepare($sql);
	$stmt->execute();

	$row = $stmt->fetch();

	$file_url = "/files/" . $row['file_name'] . "";

	$newCount = $row['download'] + 1;
	$updateQuery = "UPDATE learning SET download='" . $newCount . "' WHERE id=" . $id;
	$stmtu = $connPdo->prepare($updateQuery);
	$stmtu->execute();
	if ($stmtu->rowCount()) {
		if (in_array($row['ext'], ['pdf', 'PDF'], true)) {
			echo "<iframe id='iframe_view_file' height='100%' width='100%' src='web/viewer.html?file=" . $file_url . "' style='border:none;'></iframe>";
		} else {
			if (!$row['link'] == 1 && $_GET['download'] == "yes") {
				echo "<iframe id='iframe_view_file' height='100%' width='100%' src='" . $http . "://" . $_SERVER['HTTP_HOST'] . $file_url . "' style='border:none;'></iframe>";
			} elseif (!$row['link'] == 1) {
				echo "<iframe id='iframe_view_file' height='100%' width='100%' src='https://docs.google.com/gview?embedded=true&url=" . $_SERVER['HTTP_HOST'] . $file_url . "' style='border:none;'></iframe>";
			} else {
				echo "<iframe id='iframe_view_file' height='100%' width='100%' src='" . $row['refer_link'] . "' style='border:none;'></iframe>";
			}
		}
	}
} else if (isset($_GET['addFileForm'])) {
	$id = $_GET['id'];
?>
	<form id="uploadFileForm" onSubmit="return Validatefile();">
		<input class="form-control" type="hidden" name="only_add_files_info" value="true">

		<div class="row">
			<div class="col-md-12">
				<div class="form-group">
					<label>File Name </label>
					<input class="form-control" placeholder="Enter file name..." type="text" name="title">
				</div>
			</div>
			<div class="col-md-12">
				<div class="form-group">
					<label>Course Name</label>
					<select class="custom-select" id="files_course_select" name="course_code">
						<option value="">Choose Course Name</option>
						<?php
						foreach ($courseList as $row) { ?>
							<option value="<?php echo $row['course_code']; ?>**<?php echo $row['course_name']; ?>"><?php echo $row['course_name']; ?> (<?php echo $row['course_code']; ?>)</option>
						<?php } ?>
						<!--<option value="add_new">Add New</option> -->
					</select>
				</div>
			</div>
			<div class="col-md-6" id="old_cat">
				<div class="form-group">
					<label>Files Category</label>
					<select class="custom-select" id="files_cat_select" name="cat">
						<option value="">Choose file category</option>
						<?php
						$sql = "SELECT DISTINCT(cat) FROM learning WHERE cat != '' ORDER BY cat";

						$stmt = $connPdo->prepare($sql);
						$stmt->execute();

						foreach ($stmt as $row) { ?>
							<option value="<?php echo $row['cat']; ?>">
								<?php echo str_replace('-', ' ', $row['cat']); ?></option>
						<?php } 	?>
						<option value="add_new">Add New</option>
					</select>
				</div>
			</div>
			<div class="col-md-6" id="new_cat" style="display:none;">
				<div class="form-group">
					<label>Add New Category </label>
					<input class="form-control" id="new_cat_input" type="text">
				</div>
			</div>
			<div class="col-md-6" id="old_year">
				<div class="form-group">
					<label>Recommanded Year</label>
					<select class="custom-select" id="files_year_select" name="recommanded_year">
						<option value="">Recommanded Academic Year</option>
						<?php
						$sql = "SELECT DISTINCT(recommanded_year) FROM learning WHERE recommanded_year != '' ORDER BY recommanded_year";
						$stmt = $connPdo->prepare($sql);
						$stmt->execute();

						foreach ($stmt as $row) { ?>
							<option value="<?php echo $row['recommanded_year']; ?>">
								<?php echo str_replace('-', ' ', $row['recommanded_year']); ?></option>
						<?php } ?>
						<option value="add_new">Add New</option>
					</select>
				</div>
			</div>
			<div class="col-md-6" id="new_year" style="display:none;">
				<div class="form-group">
					<label>Add New Year Semester </label>
					<input class="form-control" type="text" id="new_year_input">
				</div>
			</div>

			<div class="col-md-6">
				<div class="form-group">
					<label>Uplaod type</label>
					<select id="selectType" name="type" class="form-control">
						<option value="">Choose upload type</option>
						<option value="file">File</option>
						<option value="file_link">Link</option>
					</select>
				</div>
			</div>

			<div class="col-md-12" id="file_link_upload" style="display:none;">
				<div class="form-group">
					<label>File link</label>
					<textarea rows="6" placeholder="Enter valid file link..." class="form-control" type="url" id="file_link_upload_input" name="refer_link"></textarea>
				</div>
			</div>
			<div class="col-md-6" id="file_upload" style="display:none;">

				<div class="form-group">
					<label>File upload </label>
					<input type="file" class="form-control" name="file" id="file">
				</div>

			</div>
			<div class="col-md-12">
				<div class="form-group">
					<span id="errorName5" style="color: red;"></span>
				</div>
			</div>


			<div class="col-md-12">
				<div class="form-group">
					<button type="submit" id="uploadFileBtn" class="border-0 btn-block block-main-btn btn btn-success text-uppercase">
						<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span>
						<span class="MainBtnText">Upload</span>
					</button>
				</div>
			</div>
		</div>
	</form>
	<script>
		fileChooseOpt();
	</script>

<?php
	$connPdo = null;
} else if (isset($_GET['megaMenuData'])) {

?>
	<div class="row">
		<?php
		foreach ($megaMenu as $menu) {	?>
			<div class="col-md-3 mb-4">
				<div class="col-megamenu">
					<h6 class="title"><?= $menu['category'] ?></h6>
					<ul class="list-unstyled">
						<?php
						$MegaMenuCat = $others->getMegaMenuCat($menu['category']);
						foreach ($MegaMenuCat as $sub_menu) {
						?>
							<li><a onclick="window.open(this.href, '<?= $sub_menu['title'] ?>', 'width=600, height=600, left=24, top=24, scrollbars, resizable'); return false;" rel="nofollow" target="_blank" href="<?= $sub_menu['link'] ?>"><?= $sub_menu['title'] ?></a></li>
						<?php } ?>
					</ul>
				</div> <!-- col-megamenu.// -->
			</div><!-- end col-3 -->
		<?php
		}
		// } 
		// else {
		// 	echo '<div class="text-center text-danger">No Links available.</div>';
		// } 
		?>
	</div>
	<?php
	$connPdo = null;
} else if (isset($_GET['courseListAll'])) {
	foreach ($course_year as $course_year) { ?>
		<div class="course_more_view_year course_info_view item_view_nav" data-year="<?= $course_year['year'] ?>" id="course_view_year">
			<div class="mobile_nav_content_icon">
				<i class="mdi mdi-calendar-check-outline"></i>
			</div>
			<div class="mobile_nav_content_middle">
				<div class="middle_title">
					<?= $course_year['year'] ?>
				</div>
				<div class="middle_text_hints">
					Click here to view <?= $course_year['year'] ?> courses.
				</div>
			</div>
			<div class="mobile_nav_content_icon_last">
				<i class="mdi mdi-chevron-right"></i>
			</div>
		</div>
	<?php }
} else if (isset($_GET['exploreMenu'])) {
	?>
	<?php
	$batch = $loggedin['batch'];
	$sql = "SELECT COUNT(*) As nth_m FROM {$batch} WHERE active ='1'";
	$stmt = $connPdo->prepare($sql);
	$stmt->execute();
	$numRows = $stmt->fetchColumn();
	$nth_m = $numRows;

	$sql = "SELECT COUNT(*) As nth_tt FROM teacher";
	$stmt = $connPdo->prepare($sql);
	$stmt->execute();
	$numRows = $stmt->fetchColumn();
	$nth_tt = $numRows;

	$sql = "SELECT COUNT(*) As nth_tto FROM office_stuff";
	$stmt = $connPdo->prepare($sql);
	$stmt->execute();
	$numRows = $stmt->fetchColumn();
	$nth_tto = $numRows;
	?>
	<div class="modal-body" style="padding: 0 1rem;">
		<div class="explore_more_content_main">
			<div class="row special_row">
				<!-- <div class="col-sm-12 col-md-12 col-lg-12 per_batch_btn text-center" id="customize_view">
							<div class="batch_name_title">
								Customize View
							</div>
							<div class="session_name_title">
								View data as what you like
							</div>
								<div class="batch_info_count">
								00
							</div> 
					</div>	 -->

			</div>
			<script>
				$(document).ready(function() {
					$("#all_search_data").on("keyup", function() {
						var value = $(this).val().toLowerCase();
    					$('#collapseFour,#collapseOne,#collapseTwo,#collapseThree,#collapseFive').removeClass('collapse').addClass('collapse show');
						$(".card.cat,.per_batch_btn").filter(function() {
							$(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
						});
					});
				});
			</script>
			<div class="ad_search my-3">
					<div class="search_form_explore mb-2">
						<input type="search" id="all_search_data" class="form-control" placeholder="Search...">
					</div>
				<div class="accordion" id="accordionExample">
					<div class="card cat">
						<!-- <div class="card-header" id="headingThree"> -->
						<h2 class="mb-0">
							<button class="view_head_btn btn btn-default p-3 btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseFour" aria-expanded="true" aria-controls="collapseThree">
								<span class="view_head_icon"><i class="fas fa-user mr-2"></i></span>
								<span class="view_head_title">View Teachers and Staff</span>
							</button>
						</h2>
						<!-- </div> -->

						<div id="collapseFour" class="collapse show" aria-labelledby="headingThree" data-parent="#accordionExample">
							<div class="card-body">
								<div class="row">

									<div class="col-sm-6 col-md-6 col-lg-6 per_batch_btn teachers">
										<div style="cursor:pointer" onclick="location.href='dataview.php?view_teacher'">
											<div class="batch_name_title">
												Teachers
											</div>
											<div class="session_name_title">
												Browse teachers info
											</div>
											<div class="batch_info_count">
												<?= $nth_tt ?>
											</div>
										</div>
									</div>
									<div class="col-sm-6 col-md-6 col-lg-6 per_batch_btn office_stuff">
										<div style="cursor:pointer" onclick="location.href='dataview.php?view_office_stuff'">
											<div class="batch_name_title">
												Office Stuff
											</div>
											<div class="session_name_title">
												Browse office stuff info
											</div>
											<div class="batch_info_count">
												<?= $nth_tto ?>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="card cat">
						<!-- <div class="card-header" id="headingThree"> -->
						<h2 class="mb-0">
							<button class="view_head_btn btn btn-default p-3 btn-block text-left" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="true" aria-controls="collapseThree">
								<span class="view_head_icon"><i class="fas fa-users mr-2"></i></span>
								<span class="view_head_title">View By Batch</span>
							</button>
						</h2>
						<!-- </div> -->

						<div id="collapseThree" class="collapse show" aria-labelledby="headingThree" data-parent="#accordionExample">
							<div class="card-body">
								<div class="row">
									<div class="col-sm-6 col-md-6 col-lg-6 per_batch_btn my_batch">
										<div style="cursor:pointer" onclick="location.href='dataview.php?view_batch&my_batch&batch=<?= $batch ?>&session=<?= $loggedin['session'] ?>'">
											<div class="batch_name_title">
												My Batch (<?= $batch ?>)
											</div>
											<div class="session_name_title">
												Session - <?= $loggedin['session'] ?>
											</div>
											<div class="batch_info_count">
												<?= $nth_m ?>
											</div>
										</div>
									</div>
									<?php
									foreach ($batchData as $row) {
										$batch = $row['batch'];
										$sql = "SELECT COUNT(*) As nth_t FROM {$batch} WHERE active ='1' AND showing='1'";
										$stmt = $connPdo->prepare($sql);
										$stmt->execute();
										$numRows = $stmt->fetchColumn();
										$nth_t = $numRows;
										if ($loggedin['batch'] !== $batch) { ?>
											<div class="col-sm-6 col-md-6 col-lg-6 per_batch_btn">
												<div style="cursor:pointer" onclick="location.href='dataview.php?view_batch&other_batch_view&batch=<?= $row['batch'] ?>&session=<?= $row['session'] ?>'">
													<div class="batch_name_title">
														<?= $row['batch'] ?> Batch
													</div>
													<div class="session_name_title">
														Session - <?= $row['session'] ?>
													</div>
													<div class="batch_info_count">
														<?= $nth_t ?>
													</div>
												</div>
											</div>
									<?php }
									}
									$connPdo = null;
									?>
								</div>

							</div>
						</div>
					</div>
					<div class="card cat">
						<!-- <div class="card-header" id="headingOne"> -->
						<h2 class="mb-0">
							<button class="view_head_btn btn btn-default p-3 btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="false" aria-controls="collapseOne">
								<span class="view_head_icon"><i class="fas fa-tint mr-2"></i></span>
								<span class="view_head_title">View By Blood</span>
							</button>
						</h2>
						<!-- </div> -->

						<div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
							<div class="card-body">

								<div class="row">

									<?php
									foreach ($BloodList as $row) {
										$blood = $row['short_text'];
										$blood_html = urlencode($blood);
										$signBlood = ["+", "-"];
										$textBlood  = ["%2B", "%2D"];
										$newBlood = str_replace($signBlood, $textBlood, $blood_html);
										$std_dis_cnt = 0;
										foreach ($batchDataAll as $key) {
											$batch = $key['batch'];
											$std_dis_cnt  += $data->itemCountDistinct($batch, "WHERE active=1 AND blood = '" . $blood . "'");
											$total_std_cnt  += $data->itemCountDistinct($batch, "WHERE active=1 AND blood = '" . $blood . "'");
										} ?>

										<div class="col-sm-6 col-md-6 col-lg-6 per_batch_btn">
											<div style="cursor:pointer" onclick="location.href='dataview.php?view_batch&customize_data_view&batch=all_batch&blood=<?= $blood ?>'">
												<div class="batch_name_title">
													<?= $blood ?> (<?= $row['pos_neg'] ?>)
												</div>
												<div class="session_name_title">
													<?= $row['long_text'] ?>
												</div>
												<div class="batch_info_count">
													<?= $std_dis_cnt ?>
												</div>
											</div>
										</div>
									<?php
									}
									?>
								</div>

							</div>
						</div>
					</div>
					<div class="card cat">
						<!-- <div class="card-header" id="headingTwo"> -->
						<h2 class="mb-0">
							<button class="view_head_btn btn btn-default p-3 btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
								<span class="view_head_icon"><i class="fas fa-hotel mr-2"></i></span>
								<span class="view_head_title">View By Hall</span>
							</button>
						</h2>
						<!-- </div> -->
						<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionExample">
							<div class="card-body">
								<div class="row">
									<?php
									foreach ($hallNames as $row) {
										$ddate = ($row['modified'] !== '') ? date('d F, Y h:i A', strtotime($row['modified'])) : '';
										$code = $row['code'];
										$std_dis_cnt = 0;
										foreach ($batchDataAll as $key) {
											$batch = $key['batch'];
											$std_dis_cnt  += $data->itemCountDistinct($batch, "WHERE active=1 AND SUBSTRING(student_id,3,3) = '" . $code . "'");
											$std_dis_cnt_total  += $data->itemCountDistinct($batch, "WHERE active=1 AND SUBSTRING(student_id,3,3) = '" . $code . "'");
										} ?>
										<div class="col-sm-12 col-md-12 col-lg-12 per_batch_btn">
											<div style="cursor:pointer" onclick="location.href='dataview.php?view_batch&customize_data_view&batch=all_batch&hall_code=<?= $code ?>'">
												<div class="batch_name_title">
													<?= $row['name_en'] ?>
												</div>
												<div class="session_name_title">
													<?= $row['name_bn'] ?>
												</div>
												<div class="batch_info_count">
													<?= $std_dis_cnt ?>
												</div>
											</div>
										</div>

									<?php
									}
									?>
								</div>
							</div>
						</div>
					</div>
					<div class="card cat">
						<!-- <div class="card-header" id="headingTwo"> -->
						<h2 class="mb-0">
							<button class="view_head_btn btn btn-default p-3 btn-block text-left collapsed" type="button" data-toggle="collapse" data-target="#collapseFive" aria-expanded="false" aria-controls="collapseFive">
								<span class="view_head_icon"><i class="fas fa-city mr-2"></i></span>
								<span class="view_head_title">View By District</span>
							</button>
						</h2>
						<!-- </div> -->
						<div id="collapseFive" class="collapse" aria-labelledby="headingFive" data-parent="#accordionExample">
							<div class="card-body">
								<div class="row">
									<?php
									foreach ($districtAll as $row) {
										$ddate = ($row['date_upated'] !== '') ? date('d F, Y h:i A', strtotime($row['date_upated'])) : '';
                                        $dis_name = $row['name'];
                                        $std_dis_cnt = 0;
                                        foreach ($batchDataAll as $key) {
                                            $batch = $key['batch'];
                                            $std_dis_cnt  += $data->itemCountDistinct($batch, "WHERE active=1 AND district = '" . $dis_name . "'");
										} ?>
										<div class="col-sm-6 col-md-6 col-lg-6 per_batch_btn">
											<div style="cursor:pointer" onclick="location.href='dataview.php?view_batch&customize_data_view&batch=all_batch&district=<?= $dis_name ?>'">
												<div class="batch_name_title">
													<?= $row['name'] ?>
												</div>
												<div class="session_name_title">
													<?= $row['name_bn'] ?> (<?= $row['division'] ?>)
												</div>
												<div class="batch_info_count">
													<?= $std_dis_cnt ?>
												</div>
											</div>
										</div>

									<?php
									}
									?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php
	$connPdo = null;
} else if (isset($_GET['mobileNavMenu'])) {
?>
	<?php if ($detect->isMobile()) { ?>
		<div class="gallery_view item_view_nav">
			<div class="mobile_nav_content_icon">
				<i class="mdi mdi-camera-plus-outline"></i>
			</div>
			<div class="mobile_nav_content_middle" id="myModalGallery">
				<div class="middle_title">
					Add Photo
				</div>
				<div class="middle_text_hints">
					Add photo to your batch gallery.
				</div>
			</div>
			<div class="mobile_nav_content_icon_last">
				<i class="mdi mdi-chevron-right"></i>
			</div>
		</div>
		<div class="gallery_view item_view_nav">
			<div class="mobile_nav_content_icon">
				<i class="mdi mdi-image-multiple-outline"></i>
			</div>
			<div class="mobile_nav_content_middle" onclick="location.href='index_gallery.php?home_view_gallery'">
				<div class="middle_title">
					Gallery View
				</div>
				<div class="middle_text_hints">
					View your batch photo gallery.
				</div>
			</div>
			<div class="mobile_nav_content_icon_last">
				<i class="mdi mdi-chevron-right"></i>
			</div>
		</div>
		<div class="gallery_view item_view_nav">
			<div class="mobile_nav_content_icon">
				<i class="mdi mdi-camera-iris"></i>
			</div>
			<div class="mobile_nav_content_middle" onclick="location.href='index_gallery.php?my_view_gallery'">
				<div class="middle_title">
					My Gallery
				</div>
				<div class="middle_text_hints">
					Manage photo uploaded by you.
				</div>
			</div>
			<div class="mobile_nav_content_icon_last">
				<i class="mdi mdi-chevron-right"></i>
			</div>
		</div>
		<?php if (($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')) { ?>
			<div class="gallery_view item_view_nav">
				<div class="mobile_nav_content_icon">
					<i class="mdi mdi-image-edit-outline"></i>
				</div>
				<div class="mobile_nav_content_middle" onclick="location.href='index_gallery.php?admin_view_gallery'">
					<div class="middle_title">
						Admin Gallery
					</div>
					<div class="middle_text_hints">
						Manage photo uploaded by your batch.
					</div>
				</div>
				<div class="mobile_nav_content_icon_last">
					<i class="mdi mdi-chevron-right"></i>
				</div>
			</div>
		<?php } ?>
		<div class="document_view item_view_nav">
			<div class="mobile_nav_content_icon">
				<i class="mdi mdi-file-plus-outline"></i>
			</div>
			<div class="mobile_nav_content_middle" id="myModalFileUpload">
				<div class="middle_title">
					Add Document
				</div>
				<div class="middle_text_hints">
					Add documents to AIS family.
				</div>
			</div>
			<div class="mobile_nav_content_icon_last">
				<i class="mdi mdi-chevron-right"></i>
			</div>
		</div>
		<div class="document_view item_view_nav">
			<div class="mobile_nav_content_icon">
				<i class="mdi mdi-file-document-multiple-outline"></i>
			</div>
			<div class="mobile_nav_content_middle" onclick="location.href='learning.php?view_files_book&all_files'">
				<div class="middle_title">
					View Document
				</div>
				<div class="middle_text_hints">
					View all document uploaded by AIS members.
				</div>
			</div>
			<div class="mobile_nav_content_icon_last">
				<i class="mdi mdi-chevron-right"></i>
			</div>
		</div>
		<div class="explore_view item_view_nav">
			<div class="mobile_nav_content_icon">
				<i class="mdi mdi-account"></i>
			</div>
			<div class="mobile_nav_content_middle" id="view_btn_stds" data-id="<?= $loggedin['id'] ?>" data-batch="<?= $loggedin['batch'] ?>">
				<div class="middle_title">
					My Profile
				</div>
				<div class="middle_text_hints">
					View your profile information
				</div>
			</div>
			<div class="mobile_nav_content_icon_last">
				<i class="mdi mdi-chevron-right"></i>
			</div>
		</div>

		<div class="explore_view item_view_nav">
			<div class="mobile_nav_content_icon">
				<i class="mdi mdi-compass-outline"></i>
			</div>
			<div class="mobile_nav_content_middle" id="explore_moreMenu">
				<div class="middle_title">
					Explore More
				</div>
				<div class="middle_text_hints">
					View all category list
				</div>
			</div>
			<div class="mobile_nav_content_icon_last">
				<i class="mdi mdi-chevron-right"></i>
			</div>
		</div>
		<?php if (($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')) { ?>
			<div class="explore_view item_view_nav">
				<div class="mobile_nav_content_icon">
					<i class="mdi mdi-account-multiple-plus-outline"></i>
				</div>
				<div class="mobile_nav_content_middle" id="addeMailFriends">
					<div class="middle_title">
						Add Batch Friends
					</div>
					<div class="middle_text_hints">
						Add your batch batch friends if not added yet.
					</div>
				</div>
				<div class="mobile_nav_content_icon_last">
					<i class="mdi mdi-chevron-right"></i>
				</div>
			</div>
			<div class="explore_view item_view_nav">
				<div class="mobile_nav_content_icon">
					<i class="mdi mdi-account-plus-outline"></i>
				</div>
				<div class="mobile_nav_content_middle" id="addNewTeachers">
					<div class="middle_title">
						Add Teachers
					</div>
					<div class="middle_text_hints">
						Add new teachers info if not added yet.
					</div>
				</div>
				<div class="mobile_nav_content_icon_last">
					<i class="mdi mdi-chevron-right"></i>
				</div>
			</div>

			<div class="explore_view item_view_nav">
				<div class="mobile_nav_content_icon">
					<i class="mdi mdi-account-plus-outline"></i>
				</div>
				<div class="mobile_nav_content_middle" id="addNewStaff">
					<div class="middle_title">
						Add Office Stuff
					</div>
					<div class="middle_text_hints">
						Add new office stuff info if not added yet.
					</div>
				</div>
				<div class="mobile_nav_content_icon_last">
					<i class="mdi mdi-chevron-right"></i>
				</div>
			</div>

			<div class="explore_view item_view_nav">
				<div class="mobile_nav_content_icon">
					<i class="mdi mdi-bell-plus-outline"></i>
				</div>
				<div class="mobile_nav_content_middle" id="myModalNotice" data-batch="<?= $loggedin['batch'] ?>">
					<div class="middle_title">
						Add Notice
					</div>
					<div class="middle_text_hints">
						Add new notice for your batch only.
					</div>
				</div>
				<div class="mobile_nav_content_icon_last">
					<i class="mdi mdi-chevron-right"></i>
				</div>
			</div>
		<?php } ?>
		<!-- <div class="explore_view all_batch_short_link item_view_nav"></div> -->
		<!-- <div class="bd_more_view wish_birthday item_view_nav">wish_birthday</div>
   		<div class="notice_more_view notifications item_view_nav">

   		</div>
   		<div class="loggedin_more_view users_loggedin_info_view item_view_nav">Loggedin</div> -->


		<div class="more_view item_view_nav" id="course_view_title">
			<div class="mobile_nav_content_icon">
				<i class="mdi mdi-book-open-page-variant"></i>
			</div>
			<div class="mobile_nav_content_middle">
				<div class="middle_title">
					AIS Course List
				</div>
				<div class="middle_text_hints">
					Click here to view all courses name and code.
				</div>
			</div>
			<div class="mobile_nav_content_icon_last">
				<i class="mdi mdi-chevron-right"></i>
			</div>
		</div>
		<div class="more_view item_view_nav" data-date="<?= date('d F') ?>" id="birthday_view_title">
			<div class="mobile_nav_content_icon">
				<i class="mdi mdi-cake-variant"></i>
			</div>
			<div class="mobile_nav_content_middle">
				<div class="middle_title">
					Birthday
				</div>
				<div class="middle_text_hints">
					Wish your friends, brothers, sisters whose today is birthday.
				</div>
			</div>
			<div class="mobile_nav_content_icon_last">
				<i class="mdi mdi-chevron-right"></i>
			</div>
		</div>

		<?php if (($loggedin['role'] == 'dev')) { ?>
			<div class="more_view item_view_nav">
				<div class="mobile_nav_content_icon">
					<i class="mdi mdi-shield-account"></i>
				</div>
				<div class="mobile_nav_content_middle" onclick="location.href='controller.php?only_for_controller'">
					<div class="middle_title">
						Controller View
					</div>
					<div class="middle_text_hints">
						This section only for site controller.
					</div>
				</div>
				<div class="mobile_nav_content_icon_last">
					<i class="mdi mdi-chevron-right"></i>
				</div>
			</div>

			<div class="more_view item_view_nav">
				<div class="mobile_nav_content_icon">
					<i class="mdi mdi-shield-account-outline"></i>
				</div>
				<div class="mobile_nav_content_middle" onclick="window.open('only-for-me.php')">
					<div class="middle_title">
						My Admin
					</div>
					<div class="middle_text_hints">
						This section only for site master admin.
					</div>
				</div>
				<div class="mobile_nav_content_icon_last">
					<i class="mdi mdi-chevron-right"></i>
				</div>
			</div>
		<?php } ?>
		<?php if ($loggedin['frnds'] == '1') { ?>
			<div class="more_view item_view_nav">
				<div class="mobile_nav_content_icon">
					<i class="mdi mdi-heart-outline"></i>
				</div>
				<div class="mobile_nav_content_middle" onclick="location.href='my_friends.php?only_my_friends'">
					<div class="middle_title">
						My Friends
					</div>
					<div class="middle_text_hints">
						This section only for Special Friends.
					</div>
				</div>
				<div class="mobile_nav_content_icon_last">
					<i class="mdi mdi-chevron-right"></i>
				</div>
			</div>
		<?php } ?>
		<div class="more_view item_view_nav">
			<div class="mobile_nav_content_icon">
				<i class="mdi mdi-history"></i>
			</div>
			<div class="mobile_nav_content_middle" data-student_id="<?= $loggedin['student_id'] ?>" id="activity_log_nav">
				<div class="middle_title">
					My Activity Log
				</div>
				<div class="middle_text_hints">
					Every students can view their activity log.
				</div>
			</div>
			<div class="mobile_nav_content_icon_last">
				<i class="mdi mdi-chevron-right"></i>
			</div>
		</div>
		<div class="more_view item_view_nav">
			<div class="mobile_nav_content_icon">
				<i class="mdi mdi-link"></i>
			</div>
			<div class="mobile_nav_content_middle" id="important_links_all_view">
				<div class="middle_title">
					Important Links
				</div>
				<div class="middle_text_hints">
					Necessary links available here.
				</div>
			</div>
			<div class="mobile_nav_content_icon_last">
				<i class="mdi mdi-chevron-right"></i>
			</div>
		</div>
		<?php if (($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')) { ?>
			<div class="more_view item_view_nav">
				<div class="mobile_nav_content_icon">
					<i class="mdi mdi-information-outline"></i>
				</div>
				<div class="mobile_nav_content_middle" onclick="location.href='dataview.php?login_info_batch&batch=<?= $batch ?>'">
					<div class="middle_title">
						My Batch Login Info
					</div>
					<div class="middle_text_hints">
						Batch admin can view students login info.
					</div>
				</div>
				<div class="mobile_nav_content_icon_last">
					<i class="mdi mdi-chevron-right"></i>
				</div>
			</div>

			<div class="more_view item_view_nav">
				<div class="mobile_nav_content_icon">
					<i class="mdi mdi-shield-bug-outline"></i>
				</div>
				<div class="mobile_nav_content_middle" onclick="location.href='dataview.php?view_batch&inactive_view&batch=<?= $loggedin['batch'] ?>&session=<?= $loggedin['session'] ?>'">
					<div class="middle_title">
						My Batch Inactive Info
					</div>
					<div class="middle_text_hints">
						Batch admin can view inactive info.
					</div>
				</div>
				<div class="mobile_nav_content_icon_last">
					<i class="mdi mdi-chevron-right"></i>
				</div>
			</div>

			<div class="more_view item_view_nav">
				<div class="mobile_nav_content_icon">
					<i class="mdi mdi-bell-ring-outline"></i>
				</div>
				<div class="mobile_nav_content_middle" onclick="location.href='dataview.php?see_all_notice&batch=<?= $batch ?>'">
					<div class="middle_title">
						All Notice
					</div>
					<div class="middle_text_hints">
						View all notice from your batch.
					</div>
				</div>
				<div class="mobile_nav_content_icon_last">
					<i class="mdi mdi-chevron-right"></i>
				</div>
			</div>

			<div class="more_view item_view_nav">
				<div class="mobile_nav_content_icon">
					<i class="mdi mdi-cog-outline"></i>
				</div>
				<div class="mobile_nav_content_middle" onclick="location.href='others.php?database_settings'">
					<div class="middle_title">
						Settings
					</div>
					<div class="middle_text_hints">
						Settings related to your batch profile.
					</div>
				</div>
				<div class="mobile_nav_content_icon_last">
					<i class="mdi mdi-chevron-right"></i>
				</div>
			</div>

		<?php } ?>
		<div class="more_view item_view_nav">
			<div class="mobile_nav_content_icon">
				<i class="mdi mdi-help-circle-outline"></i>
			</div>
			<div class="mobile_nav_content_middle" onclick="location.href='others.php?faq_view'">
				<div class="middle_title">
					FAQs
				</div>
				<div class="middle_text_hints">
					Know more details about database.
				</div>
			</div>
			<div class="mobile_nav_content_icon_last">
				<i class="mdi mdi-chevron-right"></i>
			</div>
		</div>

		<div class="link_more_view important_links item_view_nav"></div>
		<div class="about_more_view about_database item_view_nav"></div>
		<div class="log_more_view activity_log item_view_nav">
			<div class="spinner_log">
				<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
			</div>
		</div>

		<div class="more_view item_view_nav">
			<div class="mobile_nav_content_icon">
				<i class="mdi mdi-message-text-outline"></i>
			</div>
			<div class="mobile_nav_content_middle" onclick="location.href='others.php?report_info'">
				<div class="middle_title">
					Report
				</div>
				<div class="middle_text_hints">
					Report any issue to your batch admin.
				</div>
			</div>
			<div class="mobile_nav_content_icon_last">
				<i class="mdi mdi-chevron-right"></i>
			</div>
		</div>

		<div class="more_view item_view_nav" style="margin-bottom:300px">
			<div class="mobile_nav_content_icon">
				<i class="mdi mdi-information-variant"></i>
			</div>
			<div class="mobile_nav_content_middle" id="about_database">
				<div class="middle_title">
					About
				</div>
				<div class="middle_text_hints">
					More information about database.
				</div>
			</div>
			<div class="mobile_nav_content_icon_last">
				<i class="mdi mdi-chevron-right"></i>
			</div>


		</div>
	<?php } ?>

<?php
	$connPdo = null;
} else if (isset($_GET['birthDayList'])) {
?>
	<div class="birth_more_all">
		<div class="upcoming_title">
			Today (<?= sizeof($birth_data) ?>)
		</div>
		<div class="today_birthday_class">
			<?php
			if (sizeof($birth_data) !== 0) {
				foreach ($birth_data as $birth_data) {
					$photo = (!empty($birth_data['photo'])) ? '<img class="dropbtn" src="image/' . $birth_data['photo'] . '">' : '<i class="mdi mdi-cake-variant"></i>';
			?>
					<div class="bd_wish_more_view item_view_nav" data-name="<?= ucwords(strtolower($birth_data['name'])) ?>" data-studentid="<?= $birth_data['student_id'] ?>" data-id="<?= $birth_data['id'] ?>" data-batch="<?= $birth_data['batch'] ?>" id="birthday_view_item">
						<div class="mobile_nav_content_icon">
							<div class="pro_bd">
								<?= $photo ?>
							</div>
						</div>
						<div class="mobile_nav_content_middle">
							<div class="middle_title">
								<?= ucwords(strtolower($birth_data['name'])) ?>
								<small>(<?= $birth_data['batch'] ?>)</small>
							</div>
							<div class="middle_text_hints">
								<?= date('d F, Y', strtotime($birth_data['birth'])) ?>
							</div>
						</div>
						<div class="mobile_nav_content_icon_last">
							<i class="mdi mdi-chevron-right"></i>
						</div>
					</div>

			<?php }
			} else {
				echo "<div class='empty_birth_today'>Today is no one's birthday.</div>";
			} ?>
		</div>


		<div class="upcoming_title">
			This Month (<?= sizeof($birth_coming) ?>)
		</div>
		<div class="coming_birthday_class">
			<?php
			foreach ($birth_coming as $birth_coming) {
				$photo = (!empty($birth_coming['photo'])) ? '<img class="dropbtn" src="image/' . $birth_coming['photo'] . '">' : '<i class="mdi mdi-cake-variant"></i>';
			?>
				<div class="bd_wish_more_view item_view_nav" data-name="<?= ucwords(strtolower($birth_coming['name'])) ?>" data-studentid="<?= $birth_coming['student_id'] ?>" data-id="<?= $birth_coming['id'] ?>" data-batch="<?= $birth_coming['batch'] ?>" id="birthday_view_item">
					<div class="mobile_nav_content_icon">
						<div class="pro_bd">
							<?= $photo ?>
						</div>
					</div>
					<div class="mobile_nav_content_middle">
						<div class="middle_title">
							<?= ucwords(strtolower($birth_coming['name'])) ?>
							<small>(<?= $birth_coming['batch'] ?>)</small>
						</div>
						<div class="middle_text_hints">
							<?= date('d F, Y', strtotime($birth_coming['birth'])) ?>
						</div>
					</div>
					<div class="mobile_nav_content_icon_last">
						<i class="mdi mdi-chevron-right"></i>
					</div>
				</div>

			<?php } ?>

		</div>
	</div>
<?php
	$connPdo = null;
} else if (isset($_GET['userLoggedInInfo'])) {
?>
	<div class="loggedin_div">
		<!-- <p id="view_btn_stds" data-id="<?= $loggedin['id'] ?>" data-batch="<?= $loggedin['batch'] ?>" class="proImageView">
					<img src="image/<?= $loggedin['photo'] ?>">
					</p> -->
		<p><b>Name (বাংলা)<br> </b>
			<?= $loggedin['name_bangla'] ?>
		</p>
		<p><b>Student ID<br> </b>
			<?= $loggedin['student_id'] ?>
		</p>
		<p><b>Email<br> </b>
			<?= $loggedin['email'] ?>
		</p>
		<p><b>Mobile <br></b>
			<?= $loggedin['phone'] ?>
		</p>
		<p><b>Blood Group <br></b>
			<?= $loggedin['blood'] ?>
		</p>
		<p><b>District <br></b>
			<?= $loggedin['district'] ?>
		</p>
	</div>

	<div class="row-c">
		<div class="col-md-6-c">
			<a href="#" id="userLoggedOut" class="logout border-right"> <i class="fas fa-sign-out-alt"></i></a>
		</div>
		<!-- usersloggedin.php?users_info_modify -->
		<div class="col-md-6-c"> <a href="#" id="updateUserInfoLogged" class="user-edit  border-right"><i class='fas fa-edit'></i></a> </div>
		<div class="col-md-6-c"> <a href="#" id="updateUserPhotoLogged" class="user-photo  border-right"><i class='fas fa-camera'></i></a> </div>
		<div class="col-md-6-c"> <a href="#" id="updateUserPassLogged" class="user-pass "><i class='fas fa-unlock'></i></a> </div>
	</div>

<?php
	$connPdo = null;
} else if (isset($_GET['addGalleryForm'])) {
?>
	<form action="" onSubmit="return Validategallery();" method="post" enctype="multipart/form-data">
		<div class="upload">
			<div class="form-group img-show">

				<img src="ais-assets/icon/demo_g.png" id="profile-img-tag" class="upload_gallery_img">
				<div class="form-group">
					<input type="file" name="image[]" onchange="loadFile(event)" id="image" required multiple><br>
					<span id="errorName5" style="color: red;"></span>
				</div>
			</div>
			<div class="form-group">
				<label>Image capture place</label>
				<input class="form-control" type="text" name="image_place" required>
			</div>

			<div class="form-group">
				<label>Image capture date</label>
				<input class="form-control" type="text" name="image_date" required>
			</div>

			<div class="form-group">
				<label>Image caption</label>
				<input class="form-control" type="text" name="image_description" required>
			</div>

			<div class="form-group">
				<label>Photo Album</label>
				<select class="custom-select" id="album_select" name="album" required="">
					<option value="">Choose photo album</option>
					<?php
					foreach ($getAlbum as $row) { ?>
						<option value="<?= $row['album'] ?>"><?= $row['album'] ?></option>
					<?php } ?>
					<option value="add_new">Add New</option>
				</select>
			</div>
			<div class="form-group" id="new_album" style="display:none;">
				<label>Add New Album </label>
				<input class="form-control" id="new_album_input" type="text">
			</div>

		</div>
		<div class="form-group">
			<button type="submit" name="upload_gallery" class="border-0 btn-block block-main-btn btn btn-success btn-sm">Upload</button>
		</div>
	</form>
	<script>
		galleryChooseOpt();
		Validategallery()
	</script>
<?php
	$connPdo = null;
} else if (isset($_GET['mybatchlogin']) && isset($_GET['logininfoid'])) {

	$login_id = $_GET['logininfoid'];
	$sql = "SELECT {$batch}.name, {$batch}.photo, login.student_id,login.region, login.city, login.capital, login.country, login.isp, login.latitude, login.longitude, login.batch, login.details, login.device, login.time, login.http, login.action, login.ip FROM login  INNER JOIN
		{$batch} ON login.student_id = {$batch}.student_id WHERE login.batch ='{$batch}' AND login.id='{$login_id}' ORDER BY login.id DESC";

	$stmt = $connPdo->prepare($sql);
	$stmt->execute();
	$row = $stmt->fetch();
	$connPdo = null;
?>

	<table class="table">
		<tr>
			<td align="left"><b>Name: </b><?= $row['name'] ?></td>
			<td align="center"><b>Student ID: </b><?= $row['student_id'] ?></td>
			<td align="center"><b>Batch: </b><?= $row['batch'] ?></td>
			<td align="right"><b>Time: </b><?= $row['time'] ?></td>
		</tr>
		<!-- <tr>
			<td align="left"><b>Region: </b><?= $row['region'] ?></td>
			<td align="left"><b>City: </b><?= $row['city'] ?></td>
			<td align="left"><b>Capital: </b><?= $row['capital'] ?></td>
			<td align="left"><b>Country: </b><?= $row['country'] ?></td>
		</tr> -->
		<tr>
			<td align="left"><b>Device: </b><?= $row['device'] ?></td>
			<td align="center"><b>IP: </b><?= $row['ip'] ?></td>
			<!-- <td align="center"><b>ISP: </b><?= $row['isp'] ?></td> -->
			<td colspan="2" align="center"><b>URL: </b><?= $row['http'] ?></td>
		</tr>
		<!-- <tr>
			<td align="center" colspan="4"><a target="_blank" href="https://www.google.com/maps/place/<?= $row['latitude'] ?>+<?= $row['longitude'] ?>">Google Map Location</a></td>
		</tr> -->
		<tr>
			<td align="center" colspan="4"><?= $row['details'] ?></td>
		</tr>
	</table>

<?php
	$connPdo = null;
} /* else if (isset($_GET['customize_view'])) {  ?>

	<form class="download_data" action="dataview.php" id="download_form_data">
		<input type="hidden" name="view_batch">
		<input type="hidden" name="customize_data_view">
		<div class="form-group">
			<label>Select Batch</label>
			<select class="custom-select" name="batch" required>
				<option value="">Select Batch</option>
				<?php
				foreach ($batchData as $row) {
					echo '<option value="' . $row['batch'] . '">' . $row['batch'] . '</option>';
				}
				?>
			</select>
		</div>
		<div class="form-group">
			<label>Blood Group</label>
			<select name="blood" class="custom-select">
				<option value="">Select blood group</option>
				<option value="A+" <?php echo $row['blood'] == 'A+' ? ' selected="selected"' : ''; ?>>A+</option>
				<option value="A-" <?php echo $row['blood'] == 'A-' ? ' selected="selected"' : ''; ?>>A-</option>
				<option value="AB+" <?php echo $row['blood'] == 'AB+' ? ' selected="selected"' : ''; ?>>AB+</option>
				<option value="AB-" <?php echo $row['blood'] == 'AB-' ? ' selected="selected"' : ''; ?>>AB-</option>
				<option value="B+" <?php echo $row['blood'] == 'B+' ? ' selected="selected"' : ''; ?>>B+</option>
				<option value="B-" <?php echo $row['blood'] == 'B-' ? ' selected="selected"' : ''; ?>>B-</option>
				<option value="O+" <?php echo $row['blood'] == 'O+' ? ' selected="selected"' : ''; ?>>O+</option>
				<option value="O-" <?php echo $row['blood'] == 'O-' ? ' selected="selected"' : ''; ?>>O-</option>
			</select>
		</div>

		<div class="form-group">
			<label>Hall Name </label>
			<select class="custom-select" name="hall_code">
				<option value="">Choose Hall</option>
				<option value="Bangabandhu_Sheikh_Mujibur_Rahman_Hall"> Bangabandhu Sheikh Mujibur Rahman Hall – বঙ্গবন্ধু শেখ মুজিবুর রহমান হল </option>
				<option value="Bangamata _Fazilatunnesa _Hall"> Bangamata  Fazilatunnesa  Hall – বঙ্গমাতা ফজিলাতুন্নেসা হল </option>
				<option value="Begum_Khaleda_Zia_Hall"> Begum Khaleda Zia Hall – বেগম খালেদা জিয়া হল </option>
				<option value="Madar_Bux_Hall"> Madar Bux Hall – মাদার বখ্‌শ হল </option>
				<option value="Mannujan_Hall"> Mannujan Hall – মুন্নুজান হল </option>
				<option value="Matihar_Hall">  Matihar Hall – মতিহার হল </option>
				<option value="Nawab_Abdul_Latif_Hall	"> Nawab Abdul Latif Hall – নবাব আব্দুল লতিফ হল </option>
				<option value="Rahamatunnesa_Hall"> Rahamatunnesa Hall – রহমতুন্নেসা হল </option>
				<option value="Rokeya_Hall"> Rokeya Hall -রোকেয়া হল </option>
				<option value="Shah_Mukhdum_Hall"> Shah Mukhdum Hall – শাহ্‌ মখদুম হল </option>
				<option value="Shaheed_Habibur_Rahman_Hall"> Shaheed Habibur Rahman Hall – শহীদ হবিবুর রহমান হল </option>
				<option value="Shaheed_Shamsuzzoha_Hall"> Shaheed Shamsuzzoha Hall – শহীদ শামসুজ্জোহা হল </option>
				<option value="Shaheed_Suhrawardy_Hall"> Shaheed Suhrawardy Hall – শহীদ সোহ্‌রাওয়ার্দী হল </option>
				<option value="Shaheed_Ziaur_Rahman_Hall"> Shaheed Ziaur Rahman Hall – শহীদ জিয়াউর রহমান হল </option>
				<option value="Sher-e_Bangla_Fazlul_Haque_Hall"> Sher-e Bangla Fazlul Haque Hall –  শের-ই-বাংলা ফজলুল হক হল </option>
				<option value="Syed_Amer_Ali_Hall"> Syed Amer Ali Hall – সৈয়দ আমীর আলী হল </option>
				<option value="Tapashi_Rabeya_Hall"> Tapashi Rabeya Hall – তাপসী রাবেয়া হল </option>
			</select>
		</div>
		<div class="form-group">
			<label>Dictrict </label>
			<select class="custom-select" name="district">
				<option value="">Select District</option>
				<?php
				$sql = "SELECT * FROM district ORDER BY name ASC";

				$stmt = $connPdo->prepare($sql);
				$stmt->execute();
				foreach ($stmt as $row) {

					echo '<option value="' . $row['name'] . '">' . $row['name'] . '</option>';
				}
				?>
			</select>
		</div>
		<!-- <button type="button" class="btn btn-sm btn-danger" data-dismiss="modal">Cancel</button> -->
		<button type="submit" id="download_btn_data" class="btn btn-sm btn-success">View</button>
	</form>

<?php
	$connPdo = null;
}*/ else if (isset($_GET['updateImagedata']) && isset($_GET['id'])) {
	$id = $_GET['id'];
	$urlRedirect = $_GET['url'];
	$sql = "SELECT * FROM gallery WHERE image_id = " . $id . "";
	$stmt = $connPdo->prepare($sql);
	$stmt->execute();
	$row = $stmt->fetch();
?>
	<form action="index_gallery.php?update&image_id=<?php echo $id ?>&<?= $urlRedirect ?>" method="post" enctype="multipart/form-data">
		<div class="editimage">
			<div class="form-group img-show">
				<img src="files/<?php echo $row['image_name']; ?>" class="upload_gallery_img">
			</div>

			<div class="form-group">
				<label>Pinned Photo</label>
				<select class="form-control" id="pinned" name="pinned">
					<option value="0" <?php echo $row['pinned'] == '0' ? ' selected="selected"' : ''; ?>>
						Not Pinned</option>
					<option value="1" <?php echo $row['pinned'] == '1' ? ' selected="selected"' : ''; ?>>
						Pinned</option>
				</select>
			</div>

			<div class="form-group">
				<label>Image capture place</label>
				<input class="form-control" type="text" name="image_place" value="<?php echo $row['image_place']; ?>">
			</div>

			<div class="form-group">
				<label>Image capture date</label>
				<input class="form-control" type="text" name="image_date" value="<?php echo $row['image_date']; ?>">
			</div>

			<div class="form-group">
				<label>Image caption</label>
				<input class="form-control" type="text" name="image_description" value="<?php echo $row['image_description']; ?>">
			</div>


			<div class="form-group">
				<label>Photo Album</label>
				<select class="custom-select" id="album_select" name="album">
					<option value="">Choose photo album</option>
					<?php
					$sql = "SELECT DISTINCT(album) FROM gallery WHERE album != '' ORDER BY album";
					$stmt = $connPdo->prepare($sql);
					$stmt->execute();

					foreach ($stmt as $rowa) { ?>
						<option value="<?php echo $rowa['album'] ?>" <?php echo $rowa['album'] == $row['album'] ? ' selected="selected"' : ''; ?>>

							<?php echo str_replace('-', ' ', $rowa['album']); ?>

						</option>
					<?php }  ?>
					<!-- <option value="add_new">Add New</option> -->
				</select>
			</div>
			<div class="form-group" id="new_album">
				<label>Add New Album (If any or Remove it and Type new) </label>
				<input class="form-control" id="new_album_input" value="<?php echo str_replace('-', ' ', $row['album']); ?>" name="album_new" type="text">
			</div>

			<div class="form-group">
				<label>Show/Hide</label>
				<select class="form-control" id="hide" name="hide">
					<option value="1" <?php echo $row['hide'] == '1' ? ' selected="selected"' : ''; ?>>Private</option>
					<option value="0" <?php echo $row['hide'] == '0' ? ' selected="selected"' : ''; ?>>Public</option>
				</select>
			</div>

		</div>
		<button type="submit" name="<?= $urlRedirect ?>" class="border-0 btn-block block-main-btn btn btn-warning btn-sm">Update</button>
	</form>
	<?php
	$connPdo = null;
} else if (isset($_GET['search_history_home_remove_log'])) {
	try {
		$stmt = $connPdo->prepare("UPDATE search SET show_log=0 WHERE id=" . $_GET['id'] . "");
		$stmt->execute();
		$connPdo = null;
	} catch (Exception $e) {
		echo "<div class='mt-2 text-center text-danger'>Something didn't work out. Please try one more later.</div>";
	}
} else if (isset($_GET['search_history_home'])) {
	$logId = $loggedin['student_id'];
	try {
		$numRows = 0;
		// $serSql = "SELECT * FROM search WHERE student_id=" . $logId . " AND date IN (SELECT MAX(date) FROM search GROUP BY keywords, key_cat)";
		// $serSql = "SELECT * FROM search where student_id=" . $logId . " AND show_log='1' AND id in (SELECT max(id) FROM search GROUP BY keywords, key_cat) order by id desc";

		$stmt = $connPdo->prepare("SELECT * FROM search where student_id=" . $logId . " AND show_log='1' AND id in (SELECT max(id) FROM search GROUP BY keywords, key_cat) order by id desc");
		$stmt->execute();
		$numRows = $stmt->rowCount();
		if ($numRows > 0) {
			foreach ($stmt as $row_search) {
	?>
				<div class="mt-2">
					<div class="clearfix">
						<span class="float-left">
							<a href="home.php?query=<?= $row_search['keywords'] ?>&category=<?= $row_search['key_cat'] ?>&ref=search_history#search_results"><?= $row_search['keywords'] . ' - ' . $row_search['key_cat'] ?>
							</a>
						</span>
						<span class="float-right text-danger" id="removeSearchLog" data-id="<?= $row_search['id'] ?>" data-key="<?= $row_search['keywords'] ?>" style="cursor: pointer;"><i class="mdi mdi-close mdi-18px"></i></span>
					</div>

				</div>
				<!-- echo $row_search['keywords'].' - '.$row_search['key_cat'].'<hr>'; -->
			<?php }
		} else {
			?>
			<div class="mt-2 text-center text-danger">
				No search history found.
			</div>
	<?php
		}
	} catch (Exception $e) {
		echo "<div class='mt-2 text-center text-danger'>Something didn't work out. Please try one more later.</div>";
	}
	$connPdo = null;
	?>
	<?php  } else if (isset($_GET['activitty_info_date_wise'])) {

	$student_id = ($_GET['student_id'] !== "") ? $_GET['student_id'] : $loggedin['student_id'];

	$sql1 = "SELECT * FROM activity_log WHERE student_id=" . $student_id . " GROUP BY DATE_FORMAT(date, '%Y-%m-%d') ORDER BY date DESC ";
	//$row = mysqli_fetch_array($result);
	$stmt = $connPdo->prepare($sql1);
	$stmt->execute();
	foreach ($stmt as $row_aa) {

	?>

		<table class="view_activity_log">
			<div class="log_title font-weight-bold">
				<?= date('d F, Y', strtotime($row_aa['date'])) ?>
			</div>
			<div class="deatsil_view_log">
				<?php
				$day = date('d', strtotime($row_aa['date']));
				$month = date('m', strtotime($row_aa['date']));
				$year = date('Y', strtotime($row_aa['date']));
				$sql = "SELECT * FROM activity_log WHERE DAY(date)=" . $day . " AND MONTH(date)=" . $month . " AND YEAR(date)=" . $year . " AND student_id=" . $student_id . " ORDER BY date DESC";
				$stmt = $connPdo->prepare($sql);
				$stmt->execute();
				foreach ($stmt as $row_bb) {
					$timePer = date('h:i:s A', strtotime($row_bb['date']));
				?>
					<div class="details_per" style="font-size:13px">
						- [<?= $timePer ?>] <?= $row_bb['details'] ?>
					</div>
				<?php } ?>
			</div>
		</table>
		<hr>
<?php }
	$connPdo = null;
}

$closePdo = $pdo->close();
unset($connPdo); ?>
<script>
	$(document).ready(function() {
		var table = $('#ais_family_web').DataTable({
			responsive: true,
			lengthMenu: [
				[10, 25, 50, 100, -1],
				[10, 25, 50, 100, "All"]
			],
		});
		new $.fn.dataTable.FixedHeader(table);
	});
</script>