<?php
error_reporting(0);
session_start();
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
require __DIR__."/inc/redirect.php";
require __DIR__ . '/inc/header.php';
if (!isset($_SESSION['student_id'])) {
	echo "<script>window.location='index.php'; </script>";
}
$batch = $_SESSION['batch'];
$get_batch = $_GET['batch'];
$loggedin = $data->batchData($batch, $_SESSION['student_id'], 'student_id');
$loggedin_name = $loggedin['name'];
if (isset($_GET['id']) && !isset($_GET['teachers_update']) && $_GET['batch'] !== "all_batch") {
	$get_id = $data->batchData($get_batch, $_GET['id'], 'id');
	$get_name = $get_id['name'];
	$get_student_id = $get_id['student_id'];
}

if ($redirect){
	# Redirect after Update 
	$redirect = $_SESSION['redirect_url'] = $_SERVER['HTTP_REFERER'];
	$connPdo =null;

}

/*
if (isset($_GET['teachers_update']) || isset($_GET['teacher_photo'])){
    $redirect= 'dataview.php?view_teacher';
} elseif ((isset($_GET['my_batch_update']) && isset($_GET['batch_photo']) && isset($_GET['controller_photo']))){
    $redirect= 'dataview.php?view_batch&controller_view&batch='.$get_batch.'&session='.$get_session.'';
}  elseif ((isset($_GET['my_batch_update']) && isset($_GET['action']) && ($_GET['action']=='update')) || (isset($_GET['my_batch_update']) && isset($_GET['batch_photo']))){
    $redirect= 'dataview.php?view_batch&my_batch&batch='.$loggedin['batch'].'&session='.$loggedin['session'].'';
} elseif (isset($_GET['controller_view_update']) && isset($_GET['action']) && ($_GET['action']=='update')){
    $redirect= 'dataview.php?view_batch&controller_view&batch='.$get_batch.'&session='.$get_session.'';
}  else {
    $redirect= $_SERVER['HTTP_REFERER'];
}
*/

if ((isset($_GET['id']) && isset($_GET['my_batch_update']) && isset($_SESSION['student_id']) || isset($_GET['id']) && isset($_GET['my_batch_update_photo']) && isset($_SESSION['student_id']) || isset($_GET['id']) && isset($_GET['controller_view_update']) && ($loggedin['role'] == 'dev'))  && $_GET['batch'] !== "all_batch") {
	$sql = "SELECT * FROM {$get_batch} WHERE id =" . $_GET['id'];
	$stmt = $connPdo->prepare($sql);
	$stmt->execute();
	$row_update = $stmt->fetch();
	// $connPdo =null;

} elseif (isset($_GET['id']) && isset($_GET['teachers_update'])) {
	$sql = "SELECT * FROM teacher WHERE id =" . $_GET['id'];
	$stmt = $connPdo->prepare($sql);
	$stmt->execute();
	$row_update_teacher = $stmt->fetch();
	// $connPdo =null;

} elseif (isset($_GET['stuff_id']) && isset($_GET['office_stuff_update'])) {
	$sql = "SELECT * FROM office_stuff WHERE id =" . $_GET['stuff_id'];
	$stmt = $connPdo->prepare($sql);
	$stmt->execute();
	$row_update_office_stuff = $stmt->fetch();
	// $connPdo =null;

} 
if (isset($_GET['id']) && (isset($_GET['controller_view_update']) || isset($_GET['my_batch_update'])) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev') && ($row_update['frnds'] == '1') && ($batch = '19th')) {
	$student_id = $row_update['student_id'];
	$sql = "SELECT 19th.student_id, 19th.name, 19th.phone,19th.photo,19th.father_name,19th.blood,19th.birth,19th.address,19th.district,19th.address_bangla, 19th.name_bangla, 19th.email, iconic19.prefer,iconic19.id, iconic19.details, iconic19.father_phone FROM 19th INNER JOIN  iconic19 ON {$student_id} = iconic19.student_id WHERE 19th.batch = '19th' AND 19th.frnds = '1'";
	$stmt = $connPdo->prepare($sql);
	$stmt->execute();
	$view_frnds = $stmt->fetch();
}

?>
<div class="container loogedin_info_edit_full">
	<div class="row loogedin_info_edit_left_right">
		<div class="col-md-12 loogedin_info_edit_left">
			<!--<span class="form_text_title">Navigate what you want</span> -->
			<?php
			if (isset($_GET['view_batch']) && isset($_GET['batch'])) {
				if (isset($_SESSION['successfully_generated']) && isset($_GET['inactive_view']) || isset($_SESSION['successfully_generated']) && isset($_GET['controller_view']) && isset($_GET['inactive_private_students'])) { ?>
						<div class="card my-4 alert alert-success alert-dismissible link_view">
							<button type="button" class="close" data-dismiss="alert">&times;</button>
							<div class="card-body">
								<span class="text-success"><strong>Link generated successfully!</strong></span> <br><br>
								<?php
								$link = $_SESSION['successfully_generated'];
								echo "<span class='link_body'>" . $link . "</span>";
								?>
							</div>
							<button class="btn btn-success btn-sm" data-link="<?= $link ?>" id="link_copy">Click here to copy link</button>
						</div>
					<?php } ?>
					<table id="ais_family_Std" class='table' style='width:100%'>
						<thead>
							<tr>
								<th width="60"><b>Image</th>
								<th width="90"><b>Student ID</th>
								<th width=""><b>Name (English)</th>
								<th width="80"><b>Mobile</th>
								<th width="60"><b> <span style='color:red; font-weight:bold;'>Blood</span></b></th>
								<th><b>Email</th>
								<th width="150"><b>View</th>
							</tr>
						</thead>
					</table>
			<?php } elseif (isset($_GET['view_teacher'])) { ?>
				<?php
				$sql = "SELECT * FROM teacher ORDER by name ASC";
				$stmt = $connPdo->prepare($sql);
				$stmt->execute();
				$numRows = $stmt->rowCount();
				if ($numRows > 0) { ?>
					<table id='ais_family' class='table' style='width:100%'>
						<thead>
							<tr>
								<th><b>Photo</th>
								<th><b>Name</th>
								<th><b>Designation</th>
								<th><b>Mobile </th>
								<th><b>Email</th>
								<th><b>View</th>
							</tr>
						</thead>
						<?php
						foreach ($stmt as $row) {
							$fb_id = $row['fb_id'];
							$facebook_url = $others->get_facebook_url($fb_id);
						?>
							<tr>
								<td>
									<div class='avatar'><a class='fb_id' target='_blank' href='https://www.facebook.com/<?= $facebook_url ?>'><img src='image/<?= $row['photo'] ?>'><img class='img-top' src='ais-assets/icon/fb.png'></a></div>
								</td>
								<td data-label='Name' style='font-weight:bold;'><?= $row['name'] ?></td>
								<td data-label='Designation'><?= $row['designation'] ?></td>
								<td data-label='Mobile'><a href='tel:<?= $row['phone'] ?>'><?= $row['phone'] ?></a></td>
								<td data-label='Email'><a href='mailto:<?= $row['email'] ?>'><?= $row['email'] ?></a></td>
								<td>
									<div class='btn-group'>
										<button type="button" class='view_btn btn btn-success btn-sm' data-id="<?= $row['id'] ?>" id='view_btn_tea'><i class='fas fa-eye'></i></button>
										<?php if ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev' ||  array_key_exists("teacher-staff-update", $loggedChecklist)) { ?>
											<a type="button" class='btn btn-warning btn-sm' href="dataview.php?teachers_update&update_key=<?= md5($row['phone']) ?>&id=<?= $row['id'] ?>&name=<?= str_replace(' ', '_', $row['name']) ?>"><i class='fas fa-edit'></i></a>
										<?php } ?>
										<?php if ($loggedin['role'] == 'dev'  ||  array_key_exists("teacher-staff-delete", $loggedChecklist)) { ?>
											<button type="button" id="teacherDeleteID" class='btn btn-danger btn-sm' data-id="<?=$row['id']?>"><i class='fas fa-trash-alt'></i></button>
										<?php } ?>
									</div>
								</td>
							</tr>
						<?php } ?>
					</table>
				<?php } else {
					echo "No teachers found.";
				}
				$connPdo =null;

			} elseif (isset($_GET['view_office_stuff'])) { ?>
				<?php
				$sql = "SELECT * FROM office_stuff ORDER by name ASC";
				$stmt = $connPdo->prepare($sql);
				$stmt->execute();
				$numRows = $stmt->rowCount();
				if ($numRows > 0) { ?>
					<table id='ais_family' class='table' style='width:100%'>
						<thead>
							<tr>
								<th><b>Photo</th>
								<th><b>Name</th>
								<th><b>Designation</th>
								<th><b>Mobile </th>
								<th><b>Email</th>
								<th><b>View</th>
							</tr>
						</thead>
						<?php
						foreach ($stmt as $row) {
							$fb_id = $row['fb_id'];
							$facebook_url = $others->get_facebook_url($fb_id);
						?>
							<tr>
								<td>
									<div class='avatar'><a class='fb_id' target='_blank' href='https://www.facebook.com/<?= $facebook_url ?>'><img src='image/<?= $row['photo'] ?>'><img class='img-top' src='ais-assets/icon/fb.png'></a></div>
								</td>
								<td data-label='Name' style='font-weight:bold;'><?= $row['name'] ?></td>
								<td data-label='Designation'><?= $row['designation'] ?></td>
								<td data-label='Mobile'><a href='tel:<?= $row['phone'] ?>'><?= $row['phone'] ?></a></td>
								<td data-label='Email'><a href='mailto:<?= $row['email'] ?>'><?= $row['email'] ?></a></td>
								<td>
									<div class='btn-group'>
										<button type="button" class='view_btn btn btn-success btn-sm' data-id="<?= $row['id'] ?>" id='view_btn_office_stuff'><i class='fas fa-eye'></i></button>
										<?php if ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev' ||  array_key_exists("teacher-staff-update", $loggedChecklist)) { ?>
											<a type="button" class='btn btn-warning btn-sm' href="dataview.php?office_stuff_update&update_key=<?= md5($row['id']) ?>&stuff_id=<?= $row['id'] ?>&name=<?= str_replace(' ', '_', $row['name']) ?>"><i class='fas fa-edit'></i></a>
										<?php } ?>
										<?php if ($loggedin['role'] == 'dev' ||  array_key_exists("teacher-staff-delete", $loggedChecklist)) { ?>
											<a type="button" class='btn btn-danger text-white btn-sm' id="staffDeleteID" data-id="<?= $row['id'] ?>"><i class='fas fa-trash-alt'></i></a>
										<?php } ?>
									</div>
								</td>
							</tr>
						<?php } ?>
					</table>
				<?php } else {
					echo "No office stuff found.";
				}
				$connPdo =null;

			} else if ((isset($_GET['login_info_batch']) && isset($_GET['batch']) && ($loggedin['batch'] == $get_batch) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev') && $_GET['batch'] !== "all_batch")) {
				$sql = "SELECT {$get_batch}.name, {$get_batch}.photo, login.id AS login_id, login.student_id,login.batch, login.details, login.device, login.time, login.http, login.action, login.ip FROM login  INNER JOIN
	{$get_batch} ON login.student_id = {$get_batch}.student_id WHERE login.batch ='{$get_batch}' ORDER BY login.id DESC";
			$stmt = $connPdo->prepare($sql);
			$stmt->execute();
				?>
				<table id='ais_family' class='table' style='width:100%'>
					<thead>
						<tr>
							<th>Photo</th>
							<th>Name </th>
							<th>Student ID</th>
							<th>Batch</th>
							<th>Website</th>
							<th>IP </th>
							<th>Time </th>
							<th>Device </th>
							<th>View </th>
						</tr>
					</thead>
					<?php
					foreach ($stmt as $row) {
						echo "<tr>";
						$img = $row['photo'];
						if (empty($img)) {
							echo "<td>" . "<div class='avatar'><img  src='ais-assets/icon/demo.png'>" . "</td>";
						} else {
							echo "<td>" . "<div class='avatar'><img  src='image/" . $row['photo'] . "'>" . "</td>";
						}
						echo "<td data-label='Name' style='font-weight:bold;' >" . $row['name'] . "</td>";
						echo "<td data-label='Student ID'>" . $row['student_id'] . "</td>";
						echo "<td data-label='Batch'>" . $row['batch'] . "</td>";
						echo "<td data-label='Website'>" .  $row['http'] . "</td>";
						echo "<td data-label='IP'>" .  $row['ip'] . "</td>";
						echo "<td data-label='Time' style='font-weight: 700;'>" . $row['time'] . "</td>";
						echo "<td data-label='Device' style='font-weight: 700;'>" . $row['device'] . "</td>";
						echo "<td data-label='View'><span data-time='" . $row['time'] . "' data-id='" . $row['login_id'] . "' data-name='" . $row['name'] . "' id='view_login_info' style='cursor:pointer' class='btn btn-link'>" . $row['action'] . "</span></td>";
						echo "</tr>";
					}
					$connPdo =null;

					?>
				</table>
			<?php } elseif (isset($_GET["my_batch_update"]) && isset($_GET["key"]) && $_GET['batch'] == $loggedin['batch'] && $_GET['key'] == md5($row_update["phone"]) && isset($_GET["action"]) && ($_GET["action"] == "update") && !isset($_POST["action"]) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev') || isset($_GET["controller_view_update"]) && isset($_GET["key"]) && $_GET['key'] == md5($row_update["phone"]) && isset($_GET["action"]) && ($_GET["action"] == "update") && !isset($_POST["action"]) && ($loggedin['role'] == 'dev')) { ?>
				<div class="row">
					<div class="col-md-4">
						<?php /*
<div class="card mb-3">
	<div class="card-header "><span class="bullet-info spinner-grow title-spinner mr-2 text-success"></span>Status</div>
	<div class="card-body">
<div class="row">
<script>
 function change_active(){
  document.getElementById('active').submit();
 } 
 function change_role(){
  document.getElementById('showing').submit();
 }
 </script>
<div class="col-md-6">
	<form method='get' action='dataview.php?active_status&batch=<?=$row_update['batch']?>&id=<?=$row_update['id']?>' id="active">
			<div class="form-group">
				<label>Status: <?php 
					if ($row_update['active'] == '1'){
						echo 'Active';
					} else {
						echo 'Inactive';
					} ?>
				</label>
				<select class="form-control" id="active" onchange="change_active();" name="active">
					<option value="0"<?php echo $row_update['active'] == '0' ? ' selected="selected"' : '';?>>Inactive</option>
					<option value="1"<?php echo $row_update['active'] == '1' ? ' selected="selected"' : '';?>>Active</option>
				</select>
			</div>
		</form>
		</div>
		<div class="col-md-6">
		 <form method='GET' action='dataview.php?role_status&batch=<?=$row_update['batch']?>&id=<?=$row_update['id']?>' id="showing">
			<div class="form-group">
				<label><?=_USERROLE?>: <?php 
					if ($row_update['role'] == 'admin'){
						echo ''._ADMIN.'';
					} else {
						echo ''._NOTADMIN.'';
					} ?>
				</label>
				<select class="form-control" onchange="change_role();"  name="role">
					<option value=""<?php echo $row_update['role'] == '' ? ' selected="selected"' : '';?>><?=_NOTADMIN?></option>
					<option value="admin"<?php echo $row_update['role'] == 'admin' ? ' selected="selected"' : '';?>><?=_ADMIN?></option>
				</select>
			</div>
			</form>
		</div>
</div>
</div>
</div>
*/ ?>
						<div class="card mb-3">
							<div class="card-header "><span class="fas fa-camera photo_icon  title-spinner mr-2"></span>Change Photo</div>
							<div class="card-body">
								<div class=" text-center mb-4">
									<?php
									$photo = $row_update['photo'];
									if (empty($photo)) { ?>
										<img src="ais-assets/icon/demo.png" width="100px" id="profile-img-tag-img">
									<?php	} else { ?>
										<img src="image/<?php echo $row_update['photo']; ?>" width="100px" id="profile-img-tag-img">
									<?php	}    ?>
								</div>
								<?php
								if (isset($_GET['controller_view_update'])) {
									$controller_photo = '&controller_photo';
								} ?>
								<div class="img-input">
									<form  onSubmit="return Validate_img();" id="userLoggedPhotoForm">
										<div class="form-group">
											<small><span id="error_img" style="color: red;"></span></small>
											<input class="form-control" type="file" name="image" onchange="loadImg(event)" id="image_img" required>
										</div>
										<input type="hidden" name="changePhoto" value="myBatchPhoto">
										<input type="hidden" name="batch" value="<?=$row_update['batch']?>">
										<input type="hidden" name="id" value="<?=$row_update['id']?>">
										<div class="form-group">
										<button id="userLoggedPhotoBtn" class="border-0 btn-block block-main-btn btn btn-success text-uppercase" >
											<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span> 
											<span class="MainBtnText">Save</span>
										</button>
										</div>
									</form>
								</div>
							</div>
						</div>
						<?php if (($row_update['frnds'] == '1') && ($row_update['batch'] == '19th')) { ?>
							<div class="card">
								<div class="card-header "><i class="bullet-info fas fa-lock mr-2 text-danger"></i>Update personal details of <b> <?= str_replace('_',' ',$_GET['name'])?></b></div>
								<div class="card-body">
									<form id="userSecureInfoForm">
										<div class="row">
											<div class="col-md-12">
												<div class="form-group">
													<label>
														Father Mobile
													</label>
													<input type="text" class="form-control" name="father_phone" placeholder="Father Mobile" value="<?php echo $view_frnds['father_phone']; ?>" required>
												</div>
											</div>
											<div class="col-md-12">
												<div class="form-group">
													<label>
														Prefer Vahicle
													</label>
													<input type="text" class="form-control" name="prefer" placeholder="Prefer Vahicle" value="<?php echo $view_frnds['prefer']; ?>" required>
												</div>
											</div>
											<div class="col-md-12">
												<div class="form-group">
													<label>
														Details Address
													</label>
													<textarea type="text" class="form-control" id="details_address" rows="8" name="details" placeholder="Details Address" required><?php echo $view_frnds['details']; ?></textarea>
												</div>
											</div>
											<input type="hidden" name="userLoggedSecureInfo" value="true">
											<input type="hidden" name="student_id" value="<?=$row_update['student_id']?>">
											<div class="col-md-12">
												<div class="form-group">
												<button id="userSecureInfoBtn" class="border-0 btn-block block-main-btn btn btn-success text-uppercase" >
												<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span> 
												<span class="MainBtnText">Update</span>
											</button>
												</div>
											</div>
										</div>
									</form>
								</div>
							</div>
							<script>
								$(document).ready(function() {
									$('#details_address').summernote({
										height: 300,
										minHeight: null,
										maxHeight: null,
										focus: false,
										inheritPlaceholder: true,
										toolbar: [
											['style', ['style']],
											['font', ['bold', 'underline', 'clear']],
											['color', ['color']],
											['para', ['ul', 'ol', 'paragraph']],
											// ['table', ['table']],
											['insert', ['link']],
											['view', ['fullscreen', 'codeview']]
										]
									});
								});
							</script>
						<?php } ?>
					</div>
					<div class="col-md-8">
						<div class="card update_box">
							<div class="card-header "><span class="fas fa-user-edit form_icon  title-spinner mr-2"></span>Update personal details of <b> <?= str_replace('_',' ',$_GET['name'])?></b></div>
							<div class="card-body">
								<form id="myBatchInfoUpdateForm">
									<div class="row">
										<div class="col-md-3">
											<div class="form-group">
												<label>Status: <?php
																if ($row_update['active'] == '1') {
																	echo 'Active';
																} else {
																	echo 'Inactive';
																} ?>
												</label>
												<select class="form-control" name="active">
													<option value="0" <?php echo $row_update['active'] == '0' ? ' selected="selected"' : ''; ?>>Inactive</option>
													<option value="1" <?php echo $row_update['active'] == '1' ? ' selected="selected"' : ''; ?>>Active</option>
												</select>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label>Visibility: <?php
																	if ($row_update['showing'] == '1') {
																		echo 'Public';
																	} else {
																		echo 'Private';
																	} ?>
												</label>
												<select class="form-control" name="showing">
													<option value="0" <?php echo $row_update['showing'] == '0' ? ' selected="selected"' : ''; ?>>Private</option>
													<option value="1" <?php echo $row_update['showing'] == '1' ? ' selected="selected"' : ''; ?>>Public</option>
												</select>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label>User Role: <?php
																	if ($row_update['role'] == 'admin') {
																		echo 'Admin';
																	} else {
																		echo 'General';
																	} ?>
												</label>
												<select class="form-control" name="role">
													<option value="None" <?php echo $row_update['role'] == '' ? ' selected="selected"' : ''; ?>>General</option>
													<?php if ($loggedin['role'] == 'dev') { ?>
														<option value="dev" <?php echo $row_update['role'] == 'dev' ? ' selected="selected"' : ''; ?>>Controller</option>
													<?php } ?>
													<option value="admin" <?php echo $row_update['role'] == 'admin' ? ' selected="selected"' : ''; ?>>Admin</option>
												</select>
											</div>
										</div>
										<div class="col-md-3">
											<div class="form-group">
												<label>Student ID</label>
												<input type="tel" class="form-control" name="student_id" placeholder="Student ID" value="<?php echo $row_update['student_id']; ?>" maxlength="10" readonly>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>Name (English)</label>
												<input class="form-control" type="text" name="name" placeholder="Name (English)" value="<?php echo $row_update['name']; ?>" required>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>Name (Bangla)</label>
												<input class="form-control" type="text" name="name_bangla" placeholder="Name (Bangla)" value="<?php echo $row_update['name_bangla']; ?>" required>
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group"><label>Birth Day</label><input class="form-control" type="date" name="birth" placeholder="Birth Day" value="<?php echo $row_update['birth']; ?>" required>
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group">
												<label>Blood Group</label>
												<select name="blood" class="custom-select" required>
													<option value="">Select your blood group</option>
													<option value="A+" <?php echo $row_update['blood'] == 'A+' ? ' selected="selected"' : ''; ?>>A+</option>
													<option value="A-" <?php echo $row_update['blood'] == 'A-' ? ' selected="selected"' : ''; ?>>A-</option>
													<option value="AB+" <?php echo $row_update['blood'] == 'AB+' ? ' selected="selected"' : ''; ?>>AB+</option>
													<option value="AB-" <?php echo $row_update['blood'] == 'AB-' ? ' selected="selected"' : ''; ?>>AB-</option>
													<option value="B+" <?php echo $row_update['blood'] == 'B+' ? ' selected="selected"' : ''; ?>>B+</option>
													<option value="B-" <?php echo $row_update['blood'] == 'B-' ? ' selected="selected"' : ''; ?>>B-</option>
													<option value="O+" <?php echo $row_update['blood'] == 'O+' ? ' selected="selected"' : ''; ?>>O+</option>
													<option value="O-" <?php echo $row_update['blood'] == 'O-' ? ' selected="selected"' : ''; ?>>O-</option>
												</select>
												<!--
												<input class="form-control" type="text" name="blood" placeholder="<?= _BLOOD ?>" value="<?php echo $row_update['blood']; ?>" required>-->
											</div>
										</div>
										<div class="col-md-4">
											<div class="form-group"> <label>Father Name</label><input class="form-control" type="text" name="father_name" placeholder="Father Name" value="<?php echo $row_update['father_name']; ?>" required>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>
													Facebook Link
												</label>
												<input type="url" class="form-control" name="fb_id" placeholder="Facebook Link" value="<?php echo $row_update['fb_id']; ?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group"> <label>Email</label><input class="form-control" type="email" name="email" placeholder="Email" value="<?php echo $row_update['email']; ?>" required>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>Mobile</label>
												<input class="form-control" type="tel" name="phone" placeholder="Mobile" value="<?php echo $row_update['phone']; ?>" maxlength="11" required>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>District</label>
												<select class="selectpicker form-control" data-live-search="true" data-hide-disabled="true" name="district" required>
													<option value="">Select your district</option>
													<?php
													$sql = "SELECT * FROM district ORDER BY name ASC";
													$stmt = $connPdo->prepare($sql);
													$stmt->execute();
													foreach ($stmt as $row) {
														$select = $row_update['district'] == $row['name'] ? 'selected="selected"' : '';
														echo '<option value="' . $row['name'] . '" ' . $select . '>' . $row['name'] . '</option>';
													}
													$connPdo =null;

													?>
												</select>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>Address (Bangla)</label>
												<textarea rows="5" class="form-control" type="text" name="address_bangla" placeholder="Address (Bangla)" value="<?php echo $row_update['address_bangla']; ?>" required><?php echo $row_update['address_bangla']; ?></textarea>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>Address (Engliah)</label>
												<textarea rows="5" class="form-control" type="text" name="address" placeholder="Address (Engliah)" value="<?php echo $row_update['address']; ?>" required><?php echo $row_update['address']; ?></textarea>
											</div>
										</div>
										<input name="myBatchInfoUpdate" type="hidden" value="true">
										<input name="id" type="hidden" value="<?=$row_update['id']?>">
										<input name="batch" type="hidden" value="<?=$row_update['batch']?>">
										<div class="col-md-12">
											<button id="myBatchInfoUpdateBtn" class="border-0 btn-block block-main-btn btn btn-success text-uppercase" >
												<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span> 
												<span class="MainBtnText">Update</span>
											</button>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			<?php } elseif (isset($_GET['teachers_update']) && isset($_GET['id']) && isset($_GET["update_key"]) && $_GET['update_key'] == md5($row_update_teacher['phone'])) { ?>
				<div class="row">
					<div class="col-md-4">
						<div class="card ">
							<div class="card-header "><span class="fas fa-camera photo_icon   title-spinner mr-2"></span>Change Photo</div>
							<div class="card-body">
								<div class=" text-center mb-4">
									<?php
									$photo = $row_update_teacher['photo'];
									if (empty($photo)) { ?>
										<img src="ais-assets/icon/demo.png" width="100px" id="profile-img-tag-img">
									<?php	} else { ?>
										<img src="image/<?php echo $row_update_teacher['photo']; ?>" width="100px" id="profile-img-tag-img">
									<?php	}    ?>
								</div>
								<div class="img-input">
									<form class="form-group" onSubmit="return Validate_img();" id="userLoggedPhotoForm">
										<div class="form-group">
											<small><span id="error_img" style="color: red;"></span></small>
											<input class="form-control" type="file" name="image" onchange="loadImg(event)" id="image_img" required>
										</div>
										<input type="hidden" name="changePhoto" value="teacherPhoto">
										<input type="hidden" name="id" value="<?=$row_update_teacher['id']?>">
										<div class="form-group">
											<button id="userLoggedPhotoBtn" class="border-0 btn-block block-main-btn btn btn-success text-uppercase" >
												<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span> 
												<span class="MainBtnText">Save</span>
											</button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-8">
						<div class="card update_box">
							<div class="card-header "><span class="fas fa-user-edit form_icon  title-spinner mr-2"></span>Update personal details of <b> <?= str_replace('_',' ',$_GET['name'])?></b></div>
							<div class="card-body">
								<form id="updateTeacherForm">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label>Teacher Name</label>
												<input type="text" name="name" class="form-control" placeholder="name" value="<?php echo $row_update_teacher['name']; ?>" required>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>Designation</label>
												<input type="text" name="designation" class="form-control" placeholder="designation" value="<?php echo $row_update_teacher['designation']; ?>" required>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group">
												<label>
													Facebook Link
												</label>
												<input type="url" class="form-control" name="fb_id" placeholder="Facebook Link" value="<?php echo  $row_update_teacher['fb_id']; ?>">
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group">
												<label>Education</label>
												<textarea type="text" name="edu" class="form-control" placeholder="edu" value="<?php echo $row_update_teacher['edu']; ?>" required><?php echo $row_update_teacher['edu']; ?></textarea>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>Mobile</label>
												<input type="tel" name="phone" class="form-control" placeholder="phone" value="<?php echo $row_update_teacher['phone']; ?>" maxlength="11" required>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>Email</label>
												<input type="text" name="email" class="form-control" placeholder="email" value="<?php echo $row_update_teacher['email']; ?>" required>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group">
												<label>Address</label>
												<textarea type="text" rows="5" name="per_addr" class="form-control" placeholder="Address..." value="" required><?php echo $row_update_teacher['per_addr']; ?></textarea>
											</div>
										</div>
										<input type="hidden" name="newTeacherInfoUpdate" value="true">
										<input type="hidden" name="id" value="<?=$row_update_teacher['id']?>">

										<div class="col-md-12">
											<div class="form-group">
											<button id="updateTeacherBtn" class="border-0 btn-block block-main-btn btn btn-success text-uppercase" >
												<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span> 
												<span class="MainBtnText">Update</span>
											</button>
											</div>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			<?php } elseif (isset($_GET['office_stuff_update']) && isset($_GET['stuff_id']) && isset($_GET["update_key"]) && $_GET['update_key'] == md5($row_update_office_stuff['id'])) { ?>
				<div class="row">
					<div class="col-md-4">
						<div class="card ">
							<div class="card-header "><span class="fas fa-camera photo_icon  title-spinner mr-2"></span>Change Photo</div>
							<div class="card-body">
								<div class=" text-center mb-4">
									<?php
									$photo = $row_update_office_stuff['photo'];
									if (empty($photo)) { ?>
										<img src="ais-assets/icon/demo.png" width="100px" id="profile-img-tag-img">
									<?php	} else { ?>
										<img src="image/<?php echo $row_update_office_stuff['photo']; ?>" width="100px" id="profile-img-tag-img">
									<?php	}    ?>
								</div>
								<div class="img-input">
									<form onSubmit="return Validate_img();" id="userLoggedPhotoForm">
										<div class="form-group">
											<small><span id="error_img" style="color: red;"></span></small>
											<input class="form-control" type="file" name="image" onchange="loadImg(event)" id="image_img" required>
										</div>
										<input type="hidden" name="changePhoto" value="staffPhoto">
										<input type="hidden" name="id" value="<?=$row_update_office_stuff['id']?>">
										<div class="form-group">
											<button id="userLoggedPhotoBtn" class="border-0 btn-block block-main-btn btn btn-success text-uppercase" >
												<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span> 
												<span class="MainBtnText">Save</span>
											</button>
										</div>
									</form>
								</div>
							</div>
						</div>
					</div>
					<div class="col-md-8">
						<div class="card update_box">
							<div class="card-header "><span class="fas fa-user-edit form_icon title-spinner mr-2"></span>Update personal details of <b> <?= str_replace('_',' ',$_GET['name'])?></b></div>
							<div class="card-body">
								<form id="updateStaffForm">
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<label>Stuff Name</label>
												<input type="text" name="name" class="form-control" placeholder="name" value="<?php echo $row_update_office_stuff['name']; ?>" required>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>Designation</label>
												<input type="text" name="designation" class="form-control" placeholder="designation" value="<?php echo $row_update_office_stuff['designation']; ?>" required>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group">
												<label>
													Facebook Link
												</label>
												<input type="url" class="form-control" name="fb_id" placeholder="Facebook Link" value="<?php echo  $row_update_office_stuff['fb_id']; ?>">
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>Mobile</label>
												<input type="tel" name="phone" class="form-control" placeholder="phone" value="<?php echo $row_update_office_stuff['phone']; ?>" maxlength="11" required>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<label>Email</label>
												<input type="text" name="email" class="form-control" placeholder="email" value="<?php echo $row_update_office_stuff['email']; ?>" required>
											</div>
										</div>
										<div class="col-md-12">
											<div class="form-group">
												<label>Address</label>
												<textarea type="text" rows="5" name="per_addr" class="form-control" placeholder="Address..." value="" required><?php echo $row_update_office_stuff['per_addr']; ?></textarea>
											</div>
										</div>
										<input type="hidden" name="id" value="<?php echo $row_update_office_stuff['id']; ?>">
										<input type="hidden" name="newStaffInfoUpdate" value="true">
										<div class="col-md-12">
											<div class="form-group">
												<button id="updateStaffBtn" class="border-0 btn-block block-main-btn btn btn-success text-uppercase" >
													<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span> 
													<span class="MainBtnText">Update</span>
												</button>
											</div>
										</div>
									</div>
								</form>
							</div>
						</div>
					</div>
				</div>
			<?php } elseif (isset($_GET['see_all_notice']) && isset($_GET['batch'])) { ?>
				<div class="loogedin_info_edit_right row">
					<?php
					$sql = "SELECT * FROM notice WHERE batch='" . $batch . "' ORDER by id DESC";
					$stmt = $connPdo->prepare($sql);
					$stmt->execute();
					$numRows = $stmt->rowCount();
					if ($numRows > 0) {
						foreach ($stmt as $row) {  ?>
							<div class="col-md-4">
								<div class="card members-side home_developer_box">
									<div class="card-header members-side "><i class="fas fa-bell mr-2"></i><?= $row['title'] ?></div>
									<div class="card-body">
										<?= $row['message'] ?>
									</div>
									<span class="clear-fix update_notice_btn">
										<?php if ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev') { ?>
											<span class="float-left">
												<span class="btn btn-warning btn-sm" data-id="<?= $row['id'] ?>"  id="updateNoticeWinBtn">Update</span>
												<span id="deleteNotice" data-id="<?= $row['id'] ?>" class="btn btn-danger btn-sm">Delete</span>
											</span>
										<?php } ?>
										<span class="float-right">
											<small><?= $row['name'] ?></small> (<small><?= $row['student_id'] ?></small>) -
											<small><?= $row['date'] ?></small>
										</span>
									</span>
								</div>
							</div>
					<?php }
					} else {
						echo 'No notice available';
					} 							$connPdo =null;
					?>
				</div>
			<?php } else {
				if (isset($_SESSION['student_id'])) {
					if ($redirect) {
						echo "<script>window.setTimeout(function(){ window.location.href='" . $redirect . "'; }, 2000); </script>";
					} else {
						echo "<script>window.history.go(-1); </script>";
					}
				} else {
					echo "<script>window.location='index.php'; </script>";
				}
			}  ?>
		</div>
	</div>
</div>
<?php require 'inc/footer.php'; ?>