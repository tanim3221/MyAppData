<?php
session_start();
error_reporting(0);
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
date_default_timezone_set("Asia/Dhaka");
include __DIR__.'/inc/header.php';
if (!isset($_SESSION['student_id'])) {
	$batchData = $others->getBatch();
}

$batch = $_SESSION['batch'];
$get_batch = $_GET['batch'];
if (isset($_GET['add_info_users']) && isset($_GET["key"]) && isset($_GET["action"]) && ($_GET["action"] == "add")	&& !isset($_POST["action"])) {
	$key = $_GET["key"];
	$curDate = date("Y-m-d H:i:s");
	$query = " SELECT * FROM `add_info_key` WHERE `key`='" . $key . "';";
	$stmt = $connPdo->prepare($query);
	$stmt->execute();
	$rowCount = $stmt->rowCount();
	$row = $stmt->fetch();
	if ($rowCount > 0) {
		$expDate = $row['expDate'];
		$email = $row['email'];
		$student_id = $row['student_id'];
		$batch = $row['batch'];
		$mainData = $data->batchData($batch, $student_id,"student_id");

		if ($expDate >= $curDate) {
	?>
			<div class="center-login add_info_users container ">
				<div class="card add_info_users_top" style="background:transparent;">
					<div class="card-body text-center add_info_users_title">
						<p class="card-text text-white text-uppercase text_title_loggedin">
						UPDATE INFORMATION
						</p>
					</div>
				</div>
				<div class="only_form_users">
					<form id="addNewInfoForm">
						<input type="hidden" name="add_info_users_req" value="true" />
						<input type="hidden" name="action" value="add" />
						<input type="hidden" name="email" value="<?php echo $email; ?>" />
						<input type="hidden" name="student_id" value="<?php echo $student_id; ?>" />
						<input type="hidden" name="batch" value="<?php echo $batch; ?>" />
												
						<div class="add_info_title">Personal Information</div>
						<div class="form-group">
							<label>Name (English)</label>
							<input type="text" name="name" class="form-control" placeholder="Name (English)" value="<?php echo $mainData['name']; ?>"  />
						</div>
						<div class="form-group">
							<label>Name (Bangla)</label>
							<input type="text" name="name_bangla" class="form-control" placeholder="নাম (বাংলা)" value="<?php echo $mainData['name_bangla']; ?>"  />
						</div>
						<div class="form-group">
							<label>Birthday</label>
							<input type="date" name="birth" class="form-control" placeholder="Birthday" value="<?php echo $mainData['birth']; ?>"  />
						</div>
						<div class="form-group">
							<label>Blood Group</label>
							<select name="blood" class="custom-select" >
								<option value="">Select your blood group</option>
								<option value="A+" <?php echo $mainData['blood'] == 'A+' ? ' selected="selected"' : ''; ?>>A+</option>
								<option value="A-" <?php echo $mainData['blood'] == 'A-' ? ' selected="selected"' : ''; ?>>A-</option>
								<option value="AB+" <?php echo $mainData['blood'] == 'AB+' ? ' selected="selected"' : ''; ?>>AB+</option>
								<option value="AB-" <?php echo $mainData['blood'] == 'AB-' ? ' selected="selected"' : ''; ?>>AB-</option>
								<option value="B+" <?php echo $mainData['blood'] == 'B+' ? ' selected="selected"' : ''; ?>>B+</option>
								<option value="B-" <?php echo $mainData['blood'] == 'B-' ? ' selected="selected"' : ''; ?>>B-</option>
								<option value="O+" <?php echo $mainData['blood'] == 'O+' ? ' selected="selected"' : ''; ?>>O+</option>
								<option value="O-" <?php echo $mainData['blood'] == 'O-' ? ' selected="selected"' : ''; ?>>O-</option>
							</select>
						</div>

						<div class="form-group">
							<label>Father Name</label>
							<input type="text" name="father_name" class="form-control" placeholder="Father Name" value="<?php echo $mainData['father_name']; ?>" />
						</div>
						<div class="add_info_title">Academic Information</div>
						<div class="form-group">
							<label>Student ID</label>
							<input type="tel" class="form-control" placeholder="Student ID" value="<?php echo $student_id; ?>" maxlength="10" readonly />
						</div>
						<div class="form-group">
							<label>Hall Name </label>
							<select class="selectpicker form-control" data-live-search="true" data-hide-disabled="true" name="hall_name" >
								<option value="">Select your hall</option>
									<?php
									$sql1 = "SELECT * FROM hall ORDER BY name_en ASC";
									$stmt1 = $connPdo->prepare($sql1);
									$stmt1->execute();
									foreach ($stmt1 as $row) {						
										$select = substr($student_id, 2, 3) == $row['code'] ? 'selected="selected"' : '';
										echo '<option value="' . $row['name_en'].'-'.$row['name_bn'] . '" ' . $select . '>' . $row['name_en'] . '</option>';
									}
									?>
							<!-- <option value="">Choose your hall</option>
								<option value="Bangabandhu_Sheikh_Mujibur_Rahman_Hall"> Bangabandhu Sheikh Mujibur Rahman Hall – বঙ্গবন্ধু শেখ মুজিবুর রহমান হল </option>
								<option value="Bangamata _Fazilatunnesa _Hall"> Bangamata  Fazilatunnesa  Hall – বঙ্গমাতা ফজিলাতুন্নেসা হল </option>
								<option value="Begum_Khaleda_Zia_Hall"> Begum Khaleda Zia Hall – বেগম খালেদা জিয়া হল </option>
								<option value="Madar_Bux_Hall"> Madar Bux Hall – মাদার বখ্‌শ হল </option>
								<option value="Mannujan_Hall"> Mannujan Hall – মুন্নুজান হল </option>
								<option value="Matihar_Hall">  Matihar Hall – মতিহার হল </option>
								<option value="Nawab_Abdul_Latif_Hall"> Nawab Abdul Latif Hall – নবাব আব্দুল লতিফ হল </option>
								<option value="Rahamatunnesa_Hall"> Rahamatunnesa Hall – রহমতুন্নেসা হল </option>
								<option value="Rokeya_Hall"> Rokeya Hall -রোকেয়া হল </option>
								<option value="Shah_Mukhdum_Hall"> Shah Mukhdum Hall – শাহ্‌ মখদুম হল </option>
								<option value="Shaheed_Habibur_Rahman_Hall"> Shaheed Habibur Rahman Hall – শহীদ হবিবুর রহমান হল </option>
								<option value="Shaheed_Shamsuzzoha_Hall"> Shaheed Shamsuzzoha Hall – শহীদ শামসুজ্জোহা হল </option>
								<option value="Shaheed_Suhrawardy_Hall"> Shaheed Suhrawardy Hall – শহীদ সোহ্‌রাওয়ার্দী হল </option>
								<option value="Shaheed_Ziaur_Rahman_Hall"> Shaheed Ziaur Rahman Hall – শহীদ জিয়াউর রহমান হল </option>
								<option value="Sher-e_Bangla_Fazlul_Haque_Hall"> Sher-e Bangla Fazlul Haque Hall –  শের-ই-বাংলা ফজলুল হক হল </option>
								<option value="Syed_Amer_Ali_Hall"> Syed Amer Ali Hall – সৈয়দ আমীর আলী হল </option>
								<option value="Tapashi_Rabeya_Hall"> Tapashi Rabeya Hall – তাপসী রাবেয়া হল </option> -->
							</select>
						</div>
						<div class="add_info_title">Contact Information</div>
						<div class="form-group">
							<label> Facebook Link</label>
							<input type="url" class="form-control" name="fb_id" placeholder="Your facebook profile url" value="<?php echo $mainData['fb_id']; ?>">
						</div>
						<div class="form-group">
							<label>Mobile Number</label>
							<input type="tel" name="phone" class="form-control" placeholder="Mobile" value="<?php echo $mainData['phone']; ?>" maxlength="11"  />
						</div>
						<div class="form-group">
							<label>Email</label><input class="form-control" type="email" placeholder="Email" value="<?php echo $email; ?>" readonly />
						</div>
						<div class="add_info_title">Address Details</div>
						<div class="form-group">
							<label>Address (Bangla)</label>
							<textarea type="text" name="address_bangla" rows="5" class="form-control" placeholder="বাড়ি নং, রাস্তার নম্বর, গ্রাম, ইউনিয়ন, পৌরসভা, উপজেলা, পোস্ট অফিস, পোস্ট কোড ইত্যাদি" value="<?php echo $mainData['address_bangla']; ?>" ><?php echo $mainData['address_bangla']; ?></textarea>
						</div>
						<div class="form-group">
							<label>Address (English)</label>
							<textarea type="text" name="address" rows="5" class="form-control" placeholder="House No, Road No, Village, Union, Pouroshava, Upazila, Post Office, Post Code etc." value="<?php echo $mainData['address']; ?>" ><?php echo $mainData['address']; ?></textarea>
						</div>
						<div class="form-group">
							<label>Dictrict </label>
							<select class="selectpicker form-control" data-live-search="true" data-hide-disabled="true" name="district" >
								<option value="">Select your district</option>
								<?php
								$sql = "SELECT * FROM district ORDER BY name ASC";
								$stmt = $connPdo->prepare($sql);
								$stmt->execute();
								foreach ($stmt as $row) {						
									$select = $mainData['district'] == $row['name'] ? 'selected="selected"' : '';
									echo '<option value="' . $row['name'] . '" ' . $select . '>' . $row['name'] . '</option>';
								}
								?>
							</select>
						</div>
						
						<div class="add_info_title">Job Information <i><small>(If any or type "N/A")</small></i></div>
						<div class="form-group">
							<label>Job Position</label>
							<input type="text" name="job_p" class="form-control" placeholder="Job position/designation" value="<?php echo $mainData['job_p']; ?>" />
						</div>
						
						
						<div class="form-group">
							<label>Organization Name</label>
							<input type="text" name="job_ins" class="form-control" placeholder="Institution name" value="<?php echo $mainData['job_ins']; ?>" />
						</div>
						<div class="add_info_title">Other Information</div>
						<div class="form-group">
							<label>Login Password <small>(Please enter password carefully)</small></label>
							<input type="text" name="Password" class="form-control" placeholder="Password" value="<?php echo $_POST['Password']; ?>"  />
						</div>
						<div class="form-group">
							<label>Confirm Login Password <small>(Please enter password carefully)</small></label>
							<input type="text" name="ConPassword" class="form-control" placeholder="Confirm Password" value="<?php echo $_POST['ConPassword']; ?>"  />
						</div>
						<div class="form-group">
							<button id="addNewInfoBtn" class="border-0 btn-block block-main-btn btn btn-success text-uppercase" >
								<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span> 
								<span class="MainBtnText">Update Info</span>
							</button>
							<!-- <button type="submit" class="border-0 btn-block block-main-btn btn btn-success btn-sm" name="add_info_users_req" onclick="return confirm('Do you want to update information?')">Add Info</button> -->
						</div>
					</form>
				</div>
			</div>


	<?php
		} else {
			$error = "Link Expired! You are trying to use the expired link which as valid only 24 hours (1 days after request)";
			echo "<script>window.setTimeout(function(){window.location='addinfo.php?get_req_users' }, 2000); </script>";
		}
	} else {
		$error = "Invalid Link! Maybe you have already used the key in which case it is deactivated.";
		echo "<script>window.setTimeout(function(){window.location='addinfo.php?get_req_users' }, 2000); </script>";
	}
}  else {
	echo "<script>window.location='index.php'</script>";
}

?>
<style>
	.card.loogedin_info_edit_top {
		display: none;
	}

	.body_wrapper_custom {
		box-shadow: none;
	}
</style>