<select class="form-control custom-select" name="batch" id="batch_name_all" onchange="showUser(this.value)" required="">
		<option value=""> Select your batch</option>
	<?php
		foreach ($batchData as $row) {?>
			<option value="<?=$row['batch']?>" <?php echo ($row['batch'] == $_POST['batch']) ? 'selected' : '';?> ><?=$row['batch']?> (<?=$row['session']?>)</option>
		<?php } ?>
</select>
