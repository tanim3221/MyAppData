<?php
error_reporting(0);
session_start();
require __DIR__ . '/inc/header.php';
if (!isset($_SESSION['student_id'])) {
	echo "<script>window.location='index.php'; </script>";
}
$batch = $_SESSION['batch'];
$get_batch = $_GET['batch'];
$loggedin = $data->batchData($batch, $_SESSION['student_id'], 'student_id');
$title_text = $data->batchData('batch', $batch, 'batch');
$dataReport = $data->batchDataMultiple("report_issue", $loggedin['student_id'], "student_id");
$title = $title_text['title'];
?>
<style>
.card-body span {
    border-radius: 5px;
    padding: 0px 5px;
}

.loogedin_info_edit_left_right_report {
    margin-bottom: 100px;
}
</style>
<div class="container loogedin_info_edit_full">
    <div class="row loogedin_info_edit_left_right_report">
        <?php
		if (isset($_GET['database_settings']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')) {
		?>
        <div class="col-md-6 loogedin_info_edit_left">
            <form id="batchNameTitleForm">
                <input type="hidden" name="batch_title_edit" value="true">
                <input type="hidden" name="title_edit" value="true">
                <input type="hidden" name="batch" value="<?= $loggedin['batch'] ?>">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>My Batch Name</label>
                            <input type="text" class="form-control" name="title" placeholder="e.g. Iconic 19"
                                value="<?php echo $title; ?>">
                        </div>
                    </div>
                    <div class="col-md-12">
                        <button id="batchNameTitleBtn" class="border-0 btn-block block-main-btn btn btn-success btn-sm"
                            onclick="return confirm('You agreed to change your database title.')">Save</button>
                    </div>
                </div>
            </form>
        </div>
        <div class="text-danger rounded clearfix col-md-6" id="title_edit_info">
            <span class="float-left" style="position: absolute; padding: 12px;"><i
                    class="fas fa-exclamation-triangle"></i></span>
            <span class="float-right " style="margin-left: 50px;">Use a short and civilized word for the name of your
                batch. Make sure your batch name is not more than three words long and your batch (e.g. 19th) also
                included.</span>
        </div>
        <?php } else if (isset($_GET['faq_view'])) { ?>
            <div class="row">
                <div class="col-md-12">
                <div class="form-group mt-2 sorting_search_view">
            <input type="text" class="form-control border" placeholder="Filter by faq title..." id="sort_search">
        </div>
                </div>
                <div class="col-md-12">
                    
        <div id="accordion" class="sorting_year" style="font-family: 'SolaimanLipi', Arial, sans-serif !important;">
            <div class="faq_view card-columns">
                <?php
					$cnt = 1;
					if ($loggedin['role'] == 'dev') {
						$sql = "SELECT * FROM faq ORDER by serial ASC";
					} elseif ($loggedin['role'] == 'admin') {
						$sql = "SELECT * FROM faq WHERE active='1' AND (for_whom ='all' || for_whom ='onlyadmin') ORDER by serial ASC";
					} else {
						$sql = "SELECT * FROM faq WHERE active='1' AND for_whom='all' ORDER by serial ASC";
					}
					$stmt = $connPdo->prepare($sql);
					$stmt->execute();
					foreach ($stmt as $row) {
					?>
                <div class="admin-padding">
                    <div class="card my-2">
                        <div class="card-header">
                            <a class="card-link text-bold text-primary" data-toggle="collapse"
                                href="#collapse<?= $row['id'] ?>">
                                <?= $cnt ?>. <?= $row['title'] ?>
                            </a>
                        </div>
                        <div id="collapse<?= $row['id'] ?>" class="collapse" data-parent="#accordion">
                            <div class="card-body">
                                <?= $row['details'] ?> <span class="float-right text-danger my-4">Last Modified:
                                    <?= $row['date'] ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <?php $cnt = $cnt + 1;
					} ?>
            </div>
        </div>
        <script>
        $(document).ready(function() {
            $("#sort_search").on("keyup", function() {
                var value = $(this).val().toLowerCase();
                $(".sorting_year .admin-padding").filter(function() {
                    $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
                });
            });
        });
        </script>
                </div>
            </div>

        <?php } else if (isset($_GET['report_info'])) { ?>
        <div class="row" style="width:100%">
            <div class="col-md-6">
                <div class="mb-3">

                    <div class="card-header">
						<i class="fas fa-bug"></i> Create your issue to Admin
                    </div>
                    <!-- <div class="card-body"> -->
                        <form id="contact-form" class="mt-3">
                            <div class="row my-0">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label>Your Batch Admin</label>
                                        <select class="custom-select" name="email_sel">
                                            <option value="">Select any one email</option>
                                            <?php
												$data = $data->getAdminInfo($batch);
												foreach ($data as $row) {
													echo '<option value="' . $row['email'] . '">' . $row['name'] . ' || ' . $row['email'] . '</option>';
												}
												?>
                                        </select>
                                    </div>
                                    <div class="form-group">
                                        <label>Subject</label>
                                        <input class="form-control" name="subject"
                                            placeholder="Enter your short subject" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Write your message</label>
                                        <textarea class="form-control" name="message" id="report_msg" cols="30" rows="9"
                                            placeholder="Write your details message..."
                                            required><?php echo $_POST['message']; ?></textarea>
                                    </div>
                                </div>
                                <input type="hidden" value="true" name="reportInfoToAdmin">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <!-- <div class="g-recaptcha"
                                            data-sitekey="6LeO-7AZAAAAAIkfP_4DKrWY2saTsMye6MOuuUsa"></div>
                                        <br /> -->
                                        <button id="reportSubmitBtn"
                                            class="border-0 btn-block block-main-btn btn btn-success text-uppercase">
                                            <span style="display:none"
                                                class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span>
                                            <span class="MainBtnText">Submit</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    <!-- </div> -->
                </div>
            </div>
            <script>
                $(document).ready(function() {
                    $('#report_msg').summernote({
                        height: 300,
                        minHeight: null,
                        maxHeight: null,
                        focus: false,
                        inheritPlaceholder: true,
                        toolbar: [
                            ['style', ['style']],
                            ['font', ['bold', 'underline', 'clear']],
                            ['color', ['color']],
                            ['para', ['ul', 'ol', 'paragraph']],
                            // ['table', ['table']],
                            ['insert', ['link']],
                            ['view', ['fullscreen', 'codeview']]
                        ]
                    });
                });
            </script>
            <div class="col-md-6 admin_info_report_page">
                <!-- <div id="admin_info"></div> -->
                <?php
            if (sizeof($dataReport)>0){

					$cnt = 1;
					foreach ($dataReport as $row) {
						$data = new Data();
						$dataInd = $data->batchData($loggedin['batch'], $row['email_to'], "email");
					?>
                <div class="card mb-3">
                    <div class="card-header font-weight-bold">
                        <?= $cnt . ". " . $row['subject'] ?> (<b>To: </b> <?= $row['email_to'] ?>)
                    </div>
                    <div class="card-body">
                        <!-- <h5 class="card-title">Special title treatment</h5> -->
                        <p class="card-text"><?= $row['messages'] ?></p>
                        <?= $row['resolve'] == '1' ? "<span class='btn btn-sm btn-success'>Resolved</span>" : "<span class='btn btn-sm btn-danger'>Not Resolved</span>"; ?>
                        <small class="float-right"><?= $row['re_date'] ?></small>
                    </div>
                </div>
                <?php $cnt = $cnt + 1;
					} 
                } else {
                    echo "There is no issues found right now.";
                } ?>

            </div>
        </div>
        <script>
        $(document).ready(function() {
            $("#admin_info").load("request.php?admin_info_show&batch=<?= $loggedin['batch'] ?>&report_info");
        });
        </script>
        <?php } else {
			echo "<script> window.location='home.php'; </script>";
		} ?>
    </div>
</div>
<?php require 'inc/footer.php'; ?>