<?php
error_reporting(0);
session_start();
require __DIR__."/inc/redirect.php";
require __DIR__.'/inc/header.php';
$batch = $_SESSION['batch'];
$get_batch = $_GET['batch'];

$role = $row['frnds'];
if (isset($_SESSION['student_id']) && ($loggedin['frnds'] == '1') && isset($_GET['only_my_friends'])) {
?>

<style>
    *{margin:0;padding:0;-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;-webkit-font-smoothing:antialiased}.tabfcontent ol,.tabfcontent ul{margin-left:25px}.pro-frnds img{width:100%;height:auto;border-radius:unset}.pro-frnds{position:relative!important;width:75px!important;height:75px!important;overflow:hidden;border-radius:50%!important;margin:0 auto;border:4px solid #fff}.tabfcontent{background:#fff;border-left:none;text-align:justify;padding:30px 75px;display:none}.tabfcontent h2{font-size:30px;color:#fff;background:#08003c;text-align:center;border-radius:5px;margin-bottom:20px;padding:10px 0;font-family:Titillium Web,Hind Siliguri}.value{font-size:18px;margin-bottom:10px;margin-left:300px;margin-top:-45px;border-bottom:1px solid #ddd}.tabfcontent h4{margin:0;font-size:18px!important;color:#922109;width:40%;padding:15px 0;text-align:left}.tabfcontent p a i{font-size:33px;color:#119e03;float:right}div#tab-ad li{display:inline}button.tabflinks:focus{color:#fff;border-radius:26px;background:#af0909;outline:0;border:1px solid #fff}.search-name{margin:20px 0 24px 0}#welcome{padding:0 60px}#myInput{width:100%;padding:15px 15px;border-radius:10px}#myInput{border:1px solid #ddd}#myInput:focus{border:1px solid #ddd}.head_friends{font-family:Titillium Web,Hind Siliguri;letter-spacing:6px}#myInput::placeholder{color:#ddd}#myInput::-webkit-input-placeholder{color:#ddd}#myInput::-moz-placeholder{color:#300681}#myInput:-ms-input-placeholder{color:#300681}#welcome h2{padding:60px 10px;margin:0 15px 15px 15px}#myInput:-moz-placeholder{color:#300681}#tab-ad{list-style-type:none;padding:0;margin:0}#tab-ad li a{border:1px solid #ddd;margin-top:-1px;background-color:#f6f6f6;padding:12px;text-decoration:none;font-size:18px;color:#000;display:block}#tab-ad li a:hover:not(.header){background-color:#eee}button.tabflinks{border:none;padding:15px;font-size:15px;border-radius:25px;color:#fff;background:#444;cursor:pointer;font-family:Titillium Web,Hind Siliguri}.login-button button{border:none;padding:10px;font-size:15px;border-radius:4px;color:#fff;background:#444;cursor:pointer;text-align:center}a.login-button button{text-align:center}input[type=text]{font-family:unset}#tab-ad{overflow:auto;white-space:nowrap;border:none;background-color:transparent;font-family:Righteous,cursive;border-radius:4px;text-align:center}#messagebday{color:#3c763d;background-color:#dff0d8;border:1px solid #d6e9c6;font-weight:700;line-height:25px;font-size:15px;padding:15px;border-radius:4px;margin:0 auto;width:90%}.top-page-wrapper{display:none!important}html{overflow:auto;background:##efefef}.static_page{background:##efefef}div.tabf{float:left;border:1px solid #ccc;background-color:#f1f1f1;width:100%;height:100%}.tabfcontent p a i:hover{color:#922109}div.tabf button{display:block;background-color:#444;color:#fff;padding:13px 13px;width:100%;border:none;outline:1px solid #ddd;text-align:left;cursor:pointer;transition:.4s;font-size:17px}div.tabf button:hover{background-color:#8a0017;color:#ddd}div.tabf button.active{background-color:#fff;color:#444}.Writer{max-width:70%;margin-left:24.5%}.head-name{width:100%!important}.head-name{text-align:center;background:#fff}.head-name h1{font-size:45px;color:#130677}.tabfcontent a{text-decoration:none}.wish{font-family:Titillium Web,Hind Siliguri;font-size:28px;color:#130677}@media only screen and (max-width:860px){#myInput{padding:10px 15px}#welcome{padding:15px}.search-name{margin:25px 0 0 0}#tab-ad{width:100%;float:unset}.search-wrapper{width:100%;float:unset;margin:15px 0}.value{font-size:18px;margin-left:unset;margin-top:unset;padding:5px 0;border-bottom:1px solid}.tabfcontent h4{font-size:13px!important;width:55%;padding:5px 0}.tabfcontent h2{font-size:25px;margin-bottom:20px;padding:10px 0}.tabfcontent{padding:30px 15px}.container{width:100%}button.tabflinks{padding:10px;font-size:12px}#messagebday{width:100%;line-height:30px;font-size:14px}div.tabf button{font-size:12px}.head-name h1{font-size:25px}.head-name h4{font-size:18px;font-weight:400}}
</style>

    <div class=" container head-name">
        <?php
        $sql = "SELECT 19th.student_id, 19th.name, 19th.phone,19th.father_name,19th.blood,19th.birth,19th.address,19th.address_bangla, 19th.name_bangla, 19th.email, iconic19.prefer, iconic19.details, iconic19.father_phone FROM 19th INNER JOIN  iconic19 ON 19th.student_id = iconic19.student_id WHERE 19th.batch = '19th'";
        //$sql = "SELECT * from iconic19 WHERE frnds = '1'";
         $today = date('F, d');
        echo "<span class='head_friends text-uppercase text-bold text-white'><h1>TODAY " . date('F, d') . "</h1></span><br>";

        $stmt = $connPdo->prepare($sql);
        $stmt->execute();
        $numRows = $stmt->rowCount();
        foreach ($stmt as $row) {
            $birth = date('F d', strtotime($row['birth']));
            if (date('F d') == $birth) {

                echo "<span class='wish'><i class='fas fa-birthday-cake'></i> HAPPY BIRTHDAY <i class='fas fa-birthday-cake'></i><br><b>" . $row['name_bangla'] . "</b><br></span>";
            } else {
                echo "";
            }
        }

        ?>

        <div class="search-name">
            <div class="search-wrapper mb-3">
                <form>
                    <input type="text" required class="search-box" id="myInput" onkeyup="myFunctionSearch()" placeholder="Friends Search.." title="Type what you want" />
                </form>
            </div>

            <?php
            $sql = "SELECT 19th.student_id, 19th.name, 19th.phone,19th.photo,19th.father_name,19th.blood,19th.birth,19th.address,19th.district,19th.address_bangla, 19th.name_bangla, 19th.email, iconic19.prefer,iconic19.id, iconic19.details, iconic19.father_phone FROM 19th INNER JOIN  iconic19 ON 19th.student_id = iconic19.student_id WHERE 19th.batch = '19th' AND 19th.frnds = '1' ORDER by 19th.name";
            //$sql = "SELECT * from iconic19 WHERE frnds = '1' ORDER by name";
            $stmt = $connPdo->prepare($sql);
            $stmt->execute();
            $numRows = $stmt->rowCount();
            ?>

            <div id="tab-ad">
                <li>
                    <button class="tabflinks" onclick="step(event, 'welcome')" id="defaultOpen"> Friends Empire </button>
                </li>
                <?php
                foreach ($stmt as $rows) {   ?>
                    <li>
                        <button class="tabflinks" onclick="step(event, '<?php echo $rows['id'] ?>')">
                            <?php echo $rows['name'] ?></button>
                    </li>

                <?php  } ?>
            </div>
        </div>
    </div>

    <?php

    $sql = "SELECT 19th.student_id, 19th.name, 19th.phone,19th.photo,19th.father_name,19th.blood,19th.birth,19th.address,19th.district,19th.address_bangla, 19th.name_bangla, 19th.email, iconic19.prefer,iconic19.id, iconic19.details, iconic19.father_phone FROM 19th INNER JOIN  iconic19 ON 19th.student_id = iconic19.student_id WHERE 19th.batch = '19th' AND 19th.frnds = '1'";
    $stmt = $connPdo->prepare($sql);
    $stmt->execute();
    $numRows = $stmt->rowCount();
     ?>
    <div id="welcome" class="tabfcontent">
        <h2 class="text-bold">বন্ধুত্বটা আজীবনের ** ভালোবাসি বন্ধুত্ব ** ভালোবাসি বন্ধু তোদের</h2>

    </div>
    <?php
   foreach ($stmt as $row) {  ?>

        <div id="<?php echo $row['id'] ?>" class="tabfcontent">
            <h2>

                <?php
                $birth = date('F d', strtotime($row['birth']));

                if (date('F d') == $birth) {

                    echo "<span class='wish'><i class='fas fa-birthday-cake'></i> HAPPY BIRTHDAY <i class='fas fa-birthday-cake'></i><br></span>";
                } else {
                    echo "";
                }

                $birthday = $row['birth'];

                $date_name = date('l', strtotime($birthday));
                $month = date('F', strtotime($birthday));
                $date = date('d', strtotime($birthday));
                $year = date('Y', strtotime($birthday));
                ?>
                <div class="pro-frnds"> <img class="frnds-img" src="image/<?php echo $row['photo'] ?>"></div>
                <?php echo $row['name'] ?>
            </h2>
            <h4>Fathers Name</h4>
            <div class="value"><?php echo $row['father_name'] ?></div>
            <h4>Blood Group</h4>
            <div class="value"><?php echo $row['blood'] ?></div>
            <h4>Birthday</h4>
            <div class="value"><?php echo "" . $date_name . ", " . $month . " " . $date . ", " . $year . ""; ?></div>
            <h4>Mobile</h4>
            <div class="value"> <a href="tel:<?php echo $row['phone'] ?>"><?php echo $row['phone'] ?></a></div>
            <h4>Email</h4>
            <div class="value"> <a href="mailto:<?php echo $row['email'] ?>"><?php echo $row['email'] ?></a></div>
            <h4>Fathers Mobile</h4>
            <div class="value"> <a href="tel:<?php echo $row['father_phone'] ?>"><?php echo $row['father_phone'] ?></a></div>
            <h4>Prefer Vehicles</h4>
            <div class="value"><?php echo $row['prefer'] ?></div>
            <h4>Address</h4>
            <div class="value"><?php echo $row['address'] ?></div>
            <h4>Address (বাংলা)</h4>
            <div class="value"><?php echo $row['address_bangla'] ?></div>
            <h4>District</h4>
            <div class="value"><?php echo $row['district'] ?></div>
            <h4>Details Address</h4>
            <div class="value-details"><?php echo $row['details'] ?></div>
        </div>

        <script>
            function step(evt, stepName) {
                var i, tabfcontent, tabflinks;
                tabfcontent = document.getElementsByClassName("tabfcontent");
                for (i = 0; i < tabfcontent.length; i++) {
                    tabfcontent[i].style.display = "none";
                }
                tabflinks = document.getElementsByClassName("tabflinks");
                for (i = 0; i < tabflinks.length; i++) {
                    tabflinks[i].className = tabflinks[i].className.replace(" active", "");
                }
                document.getElementById(stepName).style.display = "block";
                evt.currentTarget.className += " active";
            }

            // Get the element with id="defaultOpen" and click on it
            document.getElementById("defaultOpen").click();
        </script>

        <script>
            function myFunctionSearch() {
                var input, filter, div, li, button, i, txtValue;
                input = document.getElementById("myInput");
                filter = input.value.toUpperCase();
                div = document.getElementById("tab-ad");
                li = div.getElementsByTagName("li");
                for (i = 0; i < li.length; i++) {
                    button = li[i].getElementsByTagName("button")[0];
                    txtValue = button.textContent || button.innerText;
                    if (txtValue.toUpperCase().indexOf(filter) > -1) {
                        li[i].style.display = "";
                    } else {
                        li[i].style.display = "none";
                    }
                }
            }
        </script>

<?php     }
    $connPdo = null;

    require 'inc/footer.php';
} else {
    echo "<script>window.location='index.php';</script>";
}
?>