<?php
session_start();
error_reporting(0);
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
date_default_timezone_set("Asia/Dhaka");
require __DIR__."/inc/redirect.php";

if (isset($_SESSION['student_id'])) {

	require __DIR__ . '/inc/header.php';

	$student_id = $_SESSION['student_id'];
	$search_select = ($detect->isMobile()) ? 'custom-select' : 'selectpicker form-control';
	$getNotice = $others->getLimitData("SELECT * FROM notice WHERE batch='" . $_SESSION['batch'] . "' ORDER by id DESC LIMIT 10");
	$getNoticeAdmin = $others->getLimitData("SELECT * FROM notice WHERE batch ='Controller' ORDER by id DESC LIMIT 10");
	$getMostUseTrend = $others->getLimitData("SELECT *, COUNT(keywords) AS value_occurrence FROM search GROUP BY keywords ORDER BY value_occurrence DESC LIMIT 7");
	$getMostUseKey = $others->getLimitData("SELECT * FROM search where id in (SELECT max(id) FROM search GROUP BY keywords) order by id desc LIMIT 7");

	## Delete QR Code
	$files = glob('phpqrcode/qr_code/*'); // get all file names
		foreach($files as $file){ // iterate files
		if(is_file($file)) {
			unlink($file); // delete file
		}
	}
	## Delete QR Code
?>
	<script>
		function changeBatch_search() {
			$("#nbc-searchblue1").submit();
		}
	</script>
	<?php if (!isset($_COOKIE['bdpopupclosed']) == "yesClosed") {  ?>
		<div class="wish_them_popup_wrapper">
			<div class="wish_them_popup">
				<div class="mobile_nav_head">
					<div class="mobile_nav_title popup"></div>
					<div class="mobile_nav_close popup">
						<i class="mdi mdi-close"></i>
					</div>
				</div>
				<div class="today_birthday_class_wrapper">
					<div class="spinner_log">
						<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
					</div>
				</div>
			</div>
		</div>
	<?php } ?>
	<div class="loggedin-body">
		<div class="content iconic-body">
			<div class='head_title_home' id="search_results">
				<h2>Search</h2>
			</div>
			<?php //print_r($loggedin) 
			?>
			<div class="saerch_form_view">
				<form id="nbc-searchblue1" method="REQUEST" action="<?= $_SERVER['REQUEST_URI'] ?>#search_results" enctype="multipart/form-data" autocomplete="off">
					<div class="search-home">
						<div class="search_input_text">
							<input type="text" id="wc-searchblueinput1" class="nbc-searchblue1 search_input_id" placeholder="" name="query" value="<?php echo $_REQUEST['query']; ?>" type="search" required="required">
							<div class="search_cross" style="display:none"><i class="mdi mdi-close mdi-24px"></i></div>
						</div>
						<div class="search_input_cat">
							<select id='nbc-searchbluesubmit1' class="<?= $search_select ?>" onchange="changeBatch_search()" name="category" required>
								<option value="">Where to search?</option>
								<optgroup label="AIS Students">
									<option value="any_batch" <?php echo $_REQUEST['category'] == 'any_batch' ? ' selected="selected"' : ''; ?>>Any Batch</option>
									<?php
									foreach ($batchData as $row) { ?>
										<option value="<?= $row['batch'] ?>" <?php echo $_REQUEST['category'] == $row['batch'] ? ' selected="selected"' : ''; ?>><?= $row['batch'] ?> (<?= $row['session'] ?>)</option>
									<?php } ?>
								</optgroup>
								<optgroup label="AIS Teachers & Stuff">
									<option value="teachers" <?php echo $_REQUEST['category'] == 'teachers' ? ' selected="selected"' : ''; ?>>Teachers</option>
									<option value="office_stuff" <?php echo $_REQUEST['category'] == 'office_stuff' ? ' selected="selected"' : ''; ?>>Office Stuff</option>
								</optgroup>
							</select>
						</div>
					</div>
					<input type="hidden" name="search" value="true">
				</form>
			</div>
			<div id="search_his" style="display:none">
				<div class="spinner_log">
					<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
				</div>
			</div>
			<div class="info-text">
				<div class="search_info_text">
					Note that you can search here by Name (Bangla and English), Batch (e.g. 19th), Student ID, Mobile, Blood Group (e.g. O+), and District keywords.
				</div>
				<div style="color:green">
					To access a Facebook profile, click on the photo.
				</div>
			</div>
			<?php
			if (!isset($_GET['query'])) {
			?>
				<div class="card-deck" id="home_card_deck">
					<?php
					$count = sizeof($getNotice);
					$countAdmin = sizeof($getNoticeAdmin);
					if ($count !== 0  ||  $countAdmin !== 0) {
					?>
						<div class="card">
							<div class="card-body">
								<h5 class="card-title">Notice For You</h5>
								<div class="list-group list-group-flush">
									<?php

									foreach ($getNotice as $row) {
										if (($_SESSION['batch'] == $row['batch']) && ($row['active'] == 1)) {
											echo '<span class="list-group-item list-group-item-action flex-column align-items-start">
											<div class="d-flex w-100 justify-content-between">
												<h6 class="mb-1">' . $row['title'] . '</h6>
												<small>' . date("d-m-Y h:i A", strtotime(str_replace("/", "-", $row['date']))) . '</small>
											</div>
											<p class="mb-1">' . $row['message'] . '</p>
											<small>By ' . $row['name'] . '</small>
										</span>';
										}
									}

									foreach ($getNoticeAdmin as $row) {
										if ($row['active'] == 1) {
											echo '<span class="list-group-item list-group-item-action flex-column align-items-start">
											<div class="d-flex w-100 justify-content-between">
												<h6 class="mb-1">' . $row['title'] . '</h6>
												<small>' . date("d-m-Y h:i A", strtotime(str_replace("/", "-", $row['date']))) . '</small>
											</div>
											<p class="mb-1">' . $row['message'] . '</p>
											<small>By ' . $row['name'] . '</small>
										</span>';
										}
									}

									?>
								</div>
							</div>
						</div>
					<?php
					}
					// else {
					// 	echo "Opss! No notice for you.";
					// }
					/*
					<div class="card">
						<div class="card-body">
							<h5 class="card-title">Last Search</h5>
							<div class="list-group list-group-flush">
								<?php
								foreach ($getMostUseKey as $row) {
									echo '<span class="list-group-item list-group-item-action flex-column align-items-start">
								<div class="d-flex w-100 justify-content-between">
									<h6 class="mb-1"><small>Keyword: </small><i>' . $row['keywords'].'</i></h6>
									<small>' . ucwords(str_replace("_", " ", $row['key_cat'])) . '</small>
								</div>
								<small>By one of the member of <i>' .  $row['batch'] . ' Batch </i> <br>Dated: ' .  date("d-m-Y h:i A", strtotime($row['date'])) . '</small>
							</span>';
								}
								?>
							</div>
						</div>
					</div>
					<div class="card">
						<div class="card-body">
							<h5 class="card-title">Trending Search</h5>
							<div class="list-group list-group-flush">
								<?php
								foreach ($getMostUseTrend as $row) {
									echo '<span class="list-group-item list-group-item-action flex-column align-items-start">
								<div class="d-flex w-100 justify-content-between">
									<h6 class="mb-1"><small>Keyword: </small><br><i>' . $row['keywords'].'</i></h6>
									<small>' . ucwords(str_replace("_", " ", $row['key_cat'])) . '</small>
								</div>
							</span>';
								}
								?>
							</div>
						</div>
					</div>
					*/ ?>
				</div>
			<?php } ?>
		</div>
		<?php
		require __DIR__ . '/inc/search.php';
		?>
		<script src="ais-assets/js/typing_effect.js"></script>
	</div>
	<?php require __DIR__ . '/inc/footer.php'; ?>
<?php 	} else {
	echo "<script>window.location='index.php'; </script>";
} ?>