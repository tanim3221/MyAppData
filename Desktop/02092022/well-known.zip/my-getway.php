<?php
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
session_start();
//view as others
if (isset($_GET['view_as_others'])) {
    if (isset($_GET['batch']) && isset($_GET['student_id'])  && isset($_GET['key']) && $_GET['key'] == md5($_GET['student_id'])) {
        session_start();
        $student_id = $_GET['student_id'];
        $batch = $_GET['batch'];
        $_SESSION['student_id'] = $student_id;
        $_SESSION['batch'] = $batch;
        if (isset($_SESSION['student_id']) && isset($_SESSION['batch'])) {
            header("Location: home.php");
            exit();
        } else {
            header("Location: only-for-me.php");
            exit();
        }
    } else {
        unset($_SESSION['batch']);
        unset($_SESSION['student_id']);
        header("Location: index.php");
        exit();
    }
} elseif (isset($_GET['submit_role']) && isset($_GET['role']) && isset($_GET['id'])) {
    require __DIR__. '/controller/conn.php';
    $connPdo = $pdo->open();
    $id = $_GET['id'];
    $role = $_GET['role'];
    $batch = $_GET['batch'];
    $LastUpdateTime = date("Y-m-d H:i:s");
    $in = "UPDATE {$batch} SET role='$role', LastUpdateTime='$LastUpdateTime' WHERE id=".$id;
    $stmt = $connPdo->prepare($in);
    if ($stmt->execute()) {
        header("Location: only-for-me.php?p=&database=2");
        exit();
    } else {
        header("Location: index.php");
        exit();
    }
} else {
    header("Location: index.php");
    exit();
}
