<?php
session_start();

require __DIR__ . '/controller/conn.php';
include __DIR__ . '/controller/data.php';
require __DIR__ . '/controller/others.php';
$conn = $pdo->open();
$data = new Data();
$others = new Others();
$othersData = new Data();
$batch = $_SESSION['batch'];
$student_id = $_SESSION['student_id'];

$loggedin = $data->batchData($batch, $student_id, 'student_id');

## Read value
$draw = $_POST['draw'];
$row = $_POST['start'];
$rowperpage = $_POST['length']; // Rows display per page
$columnIndex = $_POST['order'][0]['column']; // Column index
$columnName = $_POST['columns'][$columnIndex]['data']; // Column name
$columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
$searchValue = $_POST['search']['value']; // Search value
$view_batch = $_POST['view_batch'];
$my_batch = $_POST['my_batch'];
$other_batch_view = $_POST['other_batch_view'];
$inactive_view = $_POST['inactive_view'];
$inactive_private_students = $_POST['inactive_private_students'];
$inactive_public_students = $_POST['inactive_public_students'];
$active_private_students = $_POST['active_private_students'];
$active_public_students = $_POST['active_public_students'];
$controller_view = $_POST['controller_view'];

$mainArray = array();

## Search 
$mainQuery = " ";
if (($controller_view == "controller_view") && ($inactive_private_students == "inactive_private_students") && ($loggedin['role'] == 'dev')) {
    $mainQuery = " AND active = :active AND showing=:showing";
    $mainArray = array(
        'active' => "0",
        'showing' => "0"
    );

} elseif (($controller_view == "controller_view") && ($inactive_public_students == "inactive_public_students") && ($loggedin['role'] == 'dev')) {
    $mainQuery = " AND active = :active AND showing=:showing";
    $mainArray = array(
        'active' => "0",
        'showing' => "1"
    );

} elseif (($controller_view == "controller_view") && ($active_public_students == "active_public_students") && ($loggedin['role'] == 'dev')) {
    $mainQuery = " AND active = :active AND showing=:showing";
    $mainArray = array(
        'active' => "1",
        'showing' => "1"
    );

} elseif (($controller_view == "controller_view") && ($active_private_students == "active_private_students") && ($loggedin['role'] == 'dev')) {
    $mainQuery = " AND active = :active AND showing=:showing";
    $mainArray = array(
        'active' => "1",
        'showing' => "0"
    );

} elseif (($controller_view == "controller_view") && ($loggedin['role'] == 'dev')) {
    $mainQuery = " ";
    $mainArray = array();
} elseif (($inactive_view == "inactive_view") && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev') && ($loggedin['batch'] == $view_batch)) {
    $mainQuery = " AND active = :active";
    $mainArray = array(
        'active' => '0'
    );
} elseif (($my_batch == "my_batch") && ($loggedin['role'] == 'admin')) {
    $mainQuery = " AND active = :active";
    $mainArray = array(
        'active' => "1"
    );
} elseif ($other_batch_view == "other_batch_view") {
    $mainQuery = " AND active = :active AND showing=:showing";
    $mainArray = array(
        'active' => "1",
        'showing' => "1"
    );
}

$mainOrder = " ORDER BY RIGHT(student_id, 5) ASC";

if ($searchValue != '') {
    $mainQuery = $mainQuery . " AND (
        student_id LIKE :student_id OR 
        phone LIKE :phone OR 
        name LIKE :name OR 
        blood LIKE :blood OR 
        email LIKE :email ) ";
    $mainArrayS = array(
        'student_id' => "%$searchValue%",
        'name' => "%$searchValue%",
        "phone" => "%$searchValue%",
        "blood" => "%$searchValue%",
        "email" => "%$searchValue%",
    );

    $mainArray = array_merge($mainArray, $mainArrayS);
}
// else {
//     $searchQuery = $mainQuery;
//     // $searchArray = $mainArray;
// }

## Total number of records without filtering
$stmt = $conn->prepare("SELECT COUNT(*) AS allcount FROM {$view_batch} WHERE 1 " . $mainQuery . " " . $mainOrder);
$stmt->execute($mainArray);
$records = $stmt->fetch();
$totalRecords = $records['allcount'];

## Total number of records with filtering
$stmt = $conn->prepare("SELECT COUNT(*) AS allcount FROM {$view_batch} WHERE 1 " . $mainQuery);
$stmt->execute($mainArray);
$records = $stmt->fetch();
$totalRecordwithFilter = $records['allcount'];

$orderBy = (($columnName !== '') ? " ORDER BY " . $columnName . " " . $columnSortOrder : $mainOrder);
## Fetch records
$stmt = $conn->prepare("SELECT * FROM {$view_batch} WHERE 1 " . $mainQuery . "  " . $orderBy . "  LIMIT :limit,:offset");

// Bind values
foreach ($mainArray as $key => $search) {
    $stmt->bindValue(':' . $key, $search, PDO::PARAM_STR);
}

$stmt->bindValue(':limit', (int)$row, PDO::PARAM_INT);
$stmt->bindValue(':offset', (int)$rowperpage, PDO::PARAM_INT);
$stmt->execute();
$empRecords = $stmt->fetchAll();

$data = array();

foreach ($empRecords as $row) {
    $img = $row['photo'];
    $id = $row['id'];
    $student_id = $row['student_id'];
    $phone = $row['phone'];
    $name = $row['name'];
    $email = $row['email'];
    $fb_id = $row['fb_id'];
    $facebook_url = $others->get_facebook_url($fb_id);
    if (($row['showing'] == '1') && ($row['active'] == '1')) {
        $btnColor = 'success';
    } else if ($row['active'] == '0') {
        $btnColor = 'danger';
    }else if ($row['showing'] == '0') {
        $btnColor = 'warning';
    }
    $view = '<button type="button" class="view_btn btn btn-' . $btnColor . ' btn-sm" data-batch="' . $view_batch . '" data-id="' . $row['id'] . '" id="view_btn_stds"><i class="fas fa-eye"></i></button>';

    if (($my_batch == "my_batch") && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev') && $loggedin['batch'] == $view_batch) {
        $edit = '
        <div class="btn-group">
        <a type="button" class="btn btn-warning btn-sm" href="dataview.php?my_batch_update&id=' . $id . '&key=' . md5($phone) . '&batch=' . $view_batch . '&name=' . str_replace(' ', '_', $name) . '&action=update"><i class="fas fa-edit"></i></a>
        <button class="btn btn-primary btn-sm" id="openPassChangeWindow" data-batch="' . $batch . '" data-id="' . $id . '" id="changePassMyBatch"><i class="fas fa-lock"></i></button>
        </div>';
    } elseif (($loggedin['role'] == 'dev' &&  $controller_view == "controller_view")) {
        $edit = '
        <a type="button" class="btn btn-danger btn-sm" onclick="return confirm("You have agreed to delete information of ' . $name . ' (' . $student_id . ')")" href="dataview.php?del_batch_info&id=' . $id . '&batch=' . $view_batch . '&name=' . str_replace(' ', '_', $name) . '&action=delete"><i class="fas fa-trash-alt"></i></a>
        <a type="button" class="btn btn-warning btn-sm" href="dataview.php?controller_view_update&id=' . $id . '&key=' . md5($phone) . '&batch=' . $view_batch . '&name=' . str_replace(' ', '_', $name) . '&action=update"><i class="fas fa-edit"></i></a>
        ';
    } elseif ($inactive_view == "inactive_view") {
        $keyAdd = $othersData->getOthersData('add_info_key', $student_id, 'student_id', 'DESC');
        $key = $keyAdd['key'];
        $edit = "
        <div class='btn-group-vertical'>
           <a type='button' onclick='return confirm('You have agreed to delete information of " . $student_id . "')'     class='btn btn-danger btn-sm'  href='dataview.php?del_batch_info&id=" . $id . "&batch=" . $batch . "&name=" . str_replace(' ', ' _', $name) . "&action=delete'><i class='fas fa-trash-alt'></i></a>
    </div>
    <form method='post' enctype='multipart/form-data' action='addinfo.php?get_info_add_req' name='add' id='inactive_form'>
        <input type='hidden' name='batch' value='" . $batch . "' />
        <input type='hidden' name='student_id' value='" . $student_id . "' />
        <input type='hidden' name='email' value='" . $email . "' />
        <button  onclick='return confirm('You have agreed to send request again to " . $email . " (" . $student_id . ")')' class='btn btn-success btn-sm' type='submit'> <i class='fas fa-paper-plane'></i></button>
    </form>
    <form method='post' enctype='multipart/form-data' action='dataview.php?admin_generate_link_add_info' id='inactive_form'>
        <input type='hidden' name='email' value='" . $email . "' />
        <input type='hidden' name='student_id' value='" . $student_id . "' />
        <button class='btn btn-primary btn-sm'  onclick='return confirm('You have agreed to generate new link for " . $email . " (" . $student_id . ")')'  name='admin_generate_link_add_info' type='submit'><i class='fas fa-sync-alt'></i></button>
    </form>
                                                                        
    <a type='button' target='_blank'    onclick='return confirm('You have agreed to add information of " . $student_id . " - " . $email . "')'   class='btn btn-info btn-sm' href='addinfo.php?add_info_users&key=" . $key . "&action=add'><i class='fas fa-plus'></i></a> ";
    } else {
        $edit = "";
    }


    if (empty($img)) {
        $img = "  <div class='avatar'><a class='fb_id' target='_blank' href='https://www.facebook.com/" . $facebook_url . "'><img src='ais-assets/icon/demo.png'><img class='img-top' src='ais-assets/icon/fb.png'></a></div>";
    } else {
        $img = "<div class='avatar'><a class='fb_id' target='_blank' href='https://www.facebook.com/" . $facebook_url . "'><img src='image/" . $img . "'><img class='img-top' src='ais-assets/icon/fb.png'></a></div>";
    }
    $data[] = array(
        "photo" => $img,
        "student_id" => $row['student_id'],
        "name" => $row['name'],
        "phone" => $row['phone'],
        "blood" => "<span style='color:red; font-weight:bold;'>".$row['blood']."</span>",
        "email" => $row['email'],
        "action" =>  $view . " " . $edit
    );
}

## Response
$response = array(
    "draw" => intval($draw),
    "iTotalRecords" => $totalRecords,
    "iTotalDisplayRecords" => $totalRecordwithFilter,
    "aaData" => $data
);

echo json_encode($response);
