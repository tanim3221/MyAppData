<?php
session_start();
ob_start();
error_reporting(0);
date_default_timezone_set("Asia/Dhaka");
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

require __DIR__ . '/controller/conn.php';
require __DIR__ . '/controller/others.php';
require_once __DIR__. '/controller/data.php';
require __DIR__ . '/controller/mobile_detect.php';
require __DIR__ . '/inc/head.php';
$connPdo = $pdo->open();
$detect = new Mobile_Detect;
$others = new Others;
$data = new Data();

$batchData = $others->getBatch();
$getMaintenance = $others->getMaintenance();

$redirect_url = empty($_SESSION['redirect_url']) ? "" : $_SESSION['redirect_url'];

if (isset($_SESSION['student_id']) && isset($_SESSION['batch'])) {
	if($redirect_url !== ""){
		header('Location: '.$redirect_url.'');
		unset($_SESSION['redirect_url']);
	} else {
		header('Location: home.php');
	}
	exit();
} else if (!isset($_SESSION['student_id']) && !isset($_SESSION['batch']) && isset($_COOKIE['SECURE_LOG'])) {
	$secure_log = $others->getDecrypted($_COOKIE['SECURE_LOG']);
	$cookie_split = explode("/",$secure_log);
	$student_id_cookie = $cookie_split[0];
	$batch_cookie = $cookie_split[1];
	$_SESSION['student_id'] = $student_id_cookie;
	$_SESSION['batch'] = $batch_cookie;
	if($redirect_url !== ""){
		header('Location: '.$redirect_url.'');
		unset($_SESSION['redirect_url']);
	} else {
		header('Location: home.php');
	}
	exit();
}

ob_end_flush();

$app_url2 = '#';
$app_url = 'https://github.com/tanim3221/ais_family_app/raw/master/app/release/aisFamily25072021.apk';
?>
<!DOCTYPE html>
<html>
<?php  
if (!isset($_COOKIE['closed']) && ($_COOKIE['closed'] !== 'closed')) { ?>
	<div class="wrong_info_report_card">
		<div class="card card_wrong_info_report">
			<span class="close_btn"><i class="mdi mdi-close mdi-18px"></i></span>
			<div class="card-body wrong_info_report_card_body text-center">
				<div class="title_text">
					<h4 class="text-uppercase app_download_win">Download AIS Family Database App</h4>
					<p class="sub_title_text_app">This app is a great way to connect AIS Family Database with you.</p>
				</div>
				<div class="download_button">
					<button class="btn btn-lg btn-primary download_btn_click" onclick="window.location.href='<?= $app_url ?>'">Download Now</button>
				</div><span class="download_app_window_footer">&copy; AIS Family Database Team</span>
			</div>
		</div>
	</div>
<?php } 
$batch_name = "<span class='selected_batch'></span>";
?>
<body>
	<div class="center_admin_info_login">
		<div class="center-login-home">
			<div class="row">
				<div class="col-md-7 login_title">
					<!-- <img  src='ais-assets/icon/demo.png'> -->
					<h3 class="text-center login_title">AIS FAMILY</h3>
					<h5>Better way to connect with Department of AIS, University of Rajshahi</h5>
					<div class="row admin_info_footer">
			<div class="col-md-12 admin_info_title">
				<div id="admin_info_show"></div>
			</div>
		</div>
				</div>
				<div class="col-md-5 login_info_input">
					<form action="" class="login" id="login" autocomplete="on">
						<div class="form-group">
							<label>Batch</label>
							<?php include 'batch.php'; ?>
						</div>
						<div class="form-group">
							<label>Student ID</label>
							<input class="form-control" type="tel" inputmode="numeric" pattern="[0-9]*" name="student_id" placeholder="e.g. 1610000000" value="<?= $_POST['student_id'] ?>" required="" />
						</div>
						<div class="form-group">
							<label>Password</label>
							<div class="input-group mb-3">
								<input class="form-control" type="password" class="pwd" id="users_pass" value="<?= $_POST['Password'] ?>" name="Password" placeholder="Password" required="" />
								<div class="input-group-append">
									<span class="input-group-text bg-white">
										<span class="show_pass" style="cursor:pointer;"><i class="fas fa-eye"></i></span>
										<span class="hide_pass" style="display:none; cursor:pointer;"><i class="fas fa-eye-slash"></i></span>
									</span>
								</div>
							</div>
						</div>
						<div class="form-group">
							<div class="pretty p-svg p-curve">
								<input type="checkbox" id="remember" name="remember" <?php if (isset($_COOKIE["SECURE_LOG"])) { ?> checked <?php } ?>>
								<div class="state p-primary">
									<!-- svg path -->
									<svg class="svg svg-icon" viewBox="0 0 20 20">
										<path d="M7.629,14.566c0.125,0.125,0.291,0.188,0.456,0.188c0.164,0,0.329-0.062,0.456-0.188l8.219-8.221c0.252-0.252,0.252-0.659,0-0.911c-0.252-0.252-0.659-0.252-0.911,0l-7.764,7.763L4.152,9.267c-0.252-0.251-0.66-0.251-0.911,0c-0.252,0.252-0.252,0.66,0,0.911L7.629,14.566z" style="stroke: white;fill:white;"></path>
									</svg>
									<label>Save Login</label>
								</div>
							</div>
						</div>
						<input type="hidden" name="login-student" value="<?=md5(date("h"))?>">
						<div class="form-group mt-3">
							<button id="loginBtn" class="border-0 btn-block block-main-btn btn btn-success text-uppercase" >
								<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span> 
								<span class="MainBtnText">Login</span>
							</button>
							<!--<a href="../tutorial/apptutorial.php"><img style="width:20px; height:20px;" border="0" alt="Installation info" src="../tutorial/information.png"></a>-->
							<span onclick="window.location.href='<?= $app_url ?>'" class="border-0 btn-block block-sec-btn btn btn-primary mobile_button_down_app text-uppercase">Download App</span>
							<br><br>
							<div class="clearfix">
								<span class="float-left"><a href="#" id="getMyOwnRequest"> Not yet updated? </a></span>
								<span class="float-right"><a href="#" id="getMyOwnPassResetRequest"> Forgot your password? </a></span>
							</div>
					</form>
				</div>
			</div>
		</div>
		
	</div>
</body>
<script type="text/javascript">
	$(document).ready(function() {
		var setCookie = function(cname, cvalue, exdays) {
			var d = new Date();
			d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
			var expires = "expires=" + d.toUTCString();
			document.cookie = cname + "=" + cvalue + "; " + expires;
		}
		var getCookie = function(cname) {
			var name = cname + "=";
			var ca = document.cookie.split(';');
			for (var i = 0; i < ca.length; i++) {
				var c = ca[i];
				while (c.charAt(0) == ' ') c = c.substring(1);
				if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
			}
			return "";
		}
		jQuery(document).ready(function($) {
			console.log(getCookie("closed"));
			if (getCookie("closed") == "closed") {
				$(".wrong_info_report_card").hide();
			}
			jQuery(".card_wrong_info_report .close_btn, .download_btn_click").click(function() {
				jQuery(".wrong_info_report_card").remove();
				setCookie("closed", "closed", 1);
			});
		});
	});
	$(document).ready(function() {
		$('#batch_name_all').on('change', function() {
			//var optionValue = $(this).val();
			//var batch_name = $('#dropdownList option[value="'+optionValue+'"]').text();
			var batch_name = $("#batch_name_all option:selected").text();
			$(".selected_batch").text(batch_name);
		});
	});
	$(document).ready(function() {
		$('.card_wrong_info_report .close_btn').on('click', function() {
			$(".wrong_info_report_card").hide();
			//window.location.reload();
		});
	});
	$(document).ready(function() {
		$('.show_pass').click(function() {
			$('#users_pass').attr('type', 'text');
			$('.show_pass').css('display', 'none');
			$('.hide_pass').css('display', 'block');
		});
		$('.hide_pass').click(function() {
			$('#users_pass').attr('type', 'password');
			$('.show_pass').css('display', 'block');
			$('.hide_pass').css('display', 'none');
		});
	});
	$(function() {
		$("[data-toggle=popover]").popover();
	});

	function showUser(str) {
		if (str == "") {
			document.getElementById("admin_info_show").innerHTML = "";
			return;
		}
		var xmlhttp = new XMLHttpRequest();
		xmlhttp.onreadystatechange = function() {
			if (this.readyState == 4 && this.status == 200) {
				document.getElementById("admin_info_show").innerHTML = this.responseText;
			}
		}
		xmlhttp.open("GET", "request.php?admin_info_show&batch=" + str, true);
		xmlhttp.send();
	}
</script>

<div id="myModalLoginInfo" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog modal-dialog-scrollable modal-xl login_modal_view">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title modal_login_info_title">Login Info</h4>
					<!-- <div class="spinner_log">
						<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
					</div> -->
					<span data-dismiss="modal"><i class="mdi mdi-close mdi-24px"></i></span>
				</div>
				<div class="modal-body" id='login_view_info'>
					<div class="spinner_log">
						<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
					</div>
				</div>

			</div>
		</div>
	</div>

</html>
