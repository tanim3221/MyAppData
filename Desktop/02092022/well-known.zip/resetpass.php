<?php
session_start();
error_reporting(0);
// error_reporting(E_ALL);
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
date_default_timezone_set("Asia/Dhaka");
require __DIR__.'/controller/conn.php';
include __DIR__.'/inc/head.php';
require __DIR__.'/PHPMailer/PHPMailerAutoload.php';
require __DIR__.'/controller/mail.php';
require __DIR__.'/controller/others.php';
$connPdo = $pdo->open();
$mailSend = new Mail();
$others = new Others();
$batchData = $others->getBatch();

$msg = $error = '';

if (isset($_GET["final_reset_mail"])){
	if (isset($_GET["key"]) && isset($_GET["action"]) && ($_GET["action"]=="reset") && !isset($_POST["action"])){
		$key = $_GET["key"];
		$curDate = date("Y-m-d H:i:s");
		$sql = "SELECT * FROM `password_reset_temp` WHERE `key`='".$key."';";
		$stmt = $connPdo->prepare($sql);
		$stmt->execute();
		$numRows = $stmt->rowCount();
		if ($numRows==0){
			$error = "Invalid Link! Maybe you have already used the key in which case it is deactivated.";
			echo "<script>window.setTimeout(function(){ window.location='resetpass.php?pass_reset_request_get'; }, 3000); </script>";
	}else{
		$row = $stmt->fetch();
		$expDate = $row['expDate'];
		$batch = $row["batch"];
		$email = $row["email"];
		if ($expDate >= $curDate){
	?>
	<div class="center-login">
	<br>	<h3 class="text-center header-reset text-uppercase">Create new password</h3><br>
		<form id="final_reset_mail_form">
		
			<div class="form-group">
				<label class="label">
				New Password
				</label>
				<input class="form-control" type="text" name="pass1" required /> </div>
			<div class="form-group">
				<label class="label">
				Confirm New Password
				</label>
				<input type="text" class="form-control" name="pass2" required /> </div>
				
			<div class="form-group">
				<input type="hidden" name="email" value="<?php echo $email;?>" />
				<input type="hidden" name="batch" value="<?=$batch?>" />
				<input type="hidden" name="action" value="update" >
				<input type="hidden" name="newPassReset" value="true" >
					<button id="passResetNewBtn" class="border-0 btn-block block-main-btn btn btn-success text-uppercase" >
						<span style="display:none" class="spinnerLoad mdi mdi-18px mdi-spin mdi-loading mdi-light"></span> 
						<span class="MainBtnText">Login</span>
					</button>
				<!-- <button class="border-0 btn-block block-main-btn btn btn-success btn-sm" id="passResetNewBtn">Reset Password</button> </div> -->
		</form>
	</div>

	<?php
		}else{
			$error= "Link Expired! You are trying to use the expired link which as valid only 24 hours (1 days after request).";
		}
	}
} else {
	$error= "Link Expired! You are trying to use the expired link which as valid only 24 hours (1 days after request).";
} 
} else {
	echo "<script> window.location='index.php'; </script>";
} ?>

<?php /* if ($error) { ?>
	<script>
		toastr.error("<?=$error?>");
	</script>
		<div class="center-login text-danger"><h4><?=$error?> </h4></div>
<?php } else if ($msg) { ?>
	<script>
		toastr.success('<?=$msg ?>');
	</script>
<div class="center-login text-success"><h4><?=$msg?> </h4></div>
<?php } */ ?>