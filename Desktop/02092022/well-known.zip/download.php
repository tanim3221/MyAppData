<?php
session_start();
error_reporting(0);
session_regenerate_id(true);
date_default_timezone_set("Asia/Dhaka");
require __DIR__ . "/controller/conn.php";
require __DIR__ . "/controller/others.php";
require __DIR__ . "/PhpSpreadsheet/PHPExcel.php";
$others = new Others();
$conn = $pdo->open();
$objPHPExcel    =    new    PHPExcel();
$batch = $_SESSION['batch'];
$get_batch = $_GET['batch'];
$sql = "SELECT * FROM {$batch} WHERE student_id='" . $_SESSION['student_id'] . "'";
$stmt1 = $conn->prepare($sql);
$stmt1->execute();
$loggedin = $stmt1->fetch();

function studentDownlaod($obj)
{
    $obj->getActiveSheet()->getStyle("A1:X1")->getFont()->setBold(true);
    $obj->getActiveSheet()->SetCellValue('A1', 'Student ID');
    $obj->getActiveSheet()->SetCellValue('B1', 'Name');
    $obj->getActiveSheet()->SetCellValue('C1', 'Name (Bangla)');
    $obj->getActiveSheet()->SetCellValue('D1', 'Mobile ');
    $obj->getActiveSheet()->SetCellValue('E1', 'Email');
    $obj->getActiveSheet()->SetCellValue('F1', 'Blood Group');
    $obj->getActiveSheet()->SetCellValue('G1', 'Birthday');
    $obj->getActiveSheet()->SetCellValue('H1', 'Father Name');
    $obj->getActiveSheet()->SetCellValue('I1', 'District');
    $obj->getActiveSheet()->SetCellValue('J1', 'Address');
    $obj->getActiveSheet()->SetCellValue('K1', 'Address (Bangla)');
    $obj->getActiveSheet()->SetCellValue('L1', 'Hall Name');
    $obj->getActiveSheet()->SetCellValue('M1', 'Batch');
}

function studentData($obj, $count, $row, $hall)
{
    $obj->getActiveSheet()->SetCellValue('A' . $count, mb_strtoupper($row['student_id'], 'UTF-8'));
    $obj->getActiveSheet()->SetCellValue('B' . $count, mb_strtoupper($row['name'], 'UTF-8'));
    $obj->getActiveSheet()->SetCellValue('C' . $count, $row['name_bangla'], 'UTF-8');
    $obj->getActiveSheet()->SetCellValue('D' . $count, mb_strtoupper($row['phone'], 'UTF-8'));
    $obj->getActiveSheet()->SetCellValue('E' . $count, mb_strtolower($row['email'], 'UTF-8'));
    $obj->getActiveSheet()->SetCellValue('F' . $count, mb_strtoupper($row['blood'], 'UTF-8'));
    $obj->getActiveSheet()->SetCellValue('G' . $count, mb_strtoupper($row['birth'], 'UTF-8'));
    $obj->getActiveSheet()->SetCellValue('H' . $count, mb_strtoupper($row['father_name'], 'UTF-8'));
    $obj->getActiveSheet()->SetCellValue('I' . $count, mb_strtoupper($row['district'], 'UTF-8'));
    $obj->getActiveSheet()->SetCellValue('J' . $count, $row['address'], 'UTF-8');
    $obj->getActiveSheet()->SetCellValue('K' . $count, $row['address_bangla'], 'UTF-8');
    $obj->getActiveSheet()->SetCellValue('L' . $count, $hall, 'UTF-8');
    $obj->getActiveSheet()->SetCellValue('M' . $count, $row['batch'], 'UTF-8');
}

function downlaodTeacher($obj)
{
    $obj->setActiveSheetIndex(0);
    $obj->getActiveSheet()->getStyle("A1:X1")->getFont()->setBold(true);
    $obj->getActiveSheet()->SetCellValue('A1', 'Name');
    $obj->getActiveSheet()->SetCellValue('B1', 'Phone');
    $obj->getActiveSheet()->SetCellValue('C1', 'Email');
    $obj->getActiveSheet()->SetCellValue('D1', 'Education ');
    $obj->getActiveSheet()->SetCellValue('E1', 'Designation');
    $obj->getActiveSheet()->SetCellValue('F1', 'Address');
}

function stuffDownload($obj)
{
    $obj->setActiveSheetIndex(0);
    $obj->getActiveSheet()->getStyle("A1:X1")->getFont()->setBold(true);
    $obj->getActiveSheet()->SetCellValue('A1', 'Name');
    $obj->getActiveSheet()->SetCellValue('B1', 'Phone');
    $obj->getActiveSheet()->SetCellValue('C1', 'Email');
    $obj->getActiveSheet()->SetCellValue('D1', 'Designation');
    $obj->getActiveSheet()->SetCellValue('E1', 'Facebook ID');
    $obj->getActiveSheet()->SetCellValue('F1', 'Address');
}

if (isset($_GET['download']) && isset($loggedin['id']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev') && $loggedin['batch'] == $get_batch &&  isset($_GET['batch']) || isset($_GET['download']) && ($loggedin['role'] == 'dev') &&  isset($_GET['batch'])) {
    $objPHPExcel->setActiveSheetIndex(0);
    studentDownlaod($objPHPExcel);
    $objPHPExcel->getActiveSheet()->setTitle("Active Students of " . $get_batch . " Batch");
    $filename = $get_batch . "_" . date("dmYHis");
    $sql = "SELECT * FROM {$get_batch} WHERE active='1' ORDER by RIGHT(student_id, 3)";
} elseif (isset($_GET['downloadTeacher']) && isset($loggedin['id']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')  || isset($_GET['downloadTeacher']) && ($loggedin['role'] == 'dev')) {
    downlaodTeacher($objPHPExcel);
    $objPHPExcel->getActiveSheet()->setTitle("Teachers List of AIS");
    $filename = "teachers_" . date("dmYHis");
    $sql = "SELECT * FROM teacher";
} elseif (isset($_GET['downloadStuff']) && isset($loggedin['id']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')  || isset($_GET['downloadStuff']) && ($loggedin['role'] == 'dev')) {
    stuffDownload($objPHPExcel);
    $objPHPExcel->getActiveSheet()->setTitle("Stuff List of AIS");
    $filename = "stuff_" . date("dmYHis");
    $sql = "SELECT * FROM office_stuff";
} elseif (isset($_GET['downloadAllBatch']) && isset($loggedin['id']) && $loggedin['role'] == 'dev') {
    $rowCountB = 0;
    $sql_all = "SELECT * FROM batch ORDER by batch ASC";
    $stmt_all = $conn->prepare($sql_all);
    $stmt_all->execute();
    foreach ($stmt_all as $rowB) {
        $objPHPExcel->createSheet();
        $objPHPExcel->setActiveSheetIndex($rowCountB);
        $objPHPExcel->getActiveSheet()->getStyle("A1:L1")->getFont()->setBold(true);
        $objPHPExcel->getActiveSheet()->setTitle($rowB['batch'] . " Batch");
        studentDownlaod($objPHPExcel);
        $batch_all = $rowB['batch'];

        $rowCount = 2;

        if(isset($_GET['criteria'])){
            $criteria = $_GET['criteria'];
            $hallName = $_GET['hallName'];
            if(isset($_GET['bloodGroup'])){
                $filename = "AIS_blood (".$criteria.") " . date("dmYHis");
                $sql_all = "SELECT * FROM {$batch_all} WHERE blood = '".$criteria."' AND active='1' ORDER by RIGHT(student_id, 3)";                
            } elseif(isset($_GET['districtName'])){
                $filename = "AIS_district (".$criteria.") " . date("dmYHis");
                $sql_all = "SELECT * FROM {$batch_all} WHERE district='".$criteria."' AND active='1' ORDER by RIGHT(student_id, 3)";                
            } elseif(isset($_GET['hallName'])){
                $filename = "AIS_hall (".$hallName.") " . date("dmYHis");
                $sql_all = "SELECT * FROM {$batch_all} WHERE SUBSTRING(student_id,3,3) ='".$criteria."' AND active='1' ORDER by RIGHT(student_id, 3)";                
            }
        } else {
            $sql_all = "SELECT * FROM {$batch_all} WHERE active='1' ORDER by RIGHT(student_id, 3)";
            $filename = "AIS_all_students_" . date("dmYHis");
        }

        $stmt_all = $conn->prepare($sql_all);
        $stmt_all->execute();
        foreach ($stmt_all as $row) {
            $student_id = $row['student_id'];
            $hallName = $others->getHallName(substr($student_id, 2, 3));
            studentData($objPHPExcel, $rowCount, $row, $hallName);
            $rowCount++;
        }
        $rowCountB++;
    }
}

$rowCount    =    2;
// $sql = "SELECT * FROM 19th WHERE active='1' ORDER by RIGHT(student_id, 3)";
$stmt = $conn->prepare($sql);
$stmt->execute();
$numRows = $stmt->rowCount();
if ($numRows > 0) {
    foreach ($stmt as $row) {

        if (isset($_GET['download']) && isset($loggedin['id']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev') && $loggedin['batch'] == $get_batch &&  isset($_GET['batch']) || isset($_GET['download']) && ($loggedin['role'] == 'dev') &&  isset($_GET['batch'])) {
            $student_id = $row['student_id'];
            $hallName = $others->getHallName(substr($student_id, 2, 3));
            studentData($objPHPExcel, $rowCount, $row, $hallName);
            // $objPHPExcel->getActiveSheet()->getRowDimension($rowCount + 2)->getRowHeight(35);
            // $img_path = "./image/" . $row['photo'];    //Path to signature .jpg file
            // if (file_exists($img_path)) {
            //     $objDrawing = new PHPExcel_Worksheet_Drawing();    //create object for Worksheet drawing
            //     $objDrawing->setName($row['name']);        //set name to image
            //     $objDrawing->setDescription($row['name']); //set description to image
            //     $objDrawing->setPath($img_path);
            //     $objDrawing->setOffsetX(25);                       //setOffsetX works properly
            //     $objDrawing->setOffsetY(10);                       //setOffsetY works properly
            //     $objDrawing->setCoordinates("L" . $rowCount);        //set image to cell
            //     $objDrawing->setWidth(50);                 //set width, height
            //     $objDrawing->setHeight(50);
            //     $objDrawing->setWorksheet($objPHPExcel->getActiveSheet());  //save
            // } else {
            //     $objPHPExcel->getActiveSheet()->setCellValue("L" . $rowCount, "No Image");
            // }

        } elseif (isset($_GET['downloadTeacher']) && isset($loggedin['id']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')  || isset($_GET['downloadTeacher']) && ($loggedin['role'] == 'dev')) {
            $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, mb_strtoupper($row['name'], 'UTF-8'));
            $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, mb_strtoupper($row['phone'], 'UTF-8'));
            $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowCount, mb_strtolower($row['email'], 'UTF-8'));
            $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, $row['edu'], 'UTF-8');
            $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowCount, mb_strtoupper($row['designation'], 'UTF-8'));
            $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowCount, $row['per_addr'], 'UTF-8');
        } elseif (isset($_GET['downloadStuff']) && isset($loggedin['id']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')  || isset($_GET['downloadStuff']) && ($loggedin['role'] == 'dev')) {

            $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCount, mb_strtoupper($row['name'], 'UTF-8'));
            $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCount, mb_strtoupper($row['phone'], 'UTF-8'));
            $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowCount, mb_strtolower($row['email'], 'UTF-8'));
            $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, mb_strtoupper($row['designation'], 'UTF-8'));
            $objPHPExcel->getActiveSheet()->SetCellValue('E' . $rowCount, mb_strtoupper($row['fb_id'], 'UTF-8'));
            $objPHPExcel->getActiveSheet()->SetCellValue('F' . $rowCount, $row['per_addr'], 'UTF-8');
        }
        $rowCount++;
    }
} else {
    echo "Your data export failed, please try again or contact to admin.";
}

if (isset($_GET['download']) && isset($loggedin['id']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev') && $loggedin['batch'] == $get_batch &&  isset($_GET['batch']) || isset($_GET['download']) && ($loggedin['role'] == 'dev') &&  isset($_GET['batch'])) {
    $objPHPExcel->createSheet();
    $objPHPExcel->setActiveSheetIndex(1);
    $objPHPExcel->getActiveSheet()->getStyle("A1:E1")->getFont()->setBold(true);
    $objPHPExcel->getActiveSheet()->setTitle("Inactive Students of " . $get_batch . " Batch");
    $objPHPExcel->getActiveSheet()->SetCellValue('A1', 'Student ID');
    $objPHPExcel->getActiveSheet()->SetCellValue('B1', 'Email');
    $objPHPExcel->getActiveSheet()->SetCellValue('C1', 'Hall Name');
    $rowCountB = 2;
    $sql = "SELECT * FROM {$get_batch} WHERE active='0' ORDER by RIGHT(student_id, 3)";
    $stmt = $conn->prepare($sql);
    $stmt->execute();
    foreach ($stmt as $rowB) {
        $student_id = $rowB['student_id'];
        $hallName = $others->getHallName(substr($student_id, 2, 3));
        $objPHPExcel->getActiveSheet()->SetCellValue('A' . $rowCountB, mb_strtoupper($rowB['student_id'], 'UTF-8'));
        $objPHPExcel->getActiveSheet()->SetCellValue('B' . $rowCountB, mb_strtolower($rowB['email'], 'UTF-8'));
        $objPHPExcel->getActiveSheet()->SetCellValue('C' . $rowCountB, $hallName, 'UTF-8');
        $objPHPExcel->getActiveSheet()->SetCellValue('D' . $rowCount, $row['batch'], 'UTF-8');
        $rowCountB++;
    }
}
$conn = null;
$objWriter    =    new PHPExcel_Writer_Excel2007($objPHPExcel);
header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment;filename="' . $filename . '.xlsx"');
header('Cache-Control: max-age=0');
$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save('php://output');
die();
