<script>
    $(document).ready(function () {
        $(".pagination").pagShrink();
    });
</script>

 <script>
      $(document).ready(function(){
        $('ul.first').bsPhotoGallery({
          "classes" : "col-xl-3 col-lg-2 col-md-4 col-sm-4",
          "hasModal" : true,
          "shortText" : false  
        });
      });
    </script>
   
<?php 
$sql = "SELECT {$batch}.name, {$batch}.photo, gallery.pinned, gallery.batch, gallery.student_id, gallery.image_name, gallery.image_date, gallery.image_place, gallery.image_description, gallery.date FROM gallery  INNER JOIN  {$batch} ON gallery.student_id = {$batch}.student_id  WHERE gallery.batch = '{$batch}' AND gallery.hide ='0' AND gallery.pinned ='1' AND gallery.batch ='{$batch}' {$album_view} ORDER BY gallery.image_id DESC LIMIT 4";
$stmt = $connPdo->prepare($sql);
$stmt->execute();
$numRows = $stmt->rowCount();

if ($numRows > 0) { ?>

    <ul id="pinned-img" class="row first alert alert-warning">
    
<?php
foreach ($stmt as $pinned) {?>
    <li>
      <img alt="<?php echo $pinned ['image_description'];?>"  src="files/<?php echo $pinned ['image_name'];?>">
      <p><b><?php echo $pinned ['image_description'];?></b><br><b>Place</b> - <?php echo $pinned ['image_place'];?><br><b>Date</b> - <?php echo $pinned ['image_date'];?><br><b>Uploaded By</b> - <?php echo $pinned ['name'];?><br></p>
  </li> 
<?php   }
} else {
    echo "<div style='margin:50px auto; color:red;' class='notfountimg'>No pinned images exist in gallery.</div>";
}
?>
</ul>        
     
<?php 

$sql = "SELECT {$batch}.name, {$batch}.photo, gallery.pinned, gallery.batch, gallery.student_id, gallery.image_name, gallery.image_date, gallery.image_place, gallery.image_description, gallery.date FROM gallery  INNER JOIN {$batch} ON gallery.student_id = {$batch}.student_id WHERE gallery.batch ='{$batch}' AND gallery.hide ='0' AND gallery.pinned ='0' {$album_view} ORDER BY gallery.image_id DESC";
$stmt1 = $connPdo->prepare($sql);
		$stmt1->execute();
		$numRows = $stmt1->rowCount();
if ($numRows > 0) { ?>

    <ul class="row first mobile_gallery_view_content">
    
<?php
foreach ($stmt as $row) { ?>
    <li>
      <img alt="<?php echo $row ['image_description'];?>"  src="files/<?php echo $row ['image_name'];?>">
      <p><b><?php echo $row ['image_description'];?></b><br><b>Place</b> - <?php echo $row ['image_place'];?><br><b>Date</b> - <?php echo $row ['image_date'];?><br><b>Uploaded By</b> - <?php echo $row ['name'];?><br></p>
  </li> 
<?php   }
} else {
    echo "<div style='margin:50px auto; color:red;' class='notfountimg'>No image exist in gallery.</div>";
}
$connPdo =null;
?>
</ul>