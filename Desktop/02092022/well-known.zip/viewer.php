<meta content='width=device-width, initial-scale=1.0' name='viewport' />
<?php 
session_start();
require __DIR__. '/controller/conn.php';
$connPdo = $pdo->open();
if (isset($_GET['id']) && isset($_GET['title'])  && isset($_GET['download']) && isset($_SESSION['student_id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM learning WHERE id=$id";
	$stmt = $connPdo->prepare($sql);
    $stmt->execute();
    $row = $stmt->fetch();
    $newCount = $row ['download'] + 1;
    $updateQuery = "UPDATE learning SET download=$newCount WHERE id=$id";
	$stmtu = $connPdo->prepare($updateQuery);
	if ($stmtu->execute()){
		if (isset($_SERVER['HTTPS'])){
			$http='https';
		} else {
			$http='http';
		}
		if (!$row['link']==1) {
			 //echo "<script>window.location.href='".$http."://".$_SERVER['HTTP_HOST']."/files/".$row['file_name']."';window.setTimeout(function(){ window.location.reload(); }, 2500); </script>";
			 echo "<iframe id='iframe_view_file' height='100%' width='100%' src='".$http."://".$_SERVER['HTTP_HOST']."/files/".$row['file_name']."' style='border:none;'></iframe>";
		} else {
			echo "<iframe id='iframe_view_file' height='100%' width='100%' src='".$row['refer_link']."' style='border:none;'></iframe>";
			 //echo "<script>window.location.href='".$row['refer_link']."';window.setTimeout(function(){ window.history.go(-1); }, 2500); </script>";
		}	
	} else {
		echo "<script>window.history.go(-1)</script>";
	}
}  else {
	echo "<script>window.location.href='index.php'</script>";
} ?>
