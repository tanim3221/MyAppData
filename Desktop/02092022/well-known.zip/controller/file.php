<?php
class Files
{
    private $conn;
    public function __construct()
    {
        $this->conn = new Database();
        $this->conn = $this->conn->open();
    }
    public function getFilesByCode($code)
    {
        $output = array();
        $stmt = $this->conn->prepare("SELECT * FROM learning WHERE course_code='" . $code . "' AND hide='0' AND approve='1' ORDER BY id DESC");
        $stmt->execute();
        foreach ($stmt as $row) {
            $output[] = $row;
        }
        return $output;
        $this->conn = null;
    }
    public function getFilesByCodeCount($code)
    {
        $stmt = $this->conn->prepare("SELECT *, COUNT(id) AS fileCount FROM learning WHERE course_code='" . $code . "' AND hide='0' AND approve='1' ORDER BY id DESC");
        $stmt->execute();
        $row = $stmt->fetch();
        $output = $row['fileCount'];
        return $output;
        $this->conn = null;
    }
}
