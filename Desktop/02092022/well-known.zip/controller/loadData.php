<?php
session_start();
error_reporting(0);

require __DIR__ . '/conn.php';
include __DIR__ . '/data.php';
require __DIR__ . '/others.php';
$conn = $pdo->open();
$data = new Data();
$others = new Others();
$othersData = new Data();
$batch = $_SESSION['batch'];
$student_id = $_SESSION['student_id'];

$loggedin = $data->batchData($batch, $student_id, 'student_id');
$loggedChecklist = json_decode($loggedin['checklist'],true);


try {
    ## Read value
    $draw = $_POST['draw'];
    $row = $_POST['start'];
    $rowperpage = $_POST['length']; // Rows display per page
    $columnIndex = $_POST['order'][0]['column']; // Column index
    $columnName = $_POST['columns'][$columnIndex]['data']; // Column name
    $columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
    $searchValue = $_POST['search']['value']; // Search value
    $view_batch = $_POST['view_batch'];
    $my_batch = $_POST['my_batch'];
    $other_batch_view = $_POST['other_batch_view'];
    $inactive_view = $_POST['inactive_view'];
    $inactive_private_students = $_POST['inactive_private_students'];
    $inactive_public_students = $_POST['inactive_public_students'];
    $active_private_students = $_POST['active_private_students'];
    $active_public_students = $_POST['active_public_students'];
    $controller_view = $_POST['controller_view'];

    $customize_data_view = $_POST['customize_data_view'];
    $dataHead = $_POST['dataHead'];
    $dataValue = $_POST['dataValue'];

    $mainArray = array();

    ## Search 
    $mainQuery = " ";
    if (($controller_view == "controller_view") && ($inactive_private_students == "inactive_private_students") && ($loggedin['role'] == 'dev')) {
        $mainQuery = " AND active = :active AND showing=:showing";
        $mainArray = array(
            'active' => "0",
            'showing' => "0"
        );
    } elseif (($controller_view == "controller_view") && ($inactive_public_students == "inactive_public_students") && ($loggedin['role'] == 'dev')) {
        $mainQuery = " AND active = :active AND showing=:showing";
        $mainArray = array(
            'active' => "0",
            'showing' => "1"
        );
    } elseif (($controller_view == "controller_view") && ($active_public_students == "active_public_students") && ($loggedin['role'] == 'dev')) {
        $mainQuery = " AND active = :active AND showing=:showing";
        $mainArray = array(
            'active' => "1",
            'showing' => "1"
        );
    } elseif (($controller_view == "controller_view") && ($active_private_students == "active_private_students") && ($loggedin['role'] == 'dev')) {
        $mainQuery = " AND active = :active AND showing=:showing";
        $mainArray = array(
            'active' => "1",
            'showing' => "0"
        );
    } elseif (($controller_view == "controller_view") && ($loggedin['role'] == 'dev')) {
        $mainQuery = " ";
        $mainArray = array();
    } elseif (($inactive_view == "inactive_view") && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev') && ($loggedin['batch'] == $view_batch)) {
        $mainQuery = " AND active = :active";
        $mainArray = array(
            'active' => '0'
        );
    } elseif (($my_batch == "my_batch") && ($loggedin['role'] == 'admin')) {
        $mainQuery = " AND active = :active";
        $mainArray = array(
            'active' => "1"
        );
    } elseif (($my_batch == "my_batch") && ($loggedin['role'] !== 'admin')) {
        $mainQuery = " AND active = :active AND showing = :showing";
        $mainArray = array(
            'active' => "1",
            'showing' => "1"
        );
    } elseif ($other_batch_view == "other_batch_view") {
        $mainQuery = " AND active = :active AND showing=:showing";
        $mainArray = array(
            'active' => "1",
            'showing' => "1"
        );
    } elseif (($customize_data_view == "customize_data_view") && (!empty($dataValue))) {
        if($dataHead=="district"){
            $dataHead_Col = $dataHead;
        } else if($dataHead=="blood"){
            $dataHead_Col = $dataHead;
        } else if($dataHead=="student_id"){
            $dataHead_Col = "SUBSTRING(student_id, 3,3)";
            $getHallName = $others->getHallByCode($dataValue);
        }
        // 1510233221
        $mainQuery = " AND {$dataHead_Col} = :dataValue AND active = :active";
        $mainArray = array(
            'dataValue' => $dataValue,
            'active' => "1"
        );
    }

    // $mainOrder = " ORDER BY RIGHT(student_id, 5) ASC";
    $mainOrder = " ORDER BY SUBSTRING(student_id, 7,4) ASC";

    if (!empty($searchValue)) {
        $mainQuery = $mainQuery . " AND (
        student_id LIKE :student_id OR 
        phone LIKE :phone OR 
        name LIKE :name OR 
        district LIKE :district OR 
        blood LIKE :blood OR 
        email LIKE :email ) ";
        $mainArrayS = array(
            'student_id' => "%$searchValue%",
            'name' => "%$searchValue%",
            'district' => "%$searchValue%",
            "phone" => "%$searchValue%",
            "blood" => "%$searchValue%",
            "email" => "%$searchValue%",
        );

        $mainArray = array_merge($mainArray, $mainArrayS);
    }
    // else {
    //     $searchQuery = $mainQuery;
    //     // $searchArray = $mainArray;
    // }

    if ($view_batch=="all_batch"){
        $sql_array = array();
        $sql = "SELECT * FROM batch WHERE active='1' ORDER by batch DESC";
        $stmt_s = $conn->prepare($sql);
        $stmt_s->execute();
        $selectTerm = " student_id,name_bangla,name,batch,phone,blood,district, email, fb_id, photo, address, address_bangla,id, active, showing ";
        foreach ($stmt_s as $row_s) {
            $row_batch = $row_s['batch'];
            $row_batch_sql = "SELECT {$selectTerm} FROM {$row_batch} WHERE 1 " .$mainQuery;
            $sql_array[] = $row_batch_sql;
        }
        $sql = "";
        foreach ($sql_array as $sql_query) {
            $sql .= $sql_query;
            if (next($sql_array)) {
                $sql .= " UNION ALL ";
            }
        }
        
        $totalRecordwithFilterSql = "SELECT COUNT(id) AS allcount FROM (".$sql.") AS std";
        $fetchRecordSql = $sql;


    } else {
        $totalRecordwithFilterSql = "SELECT COUNT(*) AS allcount FROM {$view_batch} WHERE 1 " . $mainQuery;
        $fetchRecordSql = "SELECT * FROM {$view_batch} WHERE 1 " . $mainQuery;
    }

    ## get activity of users
    $loggedinInfoInsert = array(
        'name' => $loggedin['name'],
        'batch' => $loggedin['batch'],
        'student_id' => $loggedin['student_id']
    );
    $getDataHead = " of ".(($dataHead=="student_id") ? $getHallName['name_en'] : $dataHead);
    $details_activity = "" . $loggedin['name'] . " viewed all students information <b>".(!empty($dataValue) ? $getDataHead." (".$dataValue.")" : "")."</b> of <b>".ucwords(str_replace("_"," ",$view_batch))."</b>.";
    $others->activity_log_save($details_activity, $loggedinInfoInsert);
    ## get activity of users

    ## Total number of records without filtering
    $stmt = $conn->prepare($totalRecordwithFilterSql." " . $mainOrder);
    // $stmt = $conn->prepare("SELECT COUNT(*) AS allcount FROM {$view_batch} WHERE 1 " . $mainQuery . " " . $mainOrder);
    $stmt->execute($mainArray);
    $records = $stmt->fetch();
    $totalRecords = $records['allcount'];

    ## Total number of records with filtering
    // $stmt = $conn->prepare("SELECT COUNT(*) AS allcount FROM {$view_batch} WHERE 1 " . $mainQuery);
    $stmt = $conn->prepare($totalRecordwithFilterSql);
    $stmt->execute($mainArray);
    $records = $stmt->fetch();
    $totalRecordwithFilter = $records['allcount'];

    // $orderBy = (($columnName !== '') ? " ORDER BY " . $columnName . " " . $columnSortOrder : $mainOrder);
    $orderBy = (($columnName !== '') ? $mainOrder : " ORDER BY " . $columnName . " " . $columnSortOrder);
    ## Fetch records
    $stmt = $conn->prepare($fetchRecordSql." ". $orderBy . "  LIMIT :limit,:offset");
    // $stmt = $conn->prepare("SELECT * FROM {$view_batch} WHERE 1 " . $mainQuery . "  " . $orderBy . "  LIMIT :limit,:offset");

    // Bind values
    foreach ($mainArray as $key => $search) {
        $stmt->bindValue(':' . $key, $search, PDO::PARAM_STR);
    }

    $stmt->bindValue(':limit', (int)$row, PDO::PARAM_INT);
    $stmt->bindValue(':offset', (int)$rowperpage, PDO::PARAM_INT);
    $stmt->execute();
    $empRecords = $stmt->fetchAll();

    $data = array();

    foreach ($empRecords as $row) {
        $img = $row['photo'];
        $id = $row['id'];
        $student_id = $row['student_id'];
        $phone = $row['phone'];
        $name = $row['name'];
        $email = $row['email'];
        $fb_id = $row['fb_id'];
        $batch = $row['batch'];
        $facebook_url = $others->get_facebook_url($fb_id);
        if (($row['showing'] == '1') && ($row['active'] == '1')) {
            $btnColor = 'success';
        } else if ($row['active'] == '0') {
            $btnColor = 'danger';
        } else if ($row['showing'] == '0') {
            $btnColor = 'warning';
        }
        $view = '<button type="button" class="view_btn btn btn-' . $btnColor . ' btn-sm" data-batch="' . $batch . '" data-id="' . $row['id'] . '" id="view_btn_stds"><i class="fas fa-eye"></i></button>';

        $keyAdd = $othersData->getOthersData('add_info_key', $student_id, 'student_id', 'DESC');
        $key = $keyAdd['key'];

        $edit = "";
        if (($my_batch == "my_batch") && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev') && $loggedin['batch'] == $view_batch) {
            $edit .= '
        <div class="btn-group">
        <a type="button" class="btn btn-warning btn-sm" href="dataview.php?my_batch_update&id=' . $id . '&key=' . md5($phone) . '&batch=' . $batch . '&name=' . str_replace(' ', '_', $name) . '&action=update"><i class="fas fa-edit"></i></a>
        <button class="btn btn-primary btn-sm" id="openPassChangeWindow" data-batch="' . $batch . '" data-id="' . $id . '" id="changePassMyBatch"><i class="fas fa-lock"></i></button>
        </div>';
        } elseif (($loggedin['role'] == 'dev' &&  $controller_view == "controller_view")) {
           if (array_key_exists("personal-info-delete", $loggedChecklist)){ 

            $edit .= '
        <a type="button" class="btn btn-danger text-white btn-sm" id="deleteBatchData" data-batch="' . $batch . '" data-id="' . $id . '"><i class="fas fa-trash-alt"></i></a>';
           }
        $edit .= '
        <a type="button" class="btn btn-warning btn-sm" href="dataview.php?controller_view_update&id=' . $id . '&key=' . md5($phone) . '&batch=' . $batch . '&name=' . str_replace(' ', '_', $name) . '&action=update"><i class="fas fa-edit"></i></a>
        ';
        if ($inactive_private_students == "inactive_private_students"){
        $edit .= "
                <div class='btn-group'>
                    <button data-student_id='" . $student_id . "' data-id='" . $id . "'  data-email='" . $email . "' data-batch='" . $batch . "' class='btn btn-success btn-sm' id='getAddReqBtnWin'> <i class='fas fa-paper-plane'></i></button>
                
                    <button class='btn btn-primary btn-sm' data-id='" . $id . "' data-student_id='" . $student_id . "'  data-email='" . $email . "' data-batch='" . $batch . "' id='generateKeyInfoBtnWin'><i class='fas fa-sync-alt'></i></button> 
                </div>
                
                <div class='btn-group mt-1'>
                    <a type='button' target='_blank' class='btn btn-info btn-sm' href='addinfo.php?add_info_users&key=" . $key . "&action=add'><i class='fas fa-plus'></i></a>

                    <button data-student_id='" . $student_id . "' data-id='" . $id . "'  data-email='" . $email . "' data-batch='" . $batch . "' class='btn btn-default btn-sm' id='changeOnlyMailID'> <i class='fas fa-user-edit'></i></button>
                </div>

                ";
        }
        
        } elseif ($inactive_view == "inactive_view") {
            
            $edit .= "
            <a type='button' class='btn btn-danger text-white btn-sm' id='deleteBatchData' data-batch='" . $batch ."' data-id='" . $id . "'><i class='fas fa-trash-alt'></i></a>
        <div class='btn-group'>
            <button data-student_id='" . $student_id . "' data-id='" . $id . "'  data-email='" . $email . "' data-batch='" . $batch . "' class='btn btn-success btn-sm' id='getAddReqBtnWin'> <i class='fas fa-paper-plane'></i></button>
        
            <button class='btn btn-primary btn-sm' data-id='" . $id . "' data-student_id='" . $student_id . "'  data-email='" . $email . "' data-batch='" . $batch . "' id='generateKeyInfoBtnWin'><i class='fas fa-sync-alt'></i></button> 
        </div>

        <div class='btn-group mt-1'>
            <a type='button' target='_blank' class='btn btn-info btn-sm' href='addinfo.php?add_info_users&key=" . $key . "&action=add'><i class='fas fa-plus'></i></a>

            <button data-student_id='" . $student_id . "' data-id='" . $id . "'  data-email='" . $email . "' data-batch='" . $batch . "' class='btn btn-default btn-sm' id='changeOnlyMailID'> <i class='fas fa-user-edit'></i></button>
        </div>
                ";
        } else {
            $edit .= "";
        }


        if (empty($img)) {
            $img = "  <div class='avatar'><a class='fb_id' target='_blank' href='https://www.facebook.com/" . $facebook_url . "'><img src='ais-assets/icon/demo.png'><img class='img-top' src='ais-assets/icon/fb.png'></a></div>";
        } else {
            $img = "<div class='avatar'><a class='fb_id' target='_blank' href='https://www.facebook.com/" . $facebook_url . "'><img src='image/" . $img . "'><img class='img-top' src='ais-assets/icon/fb.png'></a></div>";
        }

        if ($view_batch=="all_batch"){
            $seeBatch = " (".$batch.")";
        } else {
            $seeBatch = "";
        }

        $data[] = array(
            "photo" => $img,
            "student_id" => $row['student_id'].$seeBatch,
            "name" => ucwords(strtolower($row['name'])),
            "phone" => "<a href='tel:" . $row['phone'] . "'>" . $row['phone'] . "</a>",
            "blood" => "<a href='dataview.php?view_batch&customize_data_view&batch=".$row['batch']."&blood=" . $row['blood'] . "'><span style='color:red; font-weight:bold;'>" . $row['blood'] . "</span></a> ",
            "email" => "<a href='mailto:" . $row['email'] . "'>" . $row['email'] . "</a>",
            "action" =>  $view . " " . $edit
        );
    }

    ## Response
    $response = array(
        "draw" => intval($draw),
        "iTotalRecords" => $totalRecords,
        "iTotalDisplayRecords" => $totalRecordwithFilter,
        "aaData" => $data
    );

    exit(json_encode($response));
    $conn = null;

} catch (Exception $e) {
    echo "Ha Ha Ha !!! You are fool.";
}
