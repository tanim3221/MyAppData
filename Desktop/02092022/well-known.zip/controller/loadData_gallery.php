<?php
session_start();
error_reporting(0);

require __DIR__ . '/conn.php';
include __DIR__ . '/data.php';
require __DIR__ . '/others.php';
$conn = $pdo->open();
$dataLog = new Data();
$others = new Others();
$othersData = new Data();
$batch = $_SESSION['batch'];
$student_id = $_SESSION['student_id'];

$loggedin = $dataLog->batchData($batch, $student_id, 'student_id');
try {
    ## Read value
    $draw = $_POST['draw'];
    $row = $_POST['start'];
    $rowperpage = $_POST['length']; // Rows display per page
    $columnIndex = $_POST['order'][0]['column']; // Column index
    $columnName = $_POST['columns'][$columnIndex]['data']; // Column name
    $columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
    $searchValue = $_POST['search']['value']; // Search value
    $dTable = $_POST['dTable'];
    $urlParam = $_POST['urlParam'];
    $urlBatch = $_POST['urlBatch'];


    $mainArray = array();

    ## Search 

    // $mainQuery = " ";
    // $mainArray = array();

    if (($urlParam == "my_view_gallery")) {
        $mainQuery = " AND student_id = :student_id AND batch=:batch";
        $mainArray = array(
            'student_id' => $loggedin['student_id'],
            'batch' => $loggedin['batch']
        );
    } elseif (($urlParam == "admin_view_gallery")) {
        $mainQuery = " AND batch=:batch";
        $mainArray = array(
            'batch' => $loggedin['batch']
        );
    } elseif (($urlParam == "controller-view")) {
        $mainQuery = " AND batch=:batch";
        $mainArray = array(
            'batch' => $urlBatch
        );
    } 

    $mainOrder = " ORDER BY image_id DESC";

    if ($searchValue != '') {
        $mainQuery = $mainQuery . " AND (
        image_place LIKE :image_place OR 
        image_description LIKE :image_description OR 
        album LIKE :album OR 
        student_id LIKE :student_id OR 
        date LIKE :date ) ";
        $mainArrayS = array(
            'image_place' => "%$searchValue%",
            'image_description' => "%$searchValue%",
            "album" => "%$searchValue%",
            "student_id" => "%$searchValue%",
            "date" => "%$searchValue%",
        );

        $mainArray = array_merge($mainArray, $mainArrayS);
    }
    // else {
    //     $searchQuery = $mainQuery;
    //     // $searchArray = $mainArray;
    // }

    ## Total number of records without filtering
    $stmt = $conn->prepare("SELECT COUNT(*) AS allcount FROM {$dTable} WHERE 1 " . $mainQuery . " " . $mainOrder);
    $stmt->execute($mainArray);
    $records = $stmt->fetch();
    $totalRecords = $records['allcount'];

    ## Total number of records with filtering
    $stmt = $conn->prepare("SELECT COUNT(*) AS allcount FROM {$dTable} WHERE 1 " . $mainQuery);
    $stmt->execute($mainArray);
    $records = $stmt->fetch();
    $totalRecordwithFilter = $records['allcount'];

    $orderBy = (($columnName !== '') ? " ORDER BY " . $columnName . " " . $columnSortOrder : $mainOrder);
    ## Fetch records
    $stmt = $conn->prepare("SELECT * FROM {$dTable} WHERE 1 " . $mainQuery . "  " . $orderBy . "  LIMIT :limit,:offset");

    // Bind values
    foreach ($mainArray as $key => $search) {
        $stmt->bindValue(':' . $key, $search, PDO::PARAM_STR);
    }

    $stmt->bindValue(':limit', (int)$row, PDO::PARAM_INT);
    $stmt->bindValue(':offset', (int)$rowperpage, PDO::PARAM_INT);
    $stmt->execute();
    $empRecords = $stmt->fetchAll();

    $data = array();

    foreach ($empRecords as $row) {

        $student_id = $row['student_id'];

        $std_Data = $dataLog->batchData($urlBatch, $student_id, 'student_id');

        $image = '<span class="img-edit gallery_photo"><img class="photo_img" src="files/' . $row['image_name'] . '"></span>';

        $pinned = '';

        if ($row['pinned'] == '1') {
            $pinned = ' <span
            class="text-center text-white bg-success rounded p-1"><i class="fas fa-thumbtack"></i>
            Pinned to top</span><br>';
        }

        $pinned .= '' . $std_Data['name'] . '<br>' . $row['date'];

        if ($row['hide'] == '1') {
            $pinned .= '<br> <span
            class="text-center text-white bg-danger rounded p-1"><i class="fas fa-lock"></i>
            Private</span>';
        }
        if ($urlParam == "admin_view_gallery") {
            $action = '<div class="m-2">' . $row['album'] . '</div>
        <div class="btn-group">
        <button id="updateImagedata" data-url="'.$urlParam.'" data-id="'.$row['image_id'].'" class="btn btn-warning">Update</button>
            <a href="index_gallery.php?del_img&admin_view_gallery&image_id=' . $row['image_id'] . '"
                onclick="return confirm("Do you want to delete image?")" class="btn btn-danger">Delete</a>
        </div>';
        } elseif ($urlParam == "controller-view") {
            $action = '<div class="m-2">' . $row['album'] . '</div>
        <div class="btn-group">
        <button id="updateImagedata" data-url="'.$urlParam.'" data-id="'.$row['image_id'].'" class="btn btn-warning">Update</button>
            <a href="index_gallery.php?del_img&controller-view&image_id=' . $row['image_id'] . '"
                onclick="return confirm("Do you want to delete image?")" class="btn btn-danger">Delete</a>
        </div>';
        } else {
            $action = ' <div class="m-2">' . $row['album'] . '</div>
        <div class="btn-group">
            <button id="updateImagedata"  data-url="'.$urlParam.'" data-id="'.$row['image_id'].'" class="btn btn-warning">Update</button>
            <a href="index_gallery.php?my_view_gallery&del_img&image_id=' . $row['image_id'] . '"
                onclick="return confirm("Do you want to delete image?")" class="btn btn-danger">
                Delete
            </a>
        </div>';
        }

        $data[] = array(
            "image_name" =>  $image,
            "image_place" => $row['image_place'],
            "image_date" => $pinned,
            "image_description" => $row['image_description'],
            "action" =>  $action
        );
    }

    ## Response
    $response = array(
        "draw" => intval($draw),
        "iTotalRecords" => $totalRecords,
        "iTotalDisplayRecords" => $totalRecordwithFilter,
        "aaData" => $data
    );

    // echo json_encode($response);
    exit(json_encode($response));
    $conn = null;

} catch (Exception $e) {
    echo "Ha Ha Ha !!! You are fool.";
}
