<?php
class Photo
{
    private $conn;
    public function __construct()
    {
        $this->conn = new Database();
        $this->conn = $this->conn->open();
    }

    public function compressedImage($source, $path, $quality)
    {

        $info = getimagesize($source);

        if ($info['mime'] == 'image/jpeg')
            $image = imagecreatefromjpeg($source);

        elseif ($info['mime'] == 'image/gif')
            $image = imagecreatefromgif($source);

        elseif ($info['mime'] == 'image/png')
            $image = imagecreatefrompng($source);

        imagejpeg($image, $path, $quality);
        $this->conn = null;

    }
    public function insertPhoto($post, $file, $loggedin)
    {

        // $image_id = rand(10000, 100000);
        $image_files = $file["image"]["name"];
        $image_date = $post['image_date'];
        $image_place = $post['image_place'];
        $album = $post['album'];
        $image_description = $post['image_description'];
        $student_id = $loggedin['student_id'];
        $batch = $loggedin['batch'];
        $hide = 0;
        $date = date("Y-m-d H:i:s");

        foreach ($image_files as $key => $files) {
            $image_file = $file["image"]["name"][$key];
            $type  = $file["image"]["type"][$key];
            $size  = $file["image"]["size"][$key];
            $temp  = $file["image"]["tmp_name"][$key];

            $ext = pathinfo($image_file, PATHINFO_EXTENSION);
            $image_name = md5(time()) . mt_rand() . "." . $ext;

            $image_url = BASE_URL . "files/" . $image_name;
            $path = $_SERVER['DOCUMENT_ROOT'] . BASE_DIR . "/files/" . $image_name;

            if (!file_exists($path)) {
                $this->compressedImage($temp, $path, 15);
                //move_uploaded_file($temp, "files/".$image_name);
                $stmt = $this->conn->prepare("INSERT INTO gallery (album, image_name, image_date, image_place, image_description, student_id, batch, date, hide, pinned,image_url) VALUES (:album, :image_name,:image_date,:image_place,:image_description,:student_id,:batch,:date,:hide, :pinned,:image_url)");
                $up = $stmt->execute(['album' => $album, 'image_name' => $image_name, 'image_url' => $path, 'image_date' => $image_date, 'image_place' => $image_place, 'image_description' => $image_description, 'student_id' => $student_id, 'batch' => $batch, 'date' => $date, 'hide' => $hide, 'pinned' => 0]);
                if ($up) {
                    $msg = 1;
                } else {
                    $msg = 0;
                }
            } else {
                $msg = 0;
            }
        }
        return $msg;
        $this->conn = null;

    }
    public function getAlbum()
    {
        $output = array();
        $stmt = $this->conn->prepare("SELECT DISTINCT(album) FROM gallery WHERE album != '' ORDER BY album");
        $stmt->execute();
        foreach ($stmt as $row) {
            $output[] = $row;
        }
        return $output;
        $this->conn = null;

    }

}
