<?php
session_start();
error_reporting(1);

require __DIR__ . '/conn.php';
include __DIR__ . '/data.php';
require __DIR__ . '/others.php';
$conn = $pdo->open();
$data = new Data();
$others = new Others();
$othersData = new Data();
$batch = $_SESSION['batch'];
$student_id = $_SESSION['student_id'];

$loggedin = $data->batchData($batch, $student_id, 'student_id');
$loggedChecklist = json_decode($loggedin['checklist'], true);

try {
    ## Read value
    $draw = $_POST['draw'];
    $row = $_POST['start'];
    $rowperpage = $_POST['length']; // Rows display per page
    $columnIndex = $_POST['order'][0]['column']; // Column index
    $columnName = $_POST['columns'][$columnIndex]['data']; // Column name
    $columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
    $searchValue = $_POST['search']['value']; // Search value
   
    $category = $_POST['category'];
    $query = urldecode($_POST['query']);

    $find = array("+", "%2B","%2D");
    $replace = array(" ","+","-");
    $query = str_replace($find, $replace, $query);

    // $category = "any_batch";
    // $query = "Sak Ahmed";

    $searchTerms = explode(' ', $query);
    $searchTermBits = array();
    foreach ($searchTerms as $term) {
        $term = trim($term);
        if (!empty($term)) {
            $searchTermBits[] = "student_id LIKE '%$term%' OR batch LIKE '%$term%' OR name_bangla LIKE '%$term%' OR name LIKE '%$term%' OR phone LIKE '%$term%' OR blood LIKE '%$term%' OR district LIKE '%$term%' OR hall LIKE '%$term%'";
        }
    }

    $mainArray = array();
    $mainQuery = " ";

    $searchSys = implode(' OR ', $searchTermBits);
    $selectTerm = " student_id,name_bangla,name,batch,phone,blood,district, email, fb_id, photo, address, address_bangla,id, showing, active ";
    if (($loggedin['batch'] == $category) || ($loggedin['role'] == 'dev')) {
        $mainQuery = " AND active = :active AND (" . $searchSys . ")";
        $mainArray = array(
            'active' => "1",
        );
    } else {
        $mainQuery = " AND active = :active AND showing =:showing AND (" . $searchSys . ")";
        $mainArray = array(
            'active' => "1",
            'showing' => "1",
        );
    }

    $mainOrder = " ORDER BY SUBSTRING(student_id, 7,4) ASC";

    if (!empty($searchValue)) {
        $mainQuery = $mainQuery . " AND (
        hall LIKE :hall_name OR 
        student_id LIKE :student_id OR 
        phone LIKE :phone OR 
        name LIKE :name OR 
        batch LIKE :batch OR 
        district LIKE :district OR 
        blood LIKE :blood OR 
        email LIKE :email ) ";
        $mainArrayS = array(
            'hall_name' => "%$searchValue%",
            'student_id' => "%$searchValue%",
            'name' => "%$searchValue%",
            'batch' => "%$searchValue%",
            'district' => "%$searchValue%",
            "phone" => "%$searchValue%",
            "blood" => "%$searchValue%",
            "email" => "%$searchValue%",
        );

        $mainArray = array_merge($mainArray, $mainArrayS);
    }
    // else {
    //     $searchQuery = $mainQuery;
    //     // $searchArray = $mainArray;
    // }

    if ($category == "any_batch") {
        $sql_array = array();
        $sql = "SELECT * FROM batch WHERE active='1' ORDER by batch DESC";
        $stmt_s = $conn->prepare($sql);
        $stmt_s->execute();
        foreach ($stmt_s as $row_s) {
            $row_batch = $row_s['batch'];
            $row_batch_sql = "SELECT {$selectTerm} FROM {$row_batch} WHERE 1 " . $mainQuery;
            $sql_array[] = $row_batch_sql;
        }
        $sql = "";
        foreach ($sql_array as $sql_query) {
            $sql .= $sql_query;
            if (next($sql_array)) {
                $sql .= " UNION ALL ";
            }
        }
        $totalRecordwithFilterSql = "SELECT COUNT(id) AS allcount FROM (" . $sql . ") AS std";
        $fetchRecordSql = $sql;
    } else {
        $totalRecordwithFilterSql = "SELECT COUNT(*) AS allcount FROM {$category} WHERE 1 " . $mainQuery;
        $fetchRecordSql = "SELECT * FROM {$category} WHERE 1 " . $mainQuery;
    }

    ## Total number of records without filtering
    $stmt = $conn->prepare($totalRecordwithFilterSql . " " . $mainOrder);
    // $stmt = $conn->prepare("SELECT COUNT(*) AS allcount FROM {$view_batch} WHERE 1 " . $mainQuery . " " . $mainOrder);
    $stmt->execute($mainArray);
    $records = $stmt->fetch();
    $totalRecords = $records['allcount'];

    ## Total number of records with filtering
    // $stmt = $conn->prepare("SELECT COUNT(*) AS allcount FROM {$view_batch} WHERE 1 " . $mainQuery);
    $stmt = $conn->prepare($totalRecordwithFilterSql);
    $stmt->execute($mainArray);
    $records = $stmt->fetch();
    $totalRecordwithFilter = $records['allcount'];

    // $orderBy = (($columnName !== '') ? " ORDER BY " . $columnName . " " . $columnSortOrder : $mainOrder);
    $orderBy = (($columnName !== '') ? $mainOrder : " ORDER BY " . $columnName . " " . $columnSortOrder);
    ## Fetch records
    $stmt = $conn->prepare($fetchRecordSql . " " . $orderBy . "  LIMIT :limit,:offset");
    // $stmt = $conn->prepare("SELECT * FROM {$view_batch} WHERE 1 " . $mainQuery . "  " . $orderBy . "  LIMIT :limit,:offset");

    // Bind values
    foreach ($mainArray as $key => $search) {
        $stmt->bindValue(':' . $key, $search, PDO::PARAM_STR);
    }

    $stmt->bindValue(':limit', (int)$row, PDO::PARAM_INT);
    $stmt->bindValue(':offset', (int)$rowperpage, PDO::PARAM_INT);
    $stmt->execute();
    $empRecords = $stmt->fetchAll();

    $data = array();

    foreach ($empRecords as $row) {
        $img = $row['photo'];
        $id = $row['id'];
        $student_id = $row['student_id'];
        $phone = $row['phone'];
        $name = $row['name'];
        $email = $row['email'];
        $fb_id = $row['fb_id'];
        $batch = $row['batch'];
        $facebook_url = $others->get_facebook_url($fb_id);
        if (($row['showing'] == '1') && ($row['active'] == '1')) {
            $btnColor = 'success';
        } else if ($row['active'] == '0') {
            $btnColor = 'danger';
        } else if ($row['showing'] == '0') {
            $btnColor = 'warning';
        }
        $view = '<button type="button" class="view_btn btn btn-' . $btnColor . ' btn-sm" data-batch="' . $batch . '" data-id="' . $row['id'] . '" id="view_btn_stds"><i class="fas fa-eye"></i></button>';

        $keyAdd = $othersData->getOthersData('add_info_key', $student_id, 'student_id', 'DESC');
        $key = $keyAdd['key'];

        if (empty($img)) {
            $img = "  <div class='avatar'><a class='fb_id' target='_blank' href='https://www.facebook.com/" . $facebook_url . "'><img src='ais-assets/icon/demo.png'><img class='img-top' src='ais-assets/icon/fb.png'></a></div>";
        } else {
            $img = "<div class='avatar'><a class='fb_id' target='_blank' href='https://www.facebook.com/" . $facebook_url . "'><img src='image/" . $img . "'><img class='img-top' src='ais-assets/icon/fb.png'></a></div>";
        }

        $data[] = array(
            "photo" => $img,
            "student_id" => $row['student_id'],
            "name" => ucwords(strtolower($row['name'])),
            "batch" => $row['batch'],
            "phone" => "<a href='tel:" . $row['phone'] . "'>" . $row['phone'] . "</a>",
            "blood" => "<a href='dataview.php?view_batch&customize_data_view&batch=" . $row['batch'] . "&blood=" . $row['blood'] . "'><span style='color:red; font-weight:bold;'>" . $row['blood'] . "</span></a> ",
            "email" => "<a href='mailto:" . $row['email'] . "'>" . $row['email'] . "</a>",
            "action" =>  $view
        );
    }

    ## Response
    $response = array(
        "draw" => intval($draw),
        "iTotalRecords" => $totalRecords,
        "iTotalDisplayRecords" => $totalRecordwithFilter,
        "aaData" => $data
    );

    exit(json_encode($response));
    $conn = null;
} catch (Exception $e) {
    echo "Ha Ha Ha !!! You are fool.";
}
