<?php
session_start();
error_reporting(0);

require __DIR__ . '/conn.php';
include __DIR__ . '/data.php';
require __DIR__ . '/others.php';
$conn = $pdo->open();
$dataLog = new Data();
$others = new Others();
$othersData = new Data();
$batch = $_SESSION['batch'];
$student_id = $_SESSION['student_id'];

$loggedin = $dataLog->batchData($batch, $student_id, 'student_id');
try {
    ## Read value
    $draw = $_POST['draw'];
    $row = $_POST['start'];
    $rowperpage = $_POST['length']; // Rows display per page
    $columnIndex = $_POST['order'][0]['column']; // Column index
    $columnName = $_POST['columns'][$columnIndex]['data']; // Column name
    $columnSortOrder = $_POST['order'][0]['dir']; // asc or desc
    $searchValue = $_POST['search']['value']; // Search value
    $dTable = $_POST['dTable'];


    $mainArray = array();

    ## Search 
    $mainQuery = " ";

    // $mainQuery = " ";
    // $mainArray = array();

    $mainOrder = " ORDER BY id DESC";

    if ($searchValue != '') {
        $mainQuery = $mainQuery . " AND (
        student_id LIKE :student_id OR 
        batch LIKE :batch OR 
        name LIKE :name OR 
        keywords LIKE :keywords OR 
        key_cat LIKE :key_cat OR 
        date LIKE :date ) ";
        $mainArrayS = array(
            'student_id' => "%$searchValue%",
            'name' => "%$searchValue%",
            "batch" => "%$searchValue%",
            "keywords" => "%$searchValue%",
            "key_cat" => "%$searchValue%",
            "date" => "%$searchValue%",
        );

        $mainArray = array_merge($mainArray, $mainArrayS);
    }
    // else {
    //     $searchQuery = $mainQuery;
    //     // $searchArray = $mainArray;
    // }

    ## Total number of records without filtering
    $stmt = $conn->prepare("SELECT COUNT(*) AS allcount FROM {$dTable} WHERE 1 " . $mainQuery . " " . $mainOrder);
    $stmt->execute($mainArray);
    $records = $stmt->fetch();
    $totalRecords = $records['allcount'];

    ## Total number of records with filtering
    $stmt = $conn->prepare("SELECT COUNT(*) AS allcount FROM {$dTable} WHERE 1 " . $mainQuery);
    $stmt->execute($mainArray);
    $records = $stmt->fetch();
    $totalRecordwithFilter = $records['allcount'];

    $orderBy = (($columnName !== '') ? " ORDER BY " . $columnName . " " . $columnSortOrder : $mainOrder);
    ## Fetch records
    $stmt = $conn->prepare("SELECT * FROM {$dTable} WHERE 1 " . $mainQuery . "  " . $orderBy . "  LIMIT :limit,:offset");

    // Bind values
    foreach ($mainArray as $key => $search) {
        $stmt->bindValue(':' . $key, $search, PDO::PARAM_STR);
    }

    $stmt->bindValue(':limit', (int)$row, PDO::PARAM_INT);
    $stmt->bindValue(':offset', (int)$rowperpage, PDO::PARAM_INT);
    $stmt->execute();
    $empRecords = $stmt->fetchAll();

    $data = array();

    foreach ($empRecords as $row) {

        $id = $row['id'];
        $student_id = $row['student_id'];
        $name = $row['name'];
        $batch = $row['batch'];
        $date = $row['date'];
        $key_cat = $row['key_cat'];
        $keywords = $row['keywords'];

        $find = array("+", "-");
        $replace = array("%2B","%2D");
        $keywords = str_replace($find, $replace, $keywords);

        $view = '<a type="button" target="_blank" href="home.php?query='.$keywords.'&category=' . $key_cat . '&ref=search_log#search_results" class="view_btn btn btn-success btn-sm">Search Again</a>';

        $data[] = array(
            "id" => $row['id'],
            "activity" => $row['name'] . ' - ' . $row['student_id'] . ' (' . $row['batch'] . ')',
            "details" => "<span class='text-danger'>".$row['keywords'] . ' - ' . $row['key_cat']."</span>",
            "date" => date('d F, Y h:i A', strtotime($row['date'])),
            "action" =>  $view
        );
    }

    ## Response
    $response = array(
        "draw" => intval($draw),
        "iTotalRecords" => $totalRecords,
        "iTotalDisplayRecords" => $totalRecordwithFilter,
        "aaData" => $data
    );
    exit(json_encode($response));
    $conn = null;

} catch (Exception $e) {
    echo "Ha Ha Ha !!! You are fool.";
}
