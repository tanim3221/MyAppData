<?php
class Data
{
    private $conn;
    public function __construct()
    {
        $this->conn = new Database();
        $this->conn = $this->conn->open();
    }

    public function batchData($table, $value, $column)
    {
        $stmt = $this->conn->prepare("SELECT * FROM {$table} WHERE {$column}='" . $value . "'");
        $stmt->execute();
        $data = $stmt->fetch();
        return $data;
        $this->conn = null;

    }
    public function batchDataMultiple($table, $value, $column)
    {
        $stmt = $this->conn->prepare("SELECT * FROM {$table} WHERE {$column}='" . $value . "'");
        $stmt->execute();
        foreach ($stmt as $row) {
			$output[] = $row;
		}
		return $output;
        $this->conn = null;

    }
    public function getOthersData($table, $value, $col, $order)
    {
        $stmt = $this->conn->prepare("SELECT * FROM {$table} WHERE {$col}='" . $value . "' ORDER BY id {$order}");
        $stmt->execute();
        $data = $stmt->fetch();
        return $data;
        $this->conn = null;

    }
    public function visitToday()
    {
        $now = date("Y-m-d");
        $stmt = $this->conn->prepare("SELECT COUNT(DISTINCT student_id) As nth_now FROM login WHERE DATE(time)='".$now."'");
        $stmt->execute();
        $data = $stmt->fetch();
        return $data;
        $this->conn = null;

    }
    public function visitTotal()
    {
        $stmt = $this->conn->prepare("SELECT COUNT(DISTINCT student_id) As nth_t FROM login");
        $stmt->execute();
        $data = $stmt->fetch();
        return $data;
        $this->conn = null;

    }

    public function batchCount($tbl, $where)
    { 
        $stmt = $this->conn->prepare("SELECT COUNT(id) As cnt FROM {$tbl} {$where}");
        $stmt->execute();
        $numRows = $stmt->fetchColumn();
        return $numRows;
        $this->conn = null;

    }

    public function customSqlRun($sql)
    { 
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        $numRows = $stmt->fetchColumn();
        return $numRows;
        $this->conn = null;

    }
    public function customSqlMultiple($sql)
    { 
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        foreach ($stmt as $row) {
			$output[] = $row;
		}
		return $output;
        $this->conn = null;

    }

    public function itemCountDistinct($tbl, $where)
    { 
        $stmt = $this->conn->prepare("SELECT DISTINCT COUNT(id) As cnt FROM {$tbl} {$where}");
        $stmt->execute();
        $numRows = $stmt->fetchColumn();
        return $numRows;
        $this->conn = null;

    }

    public function getAdminInfo($batch=FALSE){

        if ($batch==""){
            $sql_array = [];
            $sql = "SELECT * FROM batch ORDER by batch DESC";
            $stmt = $this->conn->prepare($sql);
            $stmt->execute();
            foreach ($stmt as $row) {
                $row_batch = $row['batch'];
                $row_batch = "SELECT name,id, batch, student_id, email, role FROM {$row_batch} WHERE active='1'";
                $sql_array[] = $row_batch;
            }
            $sql = '';
            foreach ($sql_array as $sql_query) {
                $sql .= $sql_query;
                if (next($sql_array)) {
                    $sql .= ' UNION ';
                }
            }
            $sql .= "ORDER by batch, SUBSTRING(student_id, 7,4) ASC";
        } else {
            $sql = "SELECT * FROM {$batch} WHERE (role='admin' OR role='dev')";
        }

		$data =array();
		$stmt = $this->conn->prepare($sql);
		$stmt->execute();
		foreach ($stmt as $rows) {
			$data [] = $rows;
		}
        return $data;
        $this->conn = null;
    }

    public function getAllBatch()
    {
        $sql_array = [];
        $sql = "SELECT * FROM batch ORDER by batch DESC";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute();
        foreach ($stmt as $row) {
            $row_batch = $row['batch'];
            $row_batch = "SELECT name,id, batch, student_id, role FROM {$row_batch} WHERE active='1'";
            $sql_array[] = $row_batch;
        }
        $sql = '';
        foreach ($sql_array as $sql_query) {
            $sql .= $sql_query;
            if (next($sql_array)) {
                $sql .= ' UNION ';
            }
        }
        $sql .= "ORDER by batch, SUBSTRING(student_id, 7,4) ASC";
        $output = array();
        $stmt1 = $this->conn->prepare($sql);
        $stmt1->execute();
        foreach ($stmt1 as $row) {
            $output[] = $row;
        }

        return $output;
        $this->conn = null;

    }
        
    public function addInfo($post)
    {
        $name = $post['name'];
        $name_bangla = $post['name_bangla'];
        $fb_id = str_replace(' ', '', $post['fb_id']);
        $blood = $post['blood'];
        $email = str_replace(' ', '', $post['email']);
        $student_id = str_replace(' ', '', $post['student_id']);
        $batch = str_replace(' ', '', $post['batch']);
        $phone = $post['phone'];
        $district = $post['district'];
        $address_bangla = $post['address_bangla'];
        $address = $post['address'];
        $birth = $post['birth'];
        $father_name = $post['father_name'];
        $curDate = date("Y-m-d H:i:s");
        $Password = $post['Password'];
        $ConPassword = $post['ConPassword'];
        $job_ins = $post['job_ins'];
        $job_p = $post['job_p'];
        $hall_name = $post['hall_name'];
        $active = 1;
        $showing = 1;
        if ($Password==$ConPassword){
            // $stmt = $this->conn->prepare("UPDATE {$batch} SET job_ins='$job_ins', job_p='$job_p', hall='$hall_name', name='$name',name_bangla='$name_bangla' ,fb_id='$fb_id',blood='$blood',phone='$phone',district='$district',address_bangla='$address_bangla',address='$address', birth='$birth', father_name='$father_name', LastUpdateTime='$curDate', Password='$Password', active='$active' , showing='$showing' WHERE student_id='" . $student_id . "' AND email='" . $email . "' AND batch ='" . $batch . "'");
            $stmt = $this->conn->prepare("UPDATE {$batch} SET job_ins=:job_ins, job_p=:job_p, hall=:hall_name, name=:name,name_bangla=:name_bangla,fb_id=:fb_id,blood=:blood,phone=:phone,district=:district, address_bangla=:address_bangla, address=:address, birth=:birth, father_name=:father_name, LastUpdateTime=:curDate, Password=:Password, active=:active, showing=:showing WHERE student_id=:student_id AND email=:email AND batch =:batch");
                
            $stmt->execute(['job_ins'=>$job_ins, 'job_p'=>$job_p, 'hall_name'=>$hall_name, 'name'=>$name,'name_bangla'=>$name_bangla,'fb_id'=>$fb_id,'blood'=>$blood,'phone'=>$phone,'district'=>$district,'address_bangla'=>$address_bangla,'address'=>$address, 'birth'=>$birth, 'father_name'=>$father_name, 'curDate'=>$curDate, 'Password'=>$Password, 'active'=>$active, 'showing'=>$showing , 'student_id'=>$student_id, 'email'=>$email, 'batch' => $batch]);
            if ($stmt->rowCount()) {
                // $msg = "Information updated successfully.";
                $stmt_d  = $this->conn->prepare("DELETE FROM `add_info_key` WHERE `email`='" . $post["email"] . "';");
                $stmt_d->execute();
                $response = 2; // Successfully submitted data
            } else {
                $response = 0; // Data not submitted successfully
            }
        } else {
            $response = 1; // Password not matched with confirm password
        }
        // return array($error, $msg);
        return $response;
        $this->conn = null;
    }
}
