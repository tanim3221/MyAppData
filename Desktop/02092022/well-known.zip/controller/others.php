<?php
class Others
{
	private $conn;
	public function __construct()
	{
		$this->conn = new Database();
		$this->conn = $this->conn->open();
	}

	public function get_client_ip() {
		$ipaddress = '';
		if (isset($_SERVER['HTTP_CLIENT_IP']))
			$ipaddress = $_SERVER['HTTP_CLIENT_IP'];
		else if(isset($_SERVER['HTTP_X_FORWARDED_FOR']))
			$ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR'];
		else if(isset($_SERVER['HTTP_X_FORWARDED']))
			$ipaddress = $_SERVER['HTTP_X_FORWARDED'];
		else if(isset($_SERVER['HTTP_FORWARDED_FOR']))
			$ipaddress = $_SERVER['HTTP_FORWARDED_FOR'];
		else if(isset($_SERVER['HTTP_FORWARDED']))
			$ipaddress = $_SERVER['HTTP_FORWARDED'];
		else if(isset($_SERVER['REMOTE_ADDR']))
			$ipaddress = $_SERVER['REMOTE_ADDR'];
		else
			$ipaddress = 'UNKNOWN';
		return $ipaddress;
        $this->conn = null;

	}

	public function insertLoginInfo($action, $detect, $uip)
	{
	
		$useragent = $_SERVER['HTTP_USER_AGENT'];
		if ($detect->isMobile()) {
			$device = 'Mobile';
		} else {
			$device = 'Desktop';
		}
		
		$http = $_SERVER['HTTP_HOST'];
		$uip = explode(',', $uip);
		$uip = $uip[0];
		// $uip = '119.30.32.182';
		$batch = $_SESSION['batch'];
		$student_id = $_SESSION['student_id'];
		// $curDate = date("Y-m-d H:i:s");
		$curDate = date("Y-m-d H:i:s");

		//Start Get IP Locaion of ipxapi.com
		// $curl = curl_init();
		// curl_setopt_array($curl, array(
		//   CURLOPT_URL => "https://ipxapi.com/api/ip?ip=".$uip."",
		//   CURLOPT_RETURNTRANSFER => true,
		//   CURLOPT_ENCODING => "",
		//   CURLOPT_MAXREDIRS => 10,
		//   CURLOPT_TIMEOUT => 30,
		//   CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		//   CURLOPT_HTTPHEADER => array(
		// 	"Accept: application/json",
		// 	"Authorization: Bearer 1945|GEDlaQS5p7lI597p0NtXrZ4TfW75B9qdVqRP6Mjy",
		// 	"Content-Type: application/json",
		// 	"cache-control: no-cache"
		//   ),
		// ));
		
		// $response = curl_exec($curl);
		// curl_close($curl);
		// $api_result = json_decode($response, true);

		// $continent = $api_result['continentName'];
		// $longitude = $api_result['lon'];
		// $latitude = $api_result['lat'];
		// $city = $api_result['city']."-".$api_result['zip'];
		// $capital = $api_result['location']['capital'];
		// $calling_code = $api_result['callingCode'];
		// $country_flag = $api_result['flag'];
		// $region = $api_result['regionName'];
		// $country = $api_result['country'];
		// $isp = $api_result['isp'];
		// $country_code = $api_result['countryCode'];


		// Start Get IP Locaion of ipstack.com
		$access_key = '12c56483145c7dba04d707f6138bec50';
		$ch = curl_init('http://api.ipstack.com/' . $uip . '?access_key=' . $access_key . '');
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$json = curl_exec($ch);
		curl_close($ch);
		$api_result = json_decode($json, true);
	
		$continent = $api_result['continent_name'];
		$longitude = $api_result['longitude'];
		$latitude = $api_result['latitude'];
		$city = $api_result['city'];
		$capital = $api_result['location']['capital'];
		$calling_code = $api_result['location']['calling_code'];
		$country_flag = $api_result['location']['country_flag'];
		$region = $api_result['region_name'];
		$country = $api_result['country_name'];
		$country_code = $api_result['country_code'];
		// End Get IP Location ipstack.com
	
		$geo = json_decode(file_get_contents("http://extreme-ip-lookup.com/json/$uip"));
		$isp = $geo->isp;
	
		$stmt = $this->conn->prepare("INSERT INTO login (device, http, capital, city, region, country, country_flag, calling_code, country_code, continent, latitude, longitude, isp, ip, student_id, batch, time, details, action) VALUES ('$device', '$http', '$capital','$city','$region','$country','$country_flag','$calling_code','$country_code','$continent','$latitude','$longitude','$isp', '$uip', '$student_id', '$batch', '$curDate', '$useragent', '$action')");
		$in = $stmt->execute();
		return $in;
        $this->conn = null;

		// Loggedin users info
	}

	public function getBatch()
	{
		$Data = array();
		$stmt = $this->conn->prepare("SELECT * FROM batch WHERE active='1' ORDER by batch DESC");
		$stmt->execute();
		foreach ($stmt as $row) {
			$Data[] = $row;
		}
		return $Data;
        $this->conn = null;

	}
	public function getMaintenance()
	{
		$Data = array();
		$stmt = $this->conn->prepare("SELECT * FROM maintenance ORDER by id DESC LIMIT 1");
		$stmt->execute();
		$output = $stmt->fetch();
		return $output;
        $this->conn = null;

	}
	public function getCheckList()
    {
        $data = array();
        $stmt = $this->conn->prepare("SELECT DISTINCT (param) FROM checklist");
        $stmt->execute();
        foreach ($stmt as $row) {
            $data[] = $row;
        }
        return $data;
    }

    public function getCheckListDisct($param)
    {
        $data = array();
        $stmt = $this->conn->prepare("SELECT * FROM checklist WHERE param = '" . $param . "'");
        $stmt->execute();
        foreach ($stmt as $row) {
            $data[] = $row;
        }
        return $data;
    }
	public function getBatchAll()
	{
		$Data = array();
		$stmt = $this->conn->prepare("SELECT * FROM batch ORDER by batch DESC");
		$stmt->execute();
		foreach ($stmt as $row) {
			$Data[] = $row;
		}
		return $Data;
        $this->conn = null;

	}
	public function getLog($table, $order)
	{
		$Data = array();
		$stmt = $this->conn->prepare("SELECT * FROM {$table} ORDER BY {$order}");
		$stmt->execute();
		foreach ($stmt as $row) {
			$Data[] = $row;
		}
		return $Data;
        $this->conn = null;

	}
	public function getMegaMenu()
	{
		$Data = array();
		$stmt = $this->conn->prepare("SELECT * FROM mega_menu GROUP BY category ORDER BY category DESC");
		$stmt->execute();
		foreach ($stmt as $row) {
			$Data[] = $row;
		}
		return $Data;
        $this->conn = null;

	}
	public function getMegaMenuCat($cat)
	{
		$Data = array();
		$stmt = $this->conn->prepare("SELECT * FROM mega_menu WHERE category='" . $cat . "'");
		$stmt->execute();
		foreach ($stmt as $row) {
			$Data[] = $row;
		}
		return $Data;
        $this->conn = null;

	}
	public function getCourse()
	{
		$Data = array();
		$stmt = $this->conn->prepare("SELECT * FROM course_list ORDER BY course_code");
		$stmt->execute();
		foreach ($stmt as $row) {
			$Data[] = $row;
		}
		return $Data;
        $this->conn = null;

	}

	public function getSearchHistory($batch, $student_id)
	{
		$output = array();
		$stmt = $this->conn->prepare("SELECT * FROM search WHERE batch= '" . $batch . "' AND student_id= '" . $student_id . "' ORDER by date DESC");
		$stmt->execute();
		foreach ($stmt as $row) {
			$output[] = $row;
		}
		return $output;
        $this->conn = null;

	}

	public function getBirthdayDate()
	{
		$sql_array = [];
		$output = array();
		$month = date('m');
		$day = date('d');
		$stmt = $this->conn->prepare("SELECT * FROM batch WHERE active='1' ORDER by batch DESC");
		$stmt->execute();
		foreach ($stmt as $row) {
			$row_batch = $row['batch'];
			$row_batch_s = "SELECT id, student_id, birth, name, photo, batch FROM {$row_batch} WHERE active='1'  AND DAY (birth)='" . $day . "' AND MONTH (birth)='" . $month . "'";
			$sql_array[] = $row_batch_s;
		}
		$sql = '';
		foreach ($sql_array as $sql_query) {
			$sql .= $sql_query;
			if (next($sql_array)) {
				$sql .= ' UNION ';
			}
		}
 
		$sql .= " ORDER BY batch ASC";
		$stmt = $this->conn->prepare($sql);
		$stmt->execute();
		foreach ($stmt as $row) {
			$output[] = $row;
		}
		return $output;
        $this->conn = null;

	}

	public function get_facebook_url($fb_id)
	{
		$facebook_url = array('https://www.facebook.com/profile.php?id=', 'https://web.facebook.com/profile.php?id=', 'https://m.facebook.com/profile.php?id=', 'https://facebook.com/', 'https://m.facebook.com/', 'https://www.facebook.com/', 'https://mobile.facebook.com/', 'https://web.facebook.com/', 'https://m.me/');
		$data = str_replace($facebook_url, '', $fb_id);
		return $data;
        $this->conn = null;

	}

	public function getUpcomingBirthdayDate()
	{
		$sql_array = [];
		$output = array();
		$month = date('m');
		$day = date('d');
		$today = date("Y-m-d");
		$start_day = strtotime($today."+1 day");
		$end_day = new DateTime(date("Y-m-d"));
		$end_day = $end_day->format("t");
		// $end_day = strtotime($today."+15 day");
		$start_day = date('d', $start_day);
		// $end_day = date('d', $end_day);
		$stmt = $this->conn->prepare("SELECT * FROM batch WHERE active='1' ORDER by batch DESC");
		$stmt->execute();
		foreach ($stmt as $row) {
			$row_batch = $row['batch'];
			// $th . $row_batch = "SELECT id, student_id, birth, name, photo, batch FROM {$row_batch} WHERE active='1' AND MONTH (birth)='" . $month . "'";
			$row_batch_s = "SELECT id, student_id, birth, name, photo, batch FROM {$row_batch} WHERE active='1' AND MONTH (birth)='" . $month . "' AND (DAY (birth) BETWEEN '" . $start_day . "' AND '" . $end_day . "')";
			$sql_array[] = $row_batch_s;
		}
		$sql = '';
		foreach ($sql_array as $sql_query) {
			$sql .= $sql_query;
			if (next($sql_array)) {
				$sql .= ' UNION ';
			}
		}

		$sql .= "ORDER BY DATE_FORMAT(birth, '%m-%d') ASC";
		$stmt = $this->conn->prepare($sql);
		$stmt->execute();
		foreach ($stmt as $row) {
			$output[] = $row;
		}
		return $output;
        $this->conn = null;

	}

	public function getHallByCode($code)
	{
		$output = array();
		$stmt = $this->conn->prepare("SELECT * FROM hall WHERE code=".$code."");
		$stmt->execute();
		$hall_name = $stmt->fetch();
		return $hall_name;
        $this->conn = null;
	}	
	public function getHallName($hall_code)
	{
		$hall_name = '';
		if ($hall_code == 102) {
			$hall_name = 'Shah Mukhdum Hall – শাহ্‌ মখদুম হল';
		} elseif ($hall_code == 111) {
			$hall_name = 'Bangabandhu Sheikh Mujibur Rahman Hall – বঙ্গবন্ধু শেখ মুজিবুর রহমান হল';
		} elseif ($hall_code == 125) {
			$hall_name = 'Bangamata  Fazilatunnesa  Hall – বঙ্গমাতা ফজিলাতুন্নেসা হল';
		} elseif ($hall_code == 123) {
			$hall_name = 'Begum Khaleda Zia Hall – বেগম খালেদা জিয়া হল';
		} elseif ($hall_code == 108) {
			$hall_name = 'Madar Bux Hall – মাদার বখ্‌শ হল';
		} elseif ($hall_code == 120) {
			$hall_name = 'Mannujan Hall – মুন্নুজান হল';
		} elseif ($hall_code == 107) {
			$hall_name = 'Matihar Hall – মতিহার হল';
		} elseif ($hall_code == 103) {
			$hall_name = 'Nawab Abdul Latif Hall – নবাব আব্দুল লতিফ হল';
		} elseif ($hall_code == 124) {
			$hall_name = 'Rahamatunnesa Hall – রহমতুন্নেসা হল';
		} elseif ($hall_code == 121) {
			$hall_name = 'Rokeya Hall -রোকেয়া হল';
		} elseif ($hall_code == 106) {
			$hall_name = 'Shaheed Habibur Rahman Hall – শহীদ হবিবুর রহমান হল';
		} elseif ($hall_code == 105) {
			$hall_name = 'Shaheed Shamsuzzoha Hall – শহীদ শামসুজ্জোহা হল';
		} elseif ($hall_code == 109) {
			$hall_name = 'Shaheed Suhrawardy Hall – শহীদ সোহ্‌রাওয়ার্দী হল';
		} elseif ($hall_code == 110) {
			$hall_name = 'Shaheed Ziaur Rahman Hall – শহীদ জিয়াউর রহমান হল';
		} elseif ($hall_code == 101) {
			$hall_name = 'Sher-e Bangla Fazlul Haque Hall –  শের-ই-বাংলা ফজলুল হক হল';
		} elseif ($hall_code == 104) {
			$hall_name = 'Syed Amer Ali Hall – সৈয়দ আমীর আলী হল';
		} elseif ($hall_code == 122) {
			$hall_name = 'Tapashi Rabeya Hall – তাপসী রাবেয়া হল';
		} else {
			//$hall = $row['hall'];
			//$hall_name = (!empty($hall)) ? $row['hall'] : 'Hall not yet specified';
			$hall_name = 0;
		}
		return $hall_name;
        $this->conn = null;

	}
	public function getCourseYear()
	{
		$output = array();
		$stmt = $this->conn->prepare("SELECT DISTINCT(year) FROM course_list ORDER by year ASC");
		$stmt->execute();
		foreach ($stmt as $row) {
			$output[] = $row;
		}
		return $output;
        $this->conn = null;

	}

	public function getLimitData($tble)
	{	
		$output = array();
		$stmt = $this->conn->prepare($tble);
		$stmt->execute();
		foreach ($stmt as $row) {
			$output[] = $row;
		}
		return $output;
        $this->conn = null;
	}	


	public function getEncrypted ($string){
		$ciphering = "AES-128-CTR";
		$iv_length = openssl_cipher_iv_length($ciphering);
		$options = 0;
		$encryption_iv = '1234567891011121';
		$encryption_key = "I Love You";
		$encryption = openssl_encrypt($string, $ciphering,
					$encryption_key, $options, $encryption_iv);
		return $encryption;
	}
	
	public function getDecrypted ($encryption){

		$ciphering = "AES-128-CTR";
		$iv_length = openssl_cipher_iv_length($ciphering);
		$options = 0;
		$decryption_iv = '1234567891011121';
		$decryption_key = "I Love You";
		$decryption=openssl_decrypt ($encryption, $ciphering, 
        $decryption_key, $options, $decryption_iv);
		return $decryption;
	}

	public function getIndData($tble, $id)
	{	
		$output = array();
		$stmt = $this->conn->prepare("SELECT * FROM {$tble} WHERE student_id=".$id."");
		$stmt->execute();
		$output = $stmt->fetch();
		return $output;
        $this->conn = null;
	}	

	public function activity_log_save($details_activity, $loggedinInfoInsert)
	{
		$date = date("Y-m-d H:i:s");
		$date_chk = date("Y-m-d H:i");
		$student_id = $loggedinInfoInsert['student_id'];
		$batch = $loggedinInfoInsert['batch'];
		$name = $loggedinInfoInsert['name'];
	
		$stmt = $this->conn->prepare("SELECT *, COUNT(*) AS numrows FROM activity_log WHERE details=:details AND student_id=:std_id AND DATE_FORMAT(date, '%Y-%m-%d %H:%i')=:date");
		$stmt->execute(['details'=>$details_activity, 'date'=>$date_chk, 'std_id'=>$student_id]);
		$row = $stmt->fetch();
		#Check double activity log
		if ($row['numrows'] < 1) {
			$stmt = $this->conn->prepare("INSERT INTO activity_log (student_id, name, details, batch, date) VALUES (:std_id, :name, :details, :batch, :date)");
			$stmt->execute(['std_id'=>$student_id,'name'=>$name,'details'=>$details_activity,'batch'=>$batch,'date'=>$date]);
		}
        $this->conn = null;

	}

}
