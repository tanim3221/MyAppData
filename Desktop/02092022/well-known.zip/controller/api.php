<?php
session_start();
error_reporting(0);
require __DIR__ . '/conn.php';
require_once __DIR__ . '/data.php';
require_once __DIR__ . '/others.php';
require_once __DIR__ . '/photo.php';
require_once __DIR__ . '/file.php';
include __DIR__ . '/../PHPMailer/PHPMailerAutoload.php';
require_once __DIR__ . '/mail.php';
require_once __DIR__ . '/../phpqrcode/phpqrcode.php';
require_once __DIR__ . '/../PhpSpreadsheet/PHPExcel.php';
require_once __DIR__ . '/notification.php';
require_once __DIR__ . '/mobile_detect.php';
// require_once __DIR__.'/../PHPMailer/smtp_validateEmail.class.php';
$connPdo = $pdo->open();
$notification = new Notification();
$data = new Data();
$others = new Others();
$photos = new Photo();
$mailSend = new Mail();
$filesData = new Files();
$detect = new Mobile_Detect;
// $SMTP_Validator = new SMTP_validateEmail();
$getMaintenance = $others->getMaintenance();


// $get_batch = $_GET['batch'];
if (isset($_SESSION['student_id'])) {
    $batch = $_SESSION['batch'];
    $loggedin = $data->batchData($batch, $_SESSION['student_id'], 'student_id');
    $loggedin_name = $loggedin['name'];
    if (isset($_SESSION['student_id'])) {
        $loggedinInfoInsert = array(
            'name' => $loggedin['name'],
            'batch' => $loggedin['batch'],
            'student_id' => $loggedin['student_id']
        );
    }
}
$msg = array('error' => false, 'warning' => false);
if (isset($_POST['createDataTable']) && ($loggedin['role'] == 'dev')) {
    $active_batch = $_POST['active'];
    $id = rand(10000, 1000000);
    $batch_name = str_replace(' ', '', $_POST['batch_name']);
    $batch_old = str_replace(' ', '', $_POST['batch_old']);
    $date = date('d/m/Y h:ia');
    $email = str_replace(' ', '', $_POST['email']);
    $student_id = $_POST['student_id'];
    $session = $_POST['session'];
    $name_data = $_POST['name_data'];
    $role = 'admin';
    $active = '0';
    $showing = '0';
    $title = $batch_name . ' Batch';
    $duplicate = "SELECT batch FROM batch WHERE batch='$batch_name'";
    //$row_duplicate = mysqli_fetch_array($duplicate);
    $stmt = $connPdo->prepare($duplicate);
    $stmt->execute();
    $duplicate = $stmt->rowCount();
    if (isset($_POST['update_batch'])) {
        $in = "UPDATE batch SET session='$session', batch='$batch_name', title='$title', active='$active_batch', date='$date' WHERE id='" . $_POST['id'] . "'; RENAME TABLE `ais`.`$batch_old` TO `ais`.`$batch_name`;";
        $stmt = $connPdo->prepare($in);
        if ($stmt->execute()) {
            $msg['error'] = false;
            $msg['message'] = "Successfully updated " . $batch_name . " batch.";
            $details_activity = 'Batch (' . $batch_name . ') updated by ' . $loggedin_name . '.';
            $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
        } else {
            $msg['error'] = true;
            $msg['message'] = "Something went wrong, Please try again later.";
        }
    } else {
        if ($duplicate > 0) {
            $msg['error'] = true;
            $msg['message'] = "Please do not try to create again the same database.";
        } else {
            $in = "INSERT INTO batch (batch, session, title, active, date) VALUES ('$batch_name','$session', '$title',  '$active_batch', '$date')";
            $stmt = $connPdo->prepare($in);
            if ($stmt->execute()) {
                $expFormat = mktime(date("H"), date("i"), date("s"), date("m"), date("d") + 1, date("Y"));
                $expDate = date("Y-m-d H:i:s", $expFormat);
                $key = md5($email);
                $addKey = substr(md5(uniqid(rand(), 1)), 3, 10);
                $key = $key . $addKey;

                $table_batch = file_get_contents("batch.sql");
                $table_batch = str_replace("TableNameReplace", $batch_name, $table_batch);

                $batch_in = "INSERT INTO `{$batch_name}` (id, name, student_id, email, session, batch, role, active, showing) VALUES ('$id','$name_data','$student_id', '$email','$session', '$batch_name', '$role', '$active', '$showing')";

                $key_in = "INSERT INTO `add_info_key` (`batch`, `student_id`, `email`, `key`, `expDate`) VALUES ('" . $batch_name . "', '" . $student_id . "','" . $email . "', '" . $key . "', '" . $expDate . "');";

                $stmt_tb_batch = $connPdo->prepare($table_batch);
                $stmt_tb_batch->execute();

                $stmt_batch = $connPdo->prepare($batch_in);
                $stmt_batch->execute();

                $stmt_key = $connPdo->prepare($key_in);
                $stmt_key->execute();

                # Details Message
                $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
                $output = '<p>Hi ' . $name_data . ',</p>';
                $output .= '<p>Please click on the following link or copy the entire link into your browser to add your information.</p>';
                $output .= '<p>-------------------------------------------------------------</p>';
                $output .= '<p><a href="' . $actual_link . '/addinfo.php?add_info_users&key=' . $key . '&action=add" target="_blank">' . $actual_link . '/addinfo.php?add_info_users&key=' . $key . '&action=add</a></p>';
                $output .= '<p>-------------------------------------------------------------</p>';
                $output .= '<p>The link will expire after 1 day due to security reasons.</p>';
                $output .= '<p>No action is required unless you request this mail, if you already added your information, please login then you can see this database</p>';
                $output .= '<p>Thanks,<br>AIS Family Database Admin<br></p>';
                $body = $output;
                $subject = "AIS Family Database";
                # Details Message
                $mail = $mailSend->sendMail($email, $body, $subject);
                $details_activity = "New batch (" . $batch_name . "), admin (" . $student_id . ") added in database by " . $loggedin['name'] . ".";
                $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
                if ($mail == 1) {
                    $msg['error'] = false;
                    $msg['message'] = "" . $batch_name . " batch added successfully with one representative.";
                } else {
                    $msg['warning'] = true;
                    $msg['message'] = "Mail not send, please share the link manually.";
                }
            } else {
                $msg['error'] = true;
                $msg['message'] = "Something went wrong, Please try again later.";
            }
        }
    }
} elseif (($_POST['login-student'] == md5(date("h"))) && isset($_POST['batch']) && isset($_POST['student_id']) && isset($_POST['Password'])) {

    try {
        $student_id = stripslashes($_POST['student_id']);
        $password = stripslashes($_POST['Password']);
        $batch = $_POST['batch'];
        $sql = "SELECT * FROM {$batch} WHERE student_id= :student_id AND Password= :password AND active=:active";
        $stmt = $connPdo->prepare($sql);
        $up = $stmt->execute([
            'student_id' => $student_id,
            'password' => $password,
            'active' => "1"
        ]);
        $result = $stmt->rowCount();
        $result_d = $stmt->fetch();
        if ($result > 0) {
            //Maintenance Mode
            $maintenance_status = $getMaintenance['status'];
            if (($maintenance_status == 1 && $result_d['role'] !== 'dev')) {
                // echo "<script>window.location.replace('maintenance.php')</script>";
                $msg['warning'] = true;
                $msg['message'] = "Sorry ! Site under maintenance mode, Please try again letter.";
            } else {
                $_SESSION['student_id'] = $student_id;
                $_SESSION['batch'] = $batch;
                $secure_log = $others->getEncrypted($student_id . "/" . $batch);
                //Set Cookie for login redirect
                if (!empty($_POST["remember"])) {
                    // $data = "Cookies accepted";
                    // setcookie("SECURE_LOG", $batch, time() + (10 * 365 * 24 * 60 * 60));
                    setcookie("SECURE_LOG", $secure_log, time() + (86400 * 30), "/"); // 86400 = 1 day
                } else {
                    // $data = "Cookies not accepted";
                    setcookie("SECURE_LOG", "");
                }
                $action = "Login";
                $uip = $others->get_client_ip();
                $others->insertLoginInfo($action, $detect, $uip);
                $msg['error'] = false;
                $msg['message'] = "Congratulations! You have logged in successfully.";
            }
        } else {
            $msg['error'] = true;
            $msg['message'] = "Your login credentials do not match our servers, so please try again.";
        }
    } catch (Exception $e) {
        $msg['warning'] = true;
        $msg['message'] = "Something went wrong, please try again later.";
    }
} elseif (isset($_POST['add_new_admin']) && ($loggedin['role'] == 'dev')) {
    $comb = $_POST['student_batch'];
    $role_admin = $_POST['role_admin'];
    $comb = explode("/", $comb);
    $id = $comb[0];
    $student_id = $comb[1];
    $batch = $comb[2];
    $name_bn = $comb[3];
    $LastUpdateTime = date("Y-m-d H:i:s");
    $loggedin_name = $loggedin['name'];

    $in = "UPDATE {$batch} SET role='$role_admin', LastUpdateTime='$LastUpdateTime' WHERE id=" . $id;
    $stmt = $connPdo->prepare($in);
    $msg_true = '"' . $name_bn . '" updated successfully as ' . $role_admin;
    $details_activity = 'New admin  (' . $name_bn . ') added by ' . $loggedin_name . ' as ' . $role_admin . '.';
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = $msg_true;
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['maintenance_mode']) && ($loggedin['role'] == 'dev')) {
    $today_date = date("Y-m-d H:i:s");
    $mode_date_time = $_POST['mode_date_time'];
    $mode_ena_dis = $_POST['mode_ena_dis'];
    $start_mode_date_time = empty($_POST['start_mode_date_time']) ? $today_date : $_POST['start_mode_date_time'];
    $data_id = $_POST['data_id'];
    $status = $mode_ena_dis;
    $expiry_date = $mode_date_time;
    $date_start = $start_mode_date_time;
    $date_end = date("Y-m-d H:i:s", strtotime($mode_date_time));
    $made_by = $loggedin_name;
    $made_date = $today_date;
    $in = "UPDATE maintenance SET status='$status', expiry_date='$expiry_date', date_start='$date_start', date_end='$date_end', made_date='$made_date' WHERE id=" . $data_id;

    $stmt = $connPdo->prepare($in);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = "Maintenance mode updated successfully.";

        if ($status == 1) {
            $details_activity = 'Maintenance mode enabled till ' . $expiry_date . ' by ' . $loggedin_name . '.';
        } else {
            $details_activity = 'Maintenance mode disabled on ' . $today_date . ' by ' . $loggedin_name . '.';
        }
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
        $in = "INSERT INTO maintenance_history (m_id, expiry_date, status, date_start, date_end, made_by, made_date) VALUES ('$data_id','$expiry_date','$status','$date_start','$date_end','$made_by','$made_date')";
        $stmt_in = $connPdo->prepare($in);
        $stmt_in->execute();
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['checkListUpdateBatch']) && ($loggedin['role'] == 'dev')) {

    $id = $_POST['id'];
    $batch = $_POST['batch'];
    $data = $data->batchData($batch, $id, 'id');
    $jsonList = json_encode($_POST);
    $up = "UPDATE {$batch} SET checklist='$jsonList' WHERE id='" . $id . "' AND batch='" . $batch . "'";
    $stmt = $connPdo->prepare($up);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = "Site administration checklist updated successfully for " . $data['name'] . " (" . $batch . ").";
        $details_activity = "Site administration checklist updated successfully for " . $data['name'] . " (" . $batch . ") by " . $loggedin_name . ".";
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['title_edit']) && isset($_POST['batch_title_edit']) && isset($_POST['batch']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')) {

    $title_b = $_POST['title'];
    $batch = $_POST['batch'];
    $sql = "UPDATE batch SET title = '$title_b'  WHERE batch='" . $batch . "'";
    $stmt = $connPdo->prepare($sql);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = $batch . " batch title have been updated successfully.";
        $details_activity = $batch . ' batch title (' . $title_b . ') updated by ' . $loggedin_name . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['change_pass_only']) && ($loggedin['role'] == 'dev')) {
    $get_batch = $_POST['get_batch'];
    $get_name = $_POST['get_name'];
    $get_student_id = $_POST['get_student_id'];
    $pass = $_POST['Password'];
    $up = "UPDATE {$get_batch} SET Password='$pass' WHERE id='" . $_POST['id'] . "' AND batch='" . $get_batch . "'";
    $stmt = $connPdo->prepare($up);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = "Password of (" . $get_name . "-" . $get_student_id . ") changed successfully.";
        $details_activity = 'Password of ' . $get_name . '-' . $get_student_id . '-' . $get_batch . ' updated by ' . $loggedin_name . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['change_mail_id_only']) && ($loggedin['role'] == 'dev' || $loggedin['role'] == 'admin')) {
    $batch = $_POST['batch'];
    $student_id = $_POST['student_id'];
    $id = $_POST['id'];
    $email = $_POST['email'];
    $row = $data->batchData($batch, $id, "id");
    $nameEmail = empty($row['name']) ? $email : $row['name'];
    // $results = $SMTP_Validator->validate(array($email));

    if (preg_match('/^[0-9]{10}+$/', $student_id)) {
        if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
            // if ($results[$email]) {
            $up = "UPDATE {$batch} SET student_id = '" . $student_id . "', email='" . $email . "' WHERE id='" . $id . "' AND batch ='" . $batch . "'";
            $stmt = $connPdo->prepare($up);
            $stmt->execute();
            if ($stmt->rowCount()) {
                $msg['error'] = false;
                $msg['message'] = "Email and Student ID of (" . $nameEmail . "-" . $student_id . ") changed successfully.";
                $details_activity = 'Email and Student ID of ' . $nameEmail . '-' . $student_id . '-' . $batch . ' updated by ' . $loggedin['name'] . '.';
                $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
            } else {
                $msg['warning'] = true;
                $msg['message'] = "No Changes detect, Please try again later.";
            }
            // } else {
            //     $msg['error'] = true;
            //     $msg['message'] = "Email address not valid, please enter valid email address to continue.";
            // }
        } else {
            $msg['error'] = true;
            $msg['message'] = "Please enter valid email address to continue.";
        }
    } else {
        $msg['error'] = true;
        $msg['message'] = "Please enter valid 10 digit Student ID to continue.";
    }
} elseif (isset($_POST['noticeAddUpdate']) && ($loggedin['role'] == 'dev')) {
    $title = $_POST['title'];
    $active = $_POST['active'];
    $message = $_POST['message'];
    $image_url = $imageUrl = $_POST['image_url'];
    $date = date('d/m/Y h:ia');
    $batch = $loggedin['batch'];
    $student_id = $loggedin['student_id'];
    $name = $loggedin['name'];
    $dev = 'Controller';
    // $dev_name = $loggedin['name'];
    $action = isset($_POST['action']) ? $_POST['action'] : '';
    $actionDestination = isset($_POST['action_destination']) ? $_POST['action_destination'] : '';
    if ($actionDestination == '') {
        $action = '';
    }
    if (isset($_POST['add_notice_admin'])) {
        $in = "INSERT INTO notice (student_id, batch, name, title,image_url, message, active, date) VALUES ('$student_id', '$dev','$name','$title','$image_url', '$message', '$active', '$date')";
        $infoMsg = 'New admin notice (' . $title . ') added successfully.';
        $details_activity = 'New notice (' . $title . ') added by ' . $loggedin_name . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else if (isset($_POST['add_notice'])) {
        $in = "INSERT INTO notice (student_id, name, title,batch,image_url, message, active, date) VALUES ('$student_id','$name','$title','$batch','$image_url', '$message', '$active', '$date')";
        $infoMsg = 'New notice (' . $title . ') added successfully.';
        $details_activity = 'New notice (' . $title . ') added by ' . $loggedin_name . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } elseif (isset($_POST['update_notice'])) {
        $in = "UPDATE notice SET title='$title', message='$message', active='$active', date='$date' WHERE id='" . $_POST['id'] . "'";
        $infoMsg = 'Notice (' . $title . ') updated successfully.';
        $details_activity = 'Notice (' . $title . ') updated by ' . $loggedin_name . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    }
    $stmt = $connPdo->prepare($in);
    if ($stmt->execute()) {
        $notification->setTitle($title);
        $notification->setMessage($message);
        $notification->setImage($imageUrl);
        $notification->setAction($action);
        $notification->setActionDestination($actionDestination);
        $firebase_token = '';
        $firebase_api = 'AAAABntCPDk:APA91bFXk6SLMVL3fYCIVO1jaAk8dO8gtlneCKhDw5ADRMS3lQ_5ICdltw69xWvUHPknWUUw2q21PheKCrs2rQ7FTkbZENHKKdQrF7czBTcwOn2Q2ws1Cr8D1o0qSwFguvIEhTM0KkGd';
        // $firebase_api = '';
        $topic = 'global';
        $send_to = 'topic';
        $requestData = $notification->getNotificatin();
        if ($send_to == 'topic') {
            $fields = array(
                'to' => '/topics/' . $topic,
                'data' => $requestData,
            );
        } else {
            $fields = array(
                'to' => $firebase_token,
                'data' => $requestData,
            );
        }
        // Set POST variables
        $url = 'https://fcm.googleapis.com/fcm/send';
        $headers = array(
            'Authorization: key=' . $firebase_api,
            'Content-Type: application/json'
        );
        // Open connection
        $ch = curl_init();
        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        // Disabling SSL Certificate support temporarily
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));
        // Execute post
        $result = curl_exec($ch);
        if ($result === FALSE) {
            $msg['warning'] = true;
            $msg['message'] = "App notification failed to send, please try again later.";
            // die('Curl failed: ' . curl_error($ch));
        }
        // Close connection
        curl_close($ch);
        //echo '<h3>Request </h3><p><pre>';
        ///echo json_encode($fields,JSON_PRETTY_PRINT);
        //echo '</pre></p><h3>Response </h3><p><pre>';
        //echo $result;
        //echo '</pre></p>';
        $msg['error'] = false;
        $msg['message'] = $infoMsg;
        // if (isset($_GET['admin_notice_batch'])) {
        // 	echo "<script>window.location='home.php?notice_add_successfully&notice';</script>";
        // }
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['multipleDataImport']) && $loggedin['role'] == "dev") {

    if ($_FILES["import_excel"]["name"] != '' && $_POST['batch'] !== '') {
        $batch = $_POST['batch'];
        $allowed_extension = array('xls', 'csv', 'xlsx');
        $file_array = explode(".", $_FILES["import_excel"]["name"]);
        $file_extension = end($file_array);

        if (in_array($file_extension, $allowed_extension)) {
            $file_name = '../import/log/' . time() . '.' . $file_extension;
            move_uploaded_file($_FILES['import_excel']['tmp_name'], $file_name);
            $file_type = PHPExcel_IOFactory::identify($file_name);
            $reader = PHPExcel_IOFactory::createReader($file_type);

            $spreadsheet = $reader->load($file_name);

            unlink($file_name);

            $data = $spreadsheet->getActiveSheet()->toArray();
            try {
                foreach ($data as $row) {
                    $insert_data = array(
                        ':student_id' =>    $row[0],
                        ':name'        =>    $row[1],
                        ':name_bangla'        =>    $row[2],
                        ':birth'        =>    $row[3],
                        ':father_name'        =>    $row[4],
                        ':phone'        =>    $row[5],
                        ':email'        =>    $row[6],
                        ':blood'        =>    $row[7],
                        ':district'        =>    $row[8],
                        ':address'        =>    $row[9],
                        ':address_bangla'        =>    $row[10],
                        ':fb_id'        =>    $row[11],
                        ':batch'        =>    $row[12],
                        ':session'        =>    $row[13],
                        ':showing'        =>    $row[14],
                        ':active'        =>    $row[15]
                    );

                    $query = "
			INSERT INTO {$batch} (student_id,name,name_bangla,birth,father_name,phone,email,blood,district,address,address_bangla,fb_id,	batch,session,showing,active) VALUES (:student_id,:name,:name_bangla,:birth,:father_name,:phone,:email,:blood,:district,:address,:address_bangla,:fb_id,:batch,:session,:showing,:active)";

                    $statement = $connPdo->prepare($query);
                    $input = $statement->execute($insert_data);
                }

                $msg['error'] = false;
                $msg_true = 'Data imported to ' . $batch . ' batch successfully.';
                $msg['message'] = $msg_true;
                $details_activity = 'Multiple data import to (' . $batch . ') batch by ' . $loggedin['name'] . '.';
                $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
            } catch (PDOException $e) {
                if ($e->errorInfo[1] == 1062) {
                    $msg['error'] = true;
                    $msg['message'] = 'Opss! Entries are already in line.';
                } else {
                    $msg['error'] = true;
                    $msg['message'] = "Something went wrong, please try again properly.";
                }
            }
            // finally {
            //     $msg['error'] = false;
            //     $msg_true = 'Data imported to ' . $batch . ' batch successfully.';
            //     $msg['message'] = $msg_true;
            //     $details_activity = 'Multiple data import to (' . $batch . ') batch by ' . $loggedin['name'] . '.';
            //     $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
            // } 

        } else {
            $msg['warning'] = true;
            $msg['message'] = 'Only .xls .csv or .xlsx file allowed.';
        }
    } else {
        $msg['warning'] = true;
        $msg['message'] = "Please attach valid file.";
    }
} elseif (isset($_POST['dependedOptionBatchSession'])) {

    $batch = $_POST['batchValue'];
    $getBatch = $data->batchData("batch", $batch, "batch");
    $msg['data'] = $getBatch['session'];
} elseif (isset($_POST['reportInfoToAdmin'])) {

    $name = $loggedin['name'];
    $email = $loggedin['email'];
    $student_id = $loggedin['student_id'];
    $mobile = $loggedin['phone'];
    $batch = $loggedin['batch'];
    $message = $_POST['message'];
    $subject_msg = $_POST['subject'];
    $email_sel = $_POST['email_sel'];

    if (!empty($_POST['message'])) {
        if (!isset($_POST['g-recaptcha-response']) && empty($_POST['g-recaptcha-response'])) {
            $secretKey = '6LeO-7AZAAAAABlGE360hyjG_zLYJukNRChFN2vR';
            $verifyResponse = file_get_contents('https://www.google.com/recaptcha/api/siteverify?secret=' . $secretKey . '&response=' . $_POST['g-recaptcha-response']);
            $responseData = json_decode($verifyResponse);
            if (!$responseData->success) {

                $date = date("Y-m-d H:i:s");
                $uip = $_SERVER['REMOTE_ADDR'];
                //$ipaddress = '37.111.235.15';
                $useragent = $_SERVER['HTTP_USER_AGENT'];

                if ($detect->isMobile()) {
                    $device = 'Mobile';
                } else {
                    $device = 'Desktop';
                }

                $http = $_SERVER['HTTP_REFERER'];

                //Start Get IP Locaion of ipstack.com
                $access_key = '12c56483145c7dba04d707f6138bec50';
                $ch = curl_init('http://api.ipstack.com/' . $uip . '?access_key=' . $access_key . '');
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $json = curl_exec($ch);
                curl_close($ch);
                $api_result = json_decode($json, true);
                $continent = $api_result['continent_name'];
                $longitude = $api_result['longitude'];
                $latitude = $api_result['latitude'];
                $city = $api_result['city'];
                $capital = $api_result['location']['capital'];
                $calling_code = $api_result['location']['calling_code'];
                $country_flag = $api_result['location']['country_flag'];
                $region = $api_result['region_name'];
                $country = $api_result['country_name'];
                $country_code = $api_result['country_code'];
                // End Get IP Location ipstack.com

                $geo = json_decode(file_get_contents("http://extreme-ip-lookup.com/json/$uip"));
                $isp = $geo->isp;

                $output = "<h3><b>Message By:</b></h3>";
                $output .= "<p><b>Name: </b>" . $name . "; <b>Mobile: </b>" . $mobile . "; <b>Email: </b>" . $email . "; <b>Batch: </b>" . $batch . "</p>";
                $output .= "<p style='font-size:19px'><b>Subject: </b><br>" . $subject_msg . "</p>";
                $output .= "<p style='font-size:19px'><b>Message: </b><br>" . $message . "</p>";
                $output .= "<p style='text-align:right'><b>Date: </b>" . $date . "</p>";
                $output .= "<h3><b>Other Details: </b><br>---------------------</h3>";
                $output .= "<p><b>IP Address: </b>" . $uip . "; <b>Device: </b>" . $device . "; <b>Referer: </b>" . $http . "; <b>User Agent: </b>" . $useragent . "; <b>Region: </b> " . $region . ";  <b>City: </b> " . $city . ";  <b>Country: </b> " . $country . ";  <b>Continent: </b> " . $continent . ";  </p>";

                $subject = "AIS Family Database Report Issue";

                $stmt = $connPdo->prepare("INSERT INTO report_issue (subject, email_to, email_from, messages, device, http, capital, city, region, country, country_flag, calling_code, country_code, continent, latitude, longitude, isp, ip, student_id, batch, time, details, re_date) VALUES ('$subject_msg', '$email_sel', '$email', '$message', '$device', '$http', '$capital','$city','$region','$country','$country_flag','$calling_code','$country_code','$continent','$latitude','$longitude','$isp', '$uip', '$student_id', '$batch', '$date', '$useragent', '$date')");
                $msg['error'] = false;
                $msg_true = 'Your message has been submtted to your batch admin (' . $email_sel . ').';
                $msg['message'] = $msg_true;
                if ($stmt->execute()) {
                    $mail = $mailSend->sendMail($email_sel, $output, $subject);
                    if ($mail == 1) {
                        $msg['error'] = false;
                        $msg_true = 'Your message has been mailed to your batch admin (' . $email_sel . ') successfully.';
                        $msg['message'] = $msg_true;
                        $details_activity = 'New report issued to batch admin (' . $email_sel . ') by ' . $name . '';
                        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
                        // $msg ="Your message has been sent successfully to your batch admin.";
                    } else {
                        $msg['warning'] = true;
                        $msg_true = 'Email server not responses for your mail.';
                        $msg['message'] = $msg_true;
                    }
                } else {
                    $msg['error'] = true;
                    $msg_true = 'Something went wrong, please try again later.';
                    $msg['message'] = $msg_true;
                    // $error="Something went wrong, please try again later.";
                    //echo "<script> window.location.href = '';</script>";
                }
            } else {
                $msg['error'] = true;
                $msg_true = 'Robot verification failed, please try again.';
                $msg['message'] = $msg_true;
                // $error = "Robot verification failed, please try again.";
                // echo "<script> window.location.href = '';</script>";
            }
        } else {
            $msg['error'] = true;
            $msg_true = 'Please check on the reCAPTCHA box.';
            $msg['message'] = $msg_true;
            // $error = "Please check on the reCAPTCHA box."; 
            // echo "<script> window.location.href = '';</script>";
        }
    } else {
        $msg['error'] = true;
        $msg_true = 'Please fill all the mandatory fields.';
        $msg['message'] = $msg_true;
        // $error = "Please fill all the mandatory fields."; 
        // echo "<script> window.location.href = '';</script>";
    }
} elseif (isset($_POST['delete_mail_sys']) && ($loggedin['role'] == 'dev')) {

    $id = $_POST['id'];
    $email = $_POST['email'];
    $dperson = $loggedin['name'];

    $actd = " DELETE FROM sys_mail_setup  WHERE id = '" . $id . "'";

    $stmt = $connPdo->prepare($actd);

    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg_true = '"' . $email . '" deleted successfully.';
        $msg['message'] = $msg_true;
        $details_activity = 'Mail (' . $email . ') deleted by ' . $dperson . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['change_mail_status']) && ($loggedin['role'] == 'dev')) {
    $status_deact = 0;
    $status_act = 1;
    $id = $_POST['id'];
    $email = $_POST['email'];
    $dperson = $loggedin['name'];


    $act = "UPDATE sys_mail_setup SET status='$status_act' WHERE id='" . $id . "'";
    $actd = " UPDATE sys_mail_setup SET status='$status_deact' WHERE id <> '" . $id . "'";

    $stmt_a = $connPdo->prepare($actd);
    $stmt_a->execute();

    $stmt = $connPdo->prepare($act);

    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg_true = '"' . $email . '" activated successfully.';
        $msg['message'] = $msg_true;
        $details_activity = 'Mail (' . $email . ') activated by ' . $dperson . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['change_mail_value']) && ($loggedin['role'] == 'dev')) {

    $email = $_POST['email'];
    $password = $_POST['password'];
    $host = $_POST['host'];
    $smtp = $_POST['smtp'];
    $port = $_POST['port'];
    $status = 1;
    $date = date('Y-m-d H:i:s');
    $dperson = $loggedin['name'];


    if (isset($_POST['id']) && $_POST['id'] == "add") {
        $msg_true = '"' . $email . '" added successfully.';
        $details_activity = 'Mail details (' . $email . ') added by ' . $dperson . '.';
        $in = "INSERT INTO sys_mail_setup (email, password, status, host, port, smtp, date_added) VALUES ('" . $email . "','" . $password . "','" . $status . "','" . $host . "','" . $port . "','" . $smtp . "','" . $date . "')";
    } else {
        $msg_true = '"' . $email . '" updated successfully.';
        $details_activity = 'Mail details (' . $email . ') updated by ' . $dperson . '.';
        $in = "UPDATE sys_mail_setup SET email='$email', password='$password', host='$host', port='$port', smtp='$smtp', date_added='$date' WHERE id='" . $_POST['id'] . "'";
    }
    $stmt = $connPdo->prepare($in);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = $msg_true;
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['change_hall_value']) && ($loggedin['role'] == 'dev')) {
    $name_bn = $_POST['name_bn'];
    $name_en = $_POST['name_en'];
    $code = $_POST['code'];
    $ddate = date('Y-m-d H:i:s');
    $dperson = $loggedin['name'];

    if ($_POST['id'] == "add") {
        $msg_true = '"' . $name_bn . '" added successfully.';
        $details_activity = 'Hall details (' . $dvalue . ') added by ' . $dperson . '.';
        $in = "INSERT INTO hall (`name_bn`, `name_en`,`code`,`update_by`,`modified`) VALUES ('" . $name_bn . "', '" . $name_en . "', '" . $code . "', '" . $dperson . "', '" . $ddate . "');";
    } else {
        $msg_true = '"' . $name_bn . '" spelling updated successfully.';
        $details_activity = 'Hall details (' . $dvalue . ') updated by ' . $dperson . '.';
        $in = "UPDATE hall SET name_bn='$name_bn', name_en='$name_en', code='$code', modified='$ddate', update_by='$dperson' WHERE id='" . $_POST['id'] . "'";
    }
    $stmt = $connPdo->prepare($in);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = $msg_true;
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['add_batch_notice']) && isset($_POST['batch']) && isset($_SESSION['student_id'])) {

    $title = $_POST['title'];
    $active = $_POST['active'];
    $message = $_POST['message'];
    $date = date('d/m/Y h:ia');
    $batch = $loggedin['batch'];
    $student_id = $loggedin['student_id'];
    $name = $loggedin['name'];
    $dev = 'Developer';
    $dev_name = $loggedin['name'];
    $in = "INSERT INTO notice (student_id, batch, name, title, message, active, date) VALUES ('$student_id', '$batch','$name','$title', '$message', '$active', '$date')";
    $stmt = $connPdo->prepare($in);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = $title . ' notice added successfully.';
        $details_activity = $title . ' - notice added by ' . $loggedin_name . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['teachers_delete']) && isset($_POST['id']) && ($loggedin['role'] == 'dev' || $loggedin['role'] == 'admin')) {
    $id = $_POST['id'];
    $tecdata = $data->batchData("teacher", $id, "id");
    $del = "DELETE FROM teacher WHERE id='" . $id . "'";
    $stmt = $connPdo->prepare($del);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = $tecdata['name'] . ' (' . $tecdata['designation'] . ') deleted successfully.';
        $details_activity = "Teacher " . $tecdata['name'] . " (" . $tecdata['designation'] . ") deleted by " . $loggedin_name . ".";
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['statementDelete']) && isset($_POST['id']) && ($loggedin['role'] == 'dev' || $loggedin['role'] == 'admin')) {
    $id = $_POST['id'];
    $data = $data->batchData("statement", $id, "id");
    $delete = '../files/' . $data['file'];
    $del = "DELETE FROM statement WHERE id='" . $id . "'";
    $stmt = $connPdo->prepare($del);
    $stmt->execute();
    if ($stmt->rowCount()) {
        unlink($delete);
        $msg['error'] = false;
        $msg['message'] = 'Statement for '.ucfirst($data['type']) . ' (' . $data['month_trnx'] . ') deleted successfully.';
        $details_activity = "Statement for " . ucfirst($data['type']) . " (" . $data['month_trnx'] . ") deleted by " . $loggedin_name . ".";
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['addStatementInfo']) && ($loggedin['role'] == 'dev' || $loggedin['role'] == 'admin')) {

    $narration = empty($_POST['narration']) ? 0 : $_POST['narration'];
    $type_d = empty($_POST['type']) ? 0 : $_POST['type'];
    $category = empty($_POST['category']) ? 0 : $_POST['category'];
    $amount = empty($_POST['amount']) ? 0 : $_POST['amount'];
    $status = 1;
    $date = $_POST['date'];
    $date_added = date('Y-m-d H:i:s');
    $month_d = date('F', strtotime($date));

    $files = $_FILES["file"]["name"];
    $files = preg_replace('/\\.[^.\\s]{3,4}$/', '', $files);
    $type  = $_FILES["file"]["type"];
    $size  = $_FILES["file"]["size"];
    $temp  = $_FILES["file"]["tmp_name"];
    $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
    $file_name = md5(time()) . "." . $ext;
    $path = "../files/" . $file_name;

    if($narration !== 0 && $type_d !== 0 && $category !== 0 && $month_d !== 0 && $amount !== 0){
        $sql = "INSERT INTO statement (narration, type, category, month_trnx, amount, date_trnx, file, status, date_added, added_by) VALUES (:narration, :type_d, :category, :month_d, :amount, :date_d, :file_name_d, :status_d, :date_added, :added_by);";
        $stmt = $connPdo->prepare($sql);
        $stmt->execute(
            array(
                "narration" => $narration,
                "type_d" => $type_d,
                "category" => $category,
                "month_d" => $month_d,
                "amount" => $amount,
                "date_d" => $date,
                "file_name_d" => $file_name,
                "status_d" => $status,
                "date_added" => $date_added,
                "added_by" => $loggedin['name']
            )
        );
        if ($stmt->rowCount()) {
            move_uploaded_file($temp, $path);
            $msg['error'] = false;
            $msg['message'] = 'Add new statement info for the category of ' .ucwords(str_replace("-", " ",$type_d)) . '-'.strtoupper($category).' (' . $month_d . ').';
            $details_activity = 'New statement info for the category of ' .ucwords(str_replace("-", " ",$type_d)) . '-'.strtoupper($category).' (' . $month_d . ') added by ' . $loggedin_name . '.';
            $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
        } else {
            $msg['error'] = true;
            $msg['message'] = "Something went wrong, Please try again later.";
        }
    } else {
        $msg['error'] = true;
        $msg['message'] = "Please fillup all required information and try again.";
    }


} elseif (isset($_POST['only_add_files_info']) && ($loggedin['role'] == 'dev' || $loggedin['role'] == 'admin')) {

    $upload_type = $_POST['type'];
    $student_id = $loggedin['student_id'];
    $name = $loggedin['name'];
    $batch = $loggedin['batch'];
    $encode_title = $_POST['title'];
    $title = str_replace(' ', '-', $encode_title);
    $course = $_POST['course_code'];
    $course = explode('**', $course);
    $course_name = $course[1];
    $course_code = $course[0];
    $date = date("Y-m-d H:i:s");
    $cat = $_POST['cat'];
    $recommanded_year = str_replace(' ', '-', $_POST['recommanded_year']);
    $hide = 0;
    $pinned = 0;
    $approve = 1;

    $files = $_FILES["file"]["name"];
    $files = preg_replace('/\\.[^.\\s]{3,4}$/', '', $files);
    $type  = $_FILES["file"]["type"];
    $size  = $_FILES["file"]["size"];
    $temp  = $_FILES["file"]["tmp_name"];
    $ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
    $file_name = md5(time()) . "." . $ext;
    $path = "../files/" . $file_name;

    $refer_link =  $_POST['refer_link'];
    $link = (!empty($refer_link) ? 1 : 0);

    $allowed_ext = array("PDF", "pdf", "DOC", "doc", "docx", "PPT", "pptx", "jpg", "png", "jpeg");

    if ($upload_type == 'file_link') {
        if (preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i", $refer_link)) {
            $valid = 1;
        } else {
            $valid = 3;
        }
    } elseif ($upload_type == 'file') {
        if (($size > 0) && ($size < 5242880) && (in_array($ext, $allowed_ext))){
            $valid = 1;
        } else {
            $valid = 2;
        }
    } 
    if ($valid == 1) {
        if ($valid == 1 && $upload_type == 'file') {
            move_uploaded_file($temp, $path);
        }
        $sql = "INSERT INTO learning (course_code, course_name, student_id, name,batch, title, refer_link, file_name,  date, recommanded_year, cat, hide, pinned, link, ext, approve) VALUES ('$course_code','$course_name','$student_id','$name','$batch','$title','$refer_link','$file_name','$date','$recommanded_year','$cat','$hide','$pinned' ,'$link','$ext','$approve')";
        $stmt = $connPdo->prepare($sql);
        $stmt->execute();
        if ($stmt->rowCount()) {
            $msg['error'] = false;
            $msg['message'] = "Your ".(!empty($refer_link) ? "file link" : "file")." (".$encode_title.") uploaded to database successfully.";
            $details_activity = "New File " . str_replace("-", " ", $encode_title) . " (" . $course_name . ") added by " . $loggedin_name . ".";
            $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
        } else {
            $msg['error'] = true;
            $msg['message'] = "Something went wrong, Please try again later.";
        }
    } elseif ($valid == 2) {
        $msg['error'] = true;
        $msg['message'] =  "Please choose only PDF, DOC, PPT, PNG, JPG format & maximum 5MB files.";
    } elseif ($valid == 3) {
        $msg['error'] = true;
        $msg['message'] =  "Please insert valid file link to upload.";
    }else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }

} elseif (isset($_POST['update_add_files_info']) && ($loggedin['role'] == 'dev' || $loggedin['role'] == 'admin') || isset($_SESSION['student_id']) && $_POST['batch'] == $loggedin['batch'] && $_POST['student_id'] == $loggedin['student_id']) {

    $id = $_POST['id'];
    $filedata = $data->batchData("learning", $id, "id");

    $encode_title = $_POST['title'];
    $title = str_replace(' ', '-', $encode_title);
    $refer_link = $_POST['refer_link'];
    $course = $_POST['course_code'];
    $course = explode('**', $course);
    $course_name = $course[1];
    $course_code = $course[0];
    $date = date("Y-m-d H:i:s");
    $cat = $_POST['cat'];
    $recommanded_year = str_replace(' ', '-', $_POST['recommanded_year']);
    $hide = $_POST['hide'];
    $pinned = $_POST['pinned'];
    $approve = $_POST['approve'];
    $sql = "UPDATE learning SET title='$title',  course_name='$course_name',  course_code='$course_code', refer_link='$refer_link', hide='$hide', pinned='$pinned', cat='$cat', recommanded_year='$recommanded_year', approve='$approve' WHERE id='" . $id . "'";
    $stmt = $connPdo->prepare($sql);
    $stmt->execute();
    if ($stmt->rowCount()) {
        $msg['error'] = false;
        $msg['message'] = str_replace("-", " ", $filedata['title']) . ' (' . $filedata['course_name'] . ') updated successfully.';
        $details_activity = "File " . str_replace("-", " ", $filedata['title']) . " (" . $filedata['course_name'] . ") updated by " . $loggedin_name . ".";
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['files_delete']) && isset($_POST['id']) && $_POST['batch'] == $loggedin['batch']  && ($loggedin['role'] == 'dev' || $loggedin['role'] == 'admin')) {
    $id = $_POST['id'];
    $filedata = $data->batchData("learning", $id, "id");
    $delete = '../files/' . $filedata['file_name'];

    $del = "DELETE FROM learning WHERE id='" . $id . "'";
    $stmt = $connPdo->prepare($del);
    $stmt->execute();
    if ($stmt->rowCount()) {
        unlink($delete);
        $msg['error'] = false;
        $msg['message'] = str_replace("-", " ", $filedata['title']) . ' (' . $filedata['course_name'] . ') deleted successfully.';
        $details_activity = "File " . str_replace("-", " ", $filedata['title']) . " (" . $filedata['course_name'] . ") deleted by " . $loggedin_name . ".";
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['admin_generate_link_add_info']) && ($loggedin['role'] == 'dev' || $loggedin['role'] == 'admin')) {

    $email = $_POST['email'];
    $batch = $_POST['batch'];
    $student_id = $_POST['student_id'];
    $expFormat = mktime(date("H"), date("i"), date("s"), date("m"), date("d") + 1, date("Y"));
    $expDate = date("Y-m-d H:i:s", $expFormat);
    $key = md5($email);
    $addKey = substr(md5(uniqid(rand(), 1)), 3, 10);
    $key = $key . $addKey;
    $generateSql = "INSERT INTO `add_info_key` (`batch`, `student_id`, `email`, `key`, `expDate`) VALUES ('" . $batch . "', '" . $student_id . "','" . $email . "', '" . $key . "', '" . $expDate . "');";
    $stmt = $connPdo->prepare($generateSql);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = 'Update info link generated successfully for ' . $email . ' (' . $student_id . ').';
        $details_activity = 'New update info link for <b>(' . $email . '-' . $student_id . '-' . $batch . ')</b>  generated by ' . $loggedin_name . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
        // generate link
        $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
        $Addlink = $actual_link . '/addinfo.php?add_info_users&key=' . $key . '&action=add';
        $_SESSION['successfully_generated'] = $Addlink;
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['office_stuff_delete']) && isset($_POST['id']) && ($loggedin['role'] == 'dev' || $loggedin['role'] == 'admin')) {
    $id = $_POST['id'];
    $tecdata = $data->batchData("office_stuff", $id, "id");
    $del = "DELETE FROM office_stuff WHERE id='" . $id . "'";
    $stmt = $connPdo->prepare($del);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = $tecdata['name'] . ' (' . $tecdata['designation'] . ') deleted successfully.';
        $details_activity = "Office Staff " . $tecdata['name'] . " (" . $tecdata['designation'] . ") deleted by " . $loggedin_name . ".";
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['update_notice']) && isset($_POST['batch']) && isset($_POST['id']) && isset($_SESSION['student_id'])) {

    $id = $_POST['id'];
    $batch = $_POST['batch'];
    $title = $_POST['title'];
    $active = $_POST['active'];
    $message = $_POST['message'];
    $date = date("Y-m-d H:i:s");
    $in = "UPDATE notice SET title='$title', message='$message', active='$active', date='$date' WHERE id='" . $id . "' AND batch='" . $batch . "'";
    $stmt = $connPdo->prepare($in);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = $title . ' updated successfully.';
        $details_activity = $title . ' - notice updated by ' . $loggedin_name . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['change_district_value']) && ($loggedin['role'] == 'dev')) {
    $dvalue = $_POST['district'];
    $dvalue_bn = $_POST['district_bn'];
    $division = $_POST['division'];
    $ddate = date('Y-m-d H:i:s');
    $dperson = $loggedin['name'];
    $up = "UPDATE district SET division='$division', name_bn='$dvalue_bn', name='$dvalue', date_upated='$ddate', person_update='$dperson' WHERE id='" . $_POST['id'] . "'";
    $stmt = $connPdo->prepare($up);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = '"' . $dvalue . '" spelling updated successfully.';
        $details_activity = 'District (' . $dvalue . ') updated by ' . $dperson . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['notice_delete']) && isset($_POST['id']) && isset($_POST['batch']) && isset($_SESSION['student_id'])) {

    $batch = $_POST['batch'];
    $id = $_POST['id'];
    $noticeRow = $data->batchData("notice", $id, "id");
    $del = "DELETE FROM notice WHERE id='" . $id . "' AND batch='" . $batch . "'";
    $stmt = $connPdo->prepare($del);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = $noticeRow['title'] . ' (' . $batch . ') notice deleted successfully.';
        $details_activity = 'Notice (' . $noticeRow['title'] . ') deleted by ' . $loggedin_name . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['userLoggedSecureInfo']) && isset($_SESSION['student_id']) && $loggedin['frnds'] == '1' && ($loggedin['batch'] == '19th') && ($loggedin['role'] == 'dev')) {
    $prefer = $_POST['prefer'];
    $father_phone = $_POST['father_phone'];
    $details = $_POST['details'];
    $curDate = date("Y-m-d H:i:s");

    $student_id = $_POST['student_id'];
    $dataInfo = $data->batchData("19th", $student_id, "student_id");
    $update = "UPDATE iconic19 SET prefer='$prefer', father_phone='$father_phone', details='$details',  LastUpdateTime='$curDate'  WHERE student_id='" . $student_id . "'";
    $stmt = $connPdo->prepare($update);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = 'Personal Details Info of ' . $dataInfo['name'] . ' updated successfully.';
        $details_activity = 'Personal Info of ' . $dataInfo['name'] . ' updated by ' . $loggedin['name'] . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['newStaffInfoAdd']) && isset($_SESSION['student_id']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')) {

    $image_file = $_FILES["image"]["name"];
    $image_file = preg_replace('/\\.[^.\\s]{3,4}$/', '', $image_file);
    $type  = $_FILES["image"]["type"];
    $size  = $_FILES["image"]["size"];
    $temp  = $_FILES["image"]["tmp_name"];
    $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
    $imagename = md5(time()) . "." . $ext;
    $id = rand(10000, 100000);
    $name = $_POST['name'];
    $added_by = $loggedin['name'];
    $per_addr = $_POST['per_addr'];
    $fb_id = $_POST['fb_id'];
    $designation = $_POST['designation'];
    $phone = $_POST['phone'];
    $email = str_replace(' ', '', $_POST['email']);
    $added_time = date("Y-m-d H:i:s");
    $path = "../image/" . $imagename;

    $allowed_ext = array("png", "jpg", "JPEG", "PNG", "JPG", "jpeg");

    if (($size > 0) && ($size < 307500)) {
        if (in_array($ext, $allowed_ext)) {
            if (preg_match("/^[a-zA-Z-' ]*$/", $name)) {
                if (preg_match('/^[0-9]{11}+$/', $phone)) {
                    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        if (preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i", $fb_id)) {
                            if (!file_exists($path)) {
                                move_uploaded_file($temp, "../image/" . $imagename);
                                $insert = "INSERT INTO office_stuff (id, photo, per_addr, name, fb_id, designation, phone, email, added_time, added_by) VALUES ('$id','$imagename','$per_addr','$name','$fb_id','$designation','$phone','$email','$added_time','$added_by')";
                                $stmt = $connPdo->prepare($insert);
                                if ($stmt->execute()) {
                                    $msg['error'] = false;
                                    $msg['message'] = $name . ' staff profile added successfully.';
                                    $details_activity = 'New staff (' . $name . ') added by ' . $added_by . '.';
                                    $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
                                } else {
                                    $msg['error'] = true;
                                    $msg['message'] = "Something went wrong, Please try again later.";
                                }
                            } else {
                                $msg['error'] = true;
                                $msg['message'] = "Image already exists, please try another one.";
                            }
                        } else {
                            $msg['warning'] = true;
                            $msg['message'] = "Please input your valid facebook profile link.";
                        }
                    } else {
                        $msg['warning'] = true;
                        $msg['message'] = "Please input your valid email address.";
                    }
                } else {
                    $msg['warning'] = true;
                    $msg['message'] = "Please input your valid 11 digit mobile number.";
                }
            } else {
                $msg['warning'] = true;
                $msg['message'] = "Please input your valid full name.";
            }
        } else {
            $msg['error'] = true;
            $msg['message'] = "Please choose only JPG, JPEG, PNG format images.";
        }
    } else {
        $msg['error'] = true;
        $msg['message'] = "Please choose image file maximum 300 KB.";
    }
} elseif (isset($_POST['newTeacherInfoAdd']) && isset($_SESSION['student_id']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')) {

    $image_file = $_FILES["image"]["name"];
    $image_file = preg_replace('/\\.[^.\\s]{3,4}$/', '', $image_file);
    $type  = $_FILES["image"]["type"];
    $size  = $_FILES["image"]["size"];
    $temp  = $_FILES["image"]["tmp_name"];
    $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
    $imagename = md5(time()) . "." . $ext;
    $id = rand(10000, 100000);
    $name = $_POST['name'];
    $added_by = $loggedin['name'];
    $per_addr = $_POST['per_addr'];
    $fb_id = $_POST['fb_id'];
    $edu = $_POST['edu'];
    $designation = $_POST['designation'];
    $phone = $_POST['phone'];
    $email = str_replace(' ', '', $_POST['email']);
    $password = $phone;
    $added_time = date("Y-m-d H:i:s");
    $path = "../image/" . $imagename;

    $allowed_ext = array("png", "jpg", "JPEG", "PNG", "JPG", "jpeg");

    if (($size > 0) && ($size < 307500)) {
        if (in_array($ext, $allowed_ext)) {
            if (preg_match("/^[a-zA-Z-' ]*$/", $name)) {
                if (preg_match('/^[0-9]{11}+$/', $phone)) {
                    if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                        if (preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i", $fb_id)) {
                            if (!file_exists($path)) {
                                move_uploaded_file($temp, "../image/" . $imagename);
                                $insert = "INSERT INTO teacher (id, photo,per_addr, name, fb_id, edu, designation, phone, email, Password,added_time,added_by) VALUES ('$id','$imagename','$per_addr','$name','$fb_id','$edu','$designation','$phone','$email','$password','$added_time','$added_by')";
                                $stmt = $connPdo->prepare($insert);
                                if ($stmt->execute()) {
                                    $msg['error'] = false;
                                    $msg['message'] = $name . ' teacher profile added successfully.';
                                    $details_activity = 'New teacher (' . $name . ') added by ' . $added_by . '.';
                                    $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
                                } else {
                                    $msg['error'] = true;
                                    $msg['message'] = "Something went wrong, Please try again later.";
                                }
                            } else {
                                $msg['error'] = true;
                                $msg['message'] = "Image already exists, please try another one.";
                            }
                        } else {
                            $msg['warning'] = true;
                            $msg['message'] = "Please input your valid facebook profile link.";
                        }
                    } else {
                        $msg['warning'] = true;
                        $msg['message'] = "Please input your valid email address.";
                    }
                } else {
                    $msg['warning'] = true;
                    $msg['message'] = "Please input your valid 11 digit mobile number.";
                }
            } else {
                $msg['warning'] = true;
                $msg['message'] = "Please input your valid full name.";
            }
        } else {
            $msg['error'] = true;
            $msg['message'] = "Please choose only JPG, JPEG, PNG format images.";
        }
    } else {
        $msg['error'] = true;
        $msg['message'] = "Please choose image file maximum 300 KB.";
    }
} elseif (isset($_POST['newStaffInfoUpdate']) && isset($_SESSION['student_id']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')) {
    $name = $_POST['name'];
    $update_by = $loggedin['name'];
    $per_addr = $_POST['per_addr'];
    $fb_id = $_POST['fb_id'];
    $designation = $_POST['designation'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $id = $_POST['id'];
    $LastUpdateTime = date("Y-m-d H:i:s");
    $update = "UPDATE office_stuff SET name='$name', per_addr='$per_addr', fb_id='$fb_id', designation='$designation',phone='$phone',email='$email' ,LastUpdateTime='$LastUpdateTime' ,update_by='$update_by' WHERE id=" . $id;
    $stmt = $connPdo->prepare($update);
    $stmt->execute();
    if ($stmt->rowCount()) {
        $msg['error'] = false;
        $msg['message'] = "Profile Information of Staff " . $name . " updated successfully.";
        $details_activity = 'Office Stuff <b>(' . $name . '-' . $designation . ')</b> updated by ' . $loggedin_name . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['myBatchInfoUpdate']) && isset($_SESSION['student_id']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')) {
    $active = $_POST['active'];
    $showing = $_POST['showing'];
    $role = $_POST['role'];
    $student_id = $_POST['student_id'];
    $name = $_POST['name'];
    $name_bangla = $_POST['name_bangla'];
    $fb_id = $_POST['fb_id'];
    $blood = $_POST['blood'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $district = $_POST['district'];
    $address_bangla = $_POST['address_bangla'];
    $address = $_POST['address'];
    $birth = $_POST['birth'];
    $birth = $_POST['birth'];
    $id = $_POST['id'];
    $batch = $_POST['batch'];
    $father_name = $_POST['father_name'];
    $curDate = date("Y-m-d H:i:s");

    $role = $_POST['role'] == 'None' ? "" : $_POST['role'];

    $update = "UPDATE {$batch} SET showing='$showing', active='$active', role='$role', student_id='$student_id', name='$name',name_bangla='$name_bangla' ,fb_id='$fb_id',blood='$blood',email='$email',phone='$phone',district='$district',address_bangla='$address_bangla', address='$address', birth='$birth', father_name='$father_name', LastUpdateTime='$curDate' WHERE id=" . $id;
    $stmt = $connPdo->prepare($update);
    $stmt->execute();
    if ($stmt->rowCount()) {
        $msg['error'] = false;
        $msg['message'] = "Profile Information of " . $name . " updated successfully.";
        $details_activity = 'Profile Info <b>(' . $name . '-' . $batch . ')</b> updated by ' . $loggedin_name . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['newTeacherInfoUpdate']) && isset($_SESSION['student_id']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')) {
    $name = $_POST['name'];
    $update_by = $loggedin['name'];
    $per_addr = $_POST['per_addr'];
    $fb_id = $_POST['fb_id'];
    $edu = $_POST['edu'];
    $designation = $_POST['designation'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $id = $_POST['id'];
    $LastUpdateTime = date("Y-m-d H:i:s");
    $update = "UPDATE teacher SET name='$name', per_addr='$per_addr', fb_id='$fb_id',edu='$edu' ,designation='$designation',phone='$phone',email='$email' ,LastUpdateTime='$LastUpdateTime' ,update_by='$update_by' WHERE id=" . $id;
    $stmt = $connPdo->prepare($update);
    $stmt->execute();
    if ($stmt->rowCount()) {
        $msg['error'] = false;
        $msg['message'] = "Profile Information of Teacher " . $name . " updated successfully.";
        $details_activity = 'Teacher Info <b>(' . $name . '-' . $designation . ')</b> updated by ' . $loggedin_name . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_SESSION['student_id']) && isset($_POST['changePhoto'])) {
    $image_file = $_FILES["image"]["name"];
    $image_file = preg_replace('/\\.[^.\\s]{3,4}$/', '', $image_file);
    $type  = $_FILES["image"]["type"];
    $size  = $_FILES["image"]["size"];
    $temp  = $_FILES["image"]["tmp_name"];
    $ext = pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION);
    $imagename = md5(time()) . "." . $ext;
    $curDate = date("Y-m-d H:i:s");
    $path = "../image/" . $imagename;
    $allowed_ext = array("png", "jpg", "JPEG", "PNG", "JPG", "jpeg");

    $id = empty($_POST['id']) ? $loggedin['id'] : $_POST['id'];
    $batch = empty($_POST['batch']) ? $loggedin['batch'] : $_POST['batch'];

    if (($size > 0) && ($size < 307500)) {
        if (in_array($ext, $allowed_ext)) {
            if (!file_exists($path)) {
                if (isset($_POST['changePhoto']) && $_POST['changePhoto'] == 'myBatchPhoto') {
                    $getRowStd = $data->batchData($batch, $id, "id");
                    $update = "UPDATE {$batch} SET photo ='$imagename', LastUpdateTime='$curDate'  WHERE id=" . $id;
                    $delete = '../image/' . $getRowStd['photo'];
                    $msg_true = 'Profile photo of ' . $getRowStd['name'] . ' changed successfully.';
                    $details_activity = 'Profile photo of <b>(' . $getRowStd['name'] . '-' . $getRowStd['student_id'] . '-' . $batch . ')</b> updated by ' . $loggedin_name . '.';
                } elseif (isset($_POST['changePhoto']) && $_POST['changePhoto'] == 'teacherPhoto') {
                    $getRowTeacher = $data->batchData("teacher", $id, "id");
                    $update = "UPDATE teacher SET photo ='$imagename', LastUpdateTime='$curDate'  WHERE id=" . $id;
                    $details_activity = 'Teacher photo updated by ' . $loggedin_name . '.';
                    $delete = '../image/' . $getRowTeacher['photo'];
                    $msg_true = 'Profile photo of Teacher ' . $getRowTeacher['name'] . ' changed successfully.';
                } elseif (isset($_POST['changePhoto']) && $_POST['changePhoto'] == 'myOwnPhoto') {
                    $getRowStd = $data->batchData($batch, $id, "id");
                    $update = "UPDATE {$batch} SET photo ='$imagename', LastUpdateTime='$curDate' WHERE id=" . $loggedin['id'];
                    $msg_true = 'My Profile photo changed successfully.';
                    $delete = '../image/' . $loggedin['photo'];
                    $details_activity = '' . $loggedin_name . ' changed his/her own profile photo.';
                } elseif (isset($_POST['changePhoto']) && $_POST['changePhoto'] == 'staffPhoto') {
                    $getRowStaff = $data->batchData("office_stuff", $id, "id");
                    $update = "UPDATE office_stuff SET photo ='$imagename', LastUpdateTime='$curDate'  WHERE id=" . $id;
                    $msg_true = 'Profile photo of Staff ' . $getRowStaff['name'] . ' changed successfully.';
                    $details_activity = 'Office stuff photo updated by ' . $loggedin_name . '.';
                    $delete = '../image/' . $getRowStaff['photo'];
                }
                $stmt = $connPdo->prepare($update);
                $stmt->execute();
                if ($stmt->rowCount()) {
                    unlink($delete);
                    move_uploaded_file($temp, $path);
                    $msg['error'] = false;
                    $msg['message'] = $msg_true;
                    $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
                } else {
                    $msg['error'] = true;
                    $msg['message'] = "Something went wrong, Please try again later.";
                }
            } else {
                $msg['error'] = true;
                $msg['message'] = "Image already exists, please try another one.";
            }
        } else {
            $msg['error'] = true;
            $msg['message'] = "Please choose only JPG, JPEG, PNG format images.";
        }
    } else {
        $msg['error'] = true;
        $msg['message'] = "Please choose image file maximum 300 KB.";
    }
} elseif (isset($_POST['userLoggedPassUpdate']) && isset($_SESSION['student_id'])) {
    $pass = $_POST['pass'];
    $newpass = $_POST['newpass'];
    $confirmpass = $_POST['confirmpass'];
    $curDate = date("Y-m-d H:i:s");
    if ($pass == $loggedin['Password']) {
        if ($newpass == $confirmpass) {
            $update = "UPDATE {$batch} SET Password='$newpass', LastUpdateTime='$curDate' WHERE id=" . $loggedin['id'];
            $stmt = $connPdo->prepare($update);
            if ($stmt->execute()) {
                $msg['error'] = false;
                $msg['message'] = 'My Login password changed successfully.';
                $details_activity = '' . $loggedin_name . ' changed his/her own login password.';
                $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
            } else {
                $msg['error'] = true;
                $msg['message'] = "Something went wrong, Please try again later.";
            }
        } else {
            $msg['error'] = true;
            $msg['message'] = "Confirm password not matched, please try again.";
        }
    } else {
        $msg['error'] = true;
        $msg['message'] = "Current password is invalid, please try again.";
    }
} elseif (isset($_POST['userLogout']) && isset($_SESSION['student_id'])) {

    $action = "Logout";
    $uip = $others->get_client_ip();
    $in = $others->insertLoginInfo($action, $detect, $uip);
    if ($in) {
        session_destroy();
        unset($_SESSION['batch']);
        unset($_SESSION['student_id']);
        unset($_COOKIE['SECURE_LOG']);
        setcookie("SECURE_LOG", "", time() - 3600, "/");
        $msg['error'] = false;
        $msg['message'] = 'You have logged out successfully.';
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, please try again later.";
    }
} elseif (isset($_POST['userLoggedInfoUpdate']) && isset($_SESSION['student_id'])) {

    $student_id = $_POST['student_id'];
    $show = $loggedin['showing'];
    $name = $_POST['name'];
    $name_bangla = $_POST['name_bangla'];
    $fb_id = $_POST['fb_id'];
    $blood = $_POST['blood'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $district = $_POST['district'];
    $address_bangla = $_POST['address_bangla'];
    $address = $_POST['address'];
    $birth = $_POST['birth'];
    $father_name = $_POST['father_name'];
    $curDate = date("Y-m-d H:i:s");
    if (preg_match("/^[a-zA-Z-' ]*$/", $name)) {
        if (preg_match('/^[0-9]{11}+$/', $phone)) {
            if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                if (preg_match("/\b(?:(?:https?|ftp):\/\/|www\.)[-a-z0-9+&@#\/%?=~_|!:,.;]*[-a-z0-9+&@#\/%=~_|]/i", $fb_id)) {
                    $update = "UPDATE {$batch} SET student_id='$student_id', name='$name', name_bangla='$name_bangla' , fb_id='$fb_id', blood='$blood', email='$email', phone='$phone', district='$district', address_bangla='$address_bangla',address='$address', birth='$birth', father_name='$father_name', LastUpdateTime='$curDate', showing='$show'  WHERE id=" . $loggedin['id'];
                    $stmt = $connPdo->prepare($update);
                    if ($stmt->execute()) {
                        $msg['error'] = false;
                        $msg['message'] = 'My Profile Info updated successfully.';
                        $details_activity = '' . $loggedin_name . ' updated his/her own profile information.';
                        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
                    } else {
                        $msg['error'] = true;
                        $msg['message'] = "Something went wrong, Please try again later.";
                    }
                } else {
                    $msg['warning'] = true;
                    $msg['message'] = "Please input your valid facebook profile link.";
                }
            } else {
                $msg['warning'] = true;
                $msg['message'] = "Please input your valid email address.";
            }
        } else {
            $msg['warning'] = true;
            $msg['message'] = "Please input your valid 11 digit mobile number.";
        }
    } else {
        $msg['warning'] = true;
        $msg['message'] = "Please input your valid full name.";
    }
} elseif (isset($_POST['faqs_delete']) && isset($_POST['id']) && isset($_SESSION['student_id'])) {

    $id = $_POST['id'];
    $noticeRow = $data->batchData("faq", $id, "id");
    $del = "DELETE FROM faq WHERE id='" . $id . "'";
    $stmt = $connPdo->prepare($del);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = $noticeRow['title'] . ' FAQ deleted successfully.';
        $details_activity = 'FAQ (' . $noticeRow['title'] . ') deleted by ' . $loggedin_name . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['mega_link_delete']) && isset($_POST['id']) && isset($_SESSION['student_id'])) {

    $id = $_POST['id'];
    $noticeRow = $data->batchData("mega_menu", $id, "id");
    $del = "DELETE FROM mega_menu WHERE id='" . $id . "'";
    $stmt = $connPdo->prepare($del);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = $noticeRow['title'] . ' link deleted successfully.';
        $details_activity = 'Link (' . $noticeRow['title'] . ') deleted by ' . $loggedin_name . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['change_course_value']) && ($loggedin['role'] == 'dev')) {
    $semester = $_POST['semester'];
    $year = $_POST['year'];
    $course_code = $_POST['course_code'];
    $course_name = $_POST['course_name'];
    $ddate = date('Y-m-d H:i:s');
    $dperson = $loggedin['name'];
    $up = "UPDATE course_list SET date_upated='$ddate', update_by='$dperson',course_code='$course_code', course_name='$course_name', year='$year', semester='$semester' WHERE id='" . $_POST['id'] . "'";
    $stmt = $connPdo->prepare($up);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = 'Successfully updated ' . $course_name . '.';
        $details_activity = 'Course (' . $course_name . ') updated by ' . $dperson . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['id']) && isset($_POST['del_batch_info']) && isset($_POST['batch']) && isset($_SESSION['student_id']) && ($loggedin['role'] == 'dev') && ($_POST['action'] == 'delete') || isset($_POST['id']) && isset($_POST['del_batch_info']) && isset($_POST['batch']) && ($loggedin['batch'] == $_POST['batch']) && isset($_SESSION['student_id']) && ($loggedin['role'] == 'admin') && ($_POST['action'] == 'delete')) {
    $batch = $_POST['batch'];
    $id = $_POST['id'];
    $dataInfo = $data->batchData($batch, $id, "id");

    $delete = "DELETE FROM {$batch} WHERE id = '" . $id . "' AND batch = '" . $batch . "'";
    $stmt = $connPdo->prepare($delete);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = $dataInfo['name'] . ' (' . $dataInfo['student_id'] . ') deleted successfully from ' . $batch . ' batch.';
        $details_activity = 'Profile <b>(' . $dataInfo['name'] . '-' . $dataInfo['email'] . '-' . $batch . ')</b> deleted by ' . $loggedin_name . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['deleteAdminName']) && ($loggedin['role'] == 'dev') && $_POST['id'] && $_POST['batch']) {

    $batch = $_POST['batch'];
    $id = $_POST['id'];
    $name = $_POST['name'];
    $student_id = $_POST['student_id'];
    $student_id_main = $_POST['student_id_main'];
    $dperson = $loggedin['name'];
    $LastUpdateTime = date("Y-m-d H:i:s");

    if ($student_id_main == $student_id) {
        $up = "UPDATE {$batch} SET role='', LastUpdateTime='$LastUpdateTime' WHERE id=" . $id;
        $stmt = $connPdo->prepare($up);
        if ($stmt->execute()) {
            $msg['error'] = false;
            $msg['message'] = $name . ' removed from admin successfully.';
            $details_activity = 'Admin (' . $name . ') removed by ' . $dperson . '.';
            $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
        } else {
            $msg['error'] = true;
            $msg['message'] = "Something went wrong, Please try again later.";
        }
    } else {
        $msg['error'] = true;
        $msg['message'] = "Please enter valid Student ID.";
    }
} elseif (isset($_POST['notice_public']) && ($loggedin['role'] == 'dev') && $_POST['id']) {

    $id = $_POST['id'];
    $dperson = $loggedin['name'];

    $data = $data->batchData("notice", $id, "id");
    $title = $data['title'];
    $LastUpdateTime = date("Y-m-d H:i:s");

    $up = "UPDATE notice SET active='1', date='$LastUpdateTime' WHERE id=" . $id;
    $stmt = $connPdo->prepare($up);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = 'Notice (' . $title . ') make public successfully.';
        $details_activity = 'Notice (' . $title . ') make status public by ' . $dperson;
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
}elseif (isset($_POST['notice_private']) && ($loggedin['role'] == 'dev') && $_POST['id']) {

    $id = $_POST['id'];
    $dperson = $loggedin['name'];

    $data = $data->batchData("notice", $id, "id");
    $title = $data['title'];
    $LastUpdateTime = date("Y-m-d H:i:s");

    $up = "UPDATE notice SET active='0', date='$LastUpdateTime' WHERE id=" . $id;
    $stmt = $connPdo->prepare($up);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = 'Notice (' . $title . ') make private successfully.';
        $details_activity = 'Notice (' . $title . ') make status private by ' . $dperson;
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
}elseif (isset($_POST['ResolvedReportIssued']) && ($loggedin['role'] == 'dev') && $_POST['id']) {

    $id = $_POST['id'];
    $dperson = $loggedin['name'];

    $data = $data->batchData("report_issue", $id, "id");
    $std_id = $data['student_id'];
    $std_batch = $data['batch'];
    $LastUpdateTime = date("Y-m-d H:i:s");

    $up = "UPDATE report_issue SET resolve='1', re_date='$LastUpdateTime' WHERE id=" . $id;
    $stmt = $connPdo->prepare($up);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = 'Report of ' . $std_id . ' (' . $std_batch . ') resolved successfully.';
        $details_activity = 'Report of ' . $std_id . ' (' . $std_batch . ') resolved status changed by ' . $dperson;
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['NotResolvedReportIssued']) && ($loggedin['role'] == 'dev') && $_POST['id']) {

    $id = $_POST['id'];
    $dperson = $loggedin['name'];

    $data = $data->batchData("report_issue", $id, "id");
    $std_id = $data['student_id'];
    $std_batch = $data['batch'];
    $LastUpdateTime = date("Y-m-d H:i:s");

    $up = "UPDATE report_issue SET resolve='0', re_date='$LastUpdateTime' WHERE id=" . $id;
    $stmt = $connPdo->prepare($up);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = 'Report of ' . $std_id . ' (' . $std_batch . ') re-issued successfully.';
        $details_activity = 'Report of ' . $std_id . ' (' . $std_batch . ') re-issue status changed by ' . $dperson;
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['DeleteReportIssued']) && ($loggedin['role'] == 'dev') && $_POST['id']) {

    $id = $_POST['id'];
    $dperson = $loggedin['name'];

    $data = $data->batchData("report_issue", $id, "id");
    $std_id = $data['student_id'];
    $std_batch = $data['batch'];

    $up = "DELETE FROM report_issue WHERE id=" . $id;
    $stmt = $connPdo->prepare($up);
    if ($stmt->execute()) {
        $msg['error'] = false;
        $msg['message'] = 'Report of ' . $std_id . ' (' . $std_batch . ') removed from database successfully.';
        $details_activity = 'Report of ' . $std_id . ' (' . $std_batch . ') removed by ' . $dperson;
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['deleteHallName']) && ($loggedin['role'] == 'dev') && $_POST['id']) {
    $id = $_POST['id'];
    $code = $_POST['code'];
    $code_org = $_POST['code_org'];
    $dperson = $loggedin['name'];
    if ($code == $code_org) {
        $up = "DELETE FROM hall WHERE id='" . $id . "' AND code='" . $code . "'";
        $stmt = $connPdo->prepare($up);
        if ($stmt->execute()) {
            $msg['error'] = false;
            $msg['message'] = 'Successfully deleted hall ' . $code . '.';
            $details_activity = 'Hall (' . $code . ') deleted by ' . $dperson . '.';
            $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
        } else {
            $msg['error'] = true;
            $msg['message'] = "Something went wrong, Please try again later.";
        }
    } else {
        $msg['error'] = true;
        $msg['message'] = "Please enter valid hall code.";
    }
} elseif (isset($_POST['upMegaLink']) && ($loggedin['role'] == 'dev')) {
    $title = $_POST['title_link'];
    $link = $_POST['link'];
    $category = $_POST['category'];
    $date = date('d/m/Y h:ia');
    $name = $loggedin['name'];
    if (isset($_POST['add_megamenu'])) {
        $sql_in = "INSERT INTO mega_menu (title, link, added_by, category, date_added) VALUES ('$title','$link','$name', '$category', '$date')";
        $stmt = $connPdo->prepare($sql_in);
        $in = $stmt->execute();
        $details_activity = 'New external link (' . $title . ') added by ' . $loggedin_name . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } elseif (isset($_POST['update_link'])) {
        $sql_up = "UPDATE mega_menu SET title='$title', link='$link', added_by='$name', category='$category', date_added='$date' WHERE id='" . $_POST['id'] . "'";
        $stmt = $connPdo->prepare($sql_up);
        $up = $stmt->execute();
        $details_activity = 'External link (' . $title . ') updated by ' . $loggedin_name . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    }
    if ($up) {
        $msg['message'] = 'External link (' . $title . ') updated successfully.';
    } elseif ($in) {
        $msg['message'] = "New external link (" . $title . ") added successfully.";
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, please try again later.";
    }
} elseif (isset($_POST['send_add_info_req']) && isset($_POST["session"]) && isset($_POST["batch"]) && isset($_POST["email"]) && isset($_POST["student_id"]) && (!empty($_POST["email"])) && (!empty($_POST["student_id"])) && isset($_SESSION['student_id']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')) {
    $student_id = str_replace(' ', '', $_POST["student_id"]);
    $batch = $_POST['batch'];
    $session = $_POST['session'];
    $id = rand(10000, 1000000);
    $email = str_replace(' ', '', $_POST["email"]);
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);
    $email = filter_var($email, FILTER_VALIDATE_EMAIL);
    // $results = $SMTP_Validator->validate(array($email));

    $active = "0";
    $showing = "0";
    if ($email) {
        if (preg_match('/^[0-9]{10}+$/', $student_id)) {
            // if ($results[$email]) {
            $duplicate = "SELECT email, student_id FROM {$batch} WHERE email='$email' OR student_id='$student_id'";
            $stmt = $connPdo->prepare($duplicate);
            $stmt->execute();
            $duplicate = $stmt->rowCount();
            if ($duplicate > 0) {
                $msg['warning'] = true;
                $msg['message'] = "Sorry ! Provided student ID or email already added in the database.";
            } else {
                $results = "INSERT INTO `{$batch}` (`id`,`student_id`,`session`, `email`, `batch`, `active`, `showing`) VALUES ('" . $id . "', '" . $student_id . "', '" . $session . "', '" . $email . "', '" . $batch . "', '" . $active . "', '" . $showing . "');";
                $stmt = $connPdo->prepare($results);
                if ($stmt->execute()) {
                    $expFormat = mktime(date("H"), date("i"), date("s"), date("m"), date("d") + 1, date("Y"));
                    $expDate = date("Y-m-d H:i:s", $expFormat);
                    $key = md5($email);
                    $addKey = substr(md5(uniqid(rand(), 1)), 3, 10);
                    $key = $key . $addKey;
                    $created = "INSERT INTO `add_info_key` (`batch`, `student_id`, `email`, `key`, `expDate`) VALUES ('" . $batch . "', '" . $student_id . "', '" . $email . "', '" . $key . "', '" . $expDate . "');";
                    $stmt = $connPdo->prepare($created);
                    if ($stmt->execute()) {
                        # Details Message
                        $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
                        $output = '<p>Hi ' . $student_id . ',</p>';
                        $output .= '<p>Please click on the following link or copy the entire link into your browser to add your information.</p>';
                        $output .= '<p>-------------------------------------------------------------</p>';
                        $output .= '<p><a href="' . $actual_link . '/addinfo.php?add_info_users&key=' . $key . '&action=add" target="_blank">' . $actual_link . '/addinfo.php?add_info_users&key=' . $key . '&action=add</a></p>';
                        $output .= '<p>-------------------------------------------------------------</p>';
                        $output .= '<p>The link will expire after 1 day due to security reasons.</p>';
                        $output .= '<p>No action is required unless you request this mail, if you already added your information, please login then you can see this database</p>';
                        $output .= '<p>Thanks,<br>AIS Family Database Admin<br></p>';
                        $body = $output;
                        $subject = "AIS Family Database";
                        # Details Message
                        $mail = $mailSend->sendMail($email, $body, $subject);
                        if ($mail == 1) {
                            $msg['error'] = false;
                            $msg['message'] = "Congratulations!  Information update request mail has been sent with instructions to " . $email;
                            $details_activity = 'New update info request send to <b>(' . $email . '-' . $student_id . '-' . $batch . ')</b> by ' . $loggedin_name . '.';
                            $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
                        } else {
                            $msg['warning'] = true;
                            $msg['message'] = "Data submitted but mail not send to the mail.";
                        }
                    } else {
                        $msg['error'] = true;
                        $msg['message'] = "Add request not created, please try again later.";
                    }
                } else {
                    $msg['error'] = true;
                    $msg['message'] = "Info not submitted to server, please try again later.";
                }
            }
            // } else {
            //     $msg['error'] = true;
            //     $msg['message'] = "Email address not valid! Please type a valid email address and try again.";
            // }
        } else {
            $msg['error'] = true;
            $msg['message'] = "Please input 10 digit Student ID and try again.";
        }
    } else {
        $msg['error'] = true;
        $msg['message'] = "Invalid email address! Please type a valid email address and try again.";
    }
} elseif (isset($_POST["getAddInfoReq"]) && isset($_POST["email"]) && isset($_POST["student_id"]) && isset($_POST["batch"]) && (!empty($_POST["email"])) && (!empty($_POST["student_id"]))) {
    $student_id = str_replace(' ', '', $_POST["student_id"]);
    $batch = str_replace(' ', '', $_POST["batch"]);
    $email = str_replace(' ', '', $_POST["email"]);
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);
    $email = filter_var($email, FILTER_VALIDATE_EMAIL);
    // $results = $SMTP_Validator->validate(array($email));

    if ($email) {
        if (preg_match('/^[0-9]{10}+$/', $student_id)) {
            // if ($results[$email]) {
            $sql = "SELECT * FROM {$batch} WHERE email='" . $email . "' AND student_id='" . $student_id . "'";
            $stmt = $connPdo->prepare($sql);
            $stmt->execute();
            $row_check = $stmt->fetch();
            $count = $stmt->rowCount();
            if ($count == 0) {
                $msg['error'] = true;
                $msg['message'] = "Sorry! Could not find any Email or Student ID. Please re-check your email address.";
            } else {
                if ($row_check['active'] == 1) {
                    $msg['error'] = true;
                    $msg['message'] = "You have already added your information in database.";
                } else {
                    $expFormat = mktime(date("H"), date("i"), date("s"), date("m"), date("d") + 1, date("Y"));
                    $expDate = date("Y-m-d H:i:s", $expFormat);
                    $key = md5($email);
                    $addKey = substr(md5(uniqid(rand(), 1)), 3, 10);
                    $key = $key . $addKey;
                    $created = "INSERT INTO `add_info_key` (`batch`, `student_id`, `email`, `key`, `expDate`) VALUES ('" . $batch . "', '" . $student_id . "','" . $email . "', '" . $key . "', '" . $expDate . "');";
                    $stmt = $connPdo->prepare($created);
                    if ($stmt->execute()) {
                        # Details Message
                        $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
                        $output = '<p>Hello ' . $student_id . ',</p>';
                        $output .= '<p>Please click on the following link or copy the entire link into your browser to add your information.</p>';
                        $output .= '<p>-------------------------------------------------------------</p>';
                        $output .= '<p><a href="' . $actual_link . '/addinfo.php?add_info_users&key=' . $key . '&action=add" target="_blank">' . $actual_link . '/addinfo.php?add_info_users&key=' . $key . '&action=add</a></p>';
                        $output .= '<p>-------------------------------------------------------------</p>';
                        $output .= '<p>The link will expire after 1 day due to security reasons.</p>';
                        $output .= '<p>No action is required unless you request this mail, if you already added your information, please login then you can see this database</p>';
                        $output .= '<p>Thanks,<br>AIS Family Database Admin<br></p>';
                        $body = $output;
                        $subject = "AIS Family Database";
                        # Details Message
                        $mail = $mailSend->sendMail($email, $body, $subject);
                        if ($mail == 1) {
                            $msg['error'] = false;
                            $msg['message'] = "Congratulations! Check Primary/Spam folder of your mailbox. For update information an email has been sent with instructions to " . $email;
                            if (isset($_SESSION['student_id'])) {
                                $details_activity = 'New update request for <b>(' . $email . '-' . $student_id . '-' . $batch . ')</b> send by ' . $loggedin['name'] . '.';
                            } else {
                                $details_activity = '<b>(' . $email . '-' . $student_id . '-' . $batch . ')</b> got his/her own new update request.';
                                $emailName = empty($row_check['name']) ? $email : $row_check['name'];
                                $loggedinInfoInsert = array(
                                    'name' => $emailName,
                                    'batch' => $batch,
                                    'student_id' => $student_id
                                );
                            }
                            $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
                        } else {
                            $msg['warning'] = true;
                            $msg['message'] = "New key generated but email not send to this mail (" . $email . ").";
                        }
                    } else {
                        $msg['error'] = true;
                        $msg['message'] = "Something went wrong, Please try again later.";
                    }
                }
            }
            // } else {
            //     $msg['error'] = true;
            //     $msg['message'] = "Email address not valid, please change the email and try again.";
            // }
        } else {
            $msg['error'] = true;
            $msg['message'] = "10 digit Student ID required, please change the student ID and try again.";
        }
    } else {
        $msg['error'] = true;
        $msg['message'] = "Invalid email address, please change the email and try again.";
    }
} elseif (isset($_POST["get_pass_reset_request"]) && isset($_POST["email"]) && (!empty($_POST["email"])) && isset($_POST["batch"]) && (!empty($_POST["batch"]))) {
    $email = $_POST["email"];
    $batch = $_POST["batch"];
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);
    $email = filter_var($email, FILTER_VALIDATE_EMAIL);
    if (!$email) {
        $msg['error'] = true;
        $msg['message'] = "Invalid email address! Please type a valid email address! Please re-check your email address or contact to email: myicche@gmail.com to reset your password.";
    } else {
        $sel_query = "SELECT * FROM {$batch} WHERE active='1' AND email='" . $email . "'";
        $stmt = $connPdo->prepare($sel_query);
        $stmt->execute();
        $row = $stmt->rowCount();
        $row_email = $stmt->fetch();
        if ($row == 1) {
            $expFormat = mktime(date("H"), date("i"), date("s"), date("m"), date("d") + 1, date("Y"));
            $expDate = date("Y-m-d H:i:s", $expFormat);
            $key = md5($email);
            $addKey = substr(md5(uniqid(rand(), 1)), 3, 10);
            $key = $key . $addKey;
            $keyUp =  "INSERT INTO `password_reset_temp` (`batch`, `email`, `key`, `expDate`)
				VALUES ('" . $batch . "', '" . $email . "', '" . $key . "', '" . $expDate . "');";
            $stmt = $connPdo->prepare($keyUp);
            $stmt->execute();
            $actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
            $output = '<p>Hi <b>' . $row_email['name'] . '</b>,</p>';

            $output .= '<p>';
            $output .= 'Your login credentials is here:</p>';

            $output .= '<p>';
            $output .= '<b>Batch: </b>' . $row_email['batch'] . '<br>';
            $output .= '<b>Student ID: </b>' . $row_email['student_id'] . '<br>';
            $output .= '<b>Current Password: </b>' . $row_email['Password'] . '<br>';
            $output .= '</p>';
            $output .= '<p><b>Or</b></p>';

            $output .= '<p>Please click on the following link or copy the entire link into your browser to reset your password.</p>';
            $output .= '<p>-------------------------------------------------------------</p>';
            $output .= '<p><a href="' . $actual_link . '/resetpass.php?final_reset_mail=true&key=' . $key . '&action=reset" target="_blank">' . $actual_link . '/resetpass.php?final_reset_mail=true&key=' . $key . '&action=reset</a></p>';
            $output .= '<p>-------------------------------------------------------------</p>';
            $output .= '<p>The link will expire after 1 day due to security reasons.</p>';
            $output .= '<p>No action is required unless you request this forgotten password email, your password will not be reset. But if you want to log in and if anyone can guess your password then change the password.</p>';
            $output .= '<p>Thanks,<br>AIS Family Database Admin<br></p>';
            $body = $output;
            $subject = "AIS Family Database Password Reset";
            $mail = $mailSend->sendMail($email, $body, $subject);
            if ($mail == 1) {
                $msg['error'] = false;
                $msg['message'] = "Congratulations! Check Primary/Spam folder of your mailbox. Password reset email has been sent to you with instructions.";
            } else {
                $msg['error'] = true;
                $msg['message'] = "Something went wrong, Please try again later.";
            }
        } else {
            $msg['error'] = true;
            $msg['message'] = "Sorry! Could not find any email address. Please re-check your email address ";
        }
    }
} elseif (($_POST["type"] == "sendMailClick") && isset($_POST["batch"]) && isset($_POST["email"]) && isset($_POST["action"]) && $_POST["action"] == "sendPassword") {

    $email = $_POST['email'];
    $batch = $_POST['batch'];

    $sel_query = "SELECT * FROM {$batch} WHERE active='1' AND email='" . $email . "'";
    $stmt = $connPdo->prepare($sel_query);
    $stmt->execute();
    $row_email = $stmt->fetch();

    $output = '<p>Hi <b>' . $row_email['name'] . '</b>,</p>';

    $output .= '<p>';
    $output .= 'Your login credentials is here:</p>';
    $output .= '<p>';
    $output .= '<b>Batch: </b>' . $row_email['batch'] . '<br>';
    $output .= '<b>Student ID: </b>' . $row_email['student_id'] . '<br>';
    $output .= '<b>Password: </b>' . $row_email['Password'] . '<br>';
    $output .= '</p>';
    $output .= "<p style='color:red'> <b>N.B.: Don't share your login credentials with anyone.</b></p>";

    $output .= '<p>Thanks,<br>AIS Family Database Admin<br></p>';
    $body = $output;
    $subject = "AIS Family Login Credentials";
    $mail = $mailSend->sendMail($email, $body, $subject);

    if ($mail == 1) {
        $msg['error'] = false;
        $msg['message'] = "Login credentials send successfully to " . $email;
        $details_activity = 'Login credentials send to ' . $email;
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, please try again.";
    }
} elseif (isset($_POST["newPassReset"]) && isset($_POST["batch"]) && isset($_POST["email"]) && isset($_POST["action"]) && $_POST["action"] == "update") {
    $error = "";
    $pass1 = $_POST["pass1"];
    $pass2 = $_POST["pass2"];
    $email = $_POST["email"];
    $batch = $_POST["batch"];
    $curDate = date("Y-m-d H:i:s");
    $sel_query = "SELECT * FROM {$batch} WHERE active='1' AND email='" . $email . "'";
    $stmt = $connPdo->prepare($sel_query);
    $stmt->execute();
    $row_email = $stmt->fetch();
    $loggedinInfoInsert = array(
        'name' => $row_email['name'],
        'batch' => $row_email['batch'],
        'student_id' => $row_email['student_id']
    );
    if ($pass1 != $pass2) {
        $error = "Please try again, confirm new password doesn't match.";
    }
    if ($error != "") {
        $msg['error'] = true;
        $msg['message'] = $error;
    } else {
        $pass1 = $pass1;
        $updatePass = "UPDATE `{$batch}` SET `Password`='" . $pass1 . "', `LastUpdateTime`='" . $curDate . "' WHERE `email`='" . $email . "';";
        $stmt = $connPdo->prepare($updatePass);
        if ($stmt->execute()) {
            $del = "DELETE FROM `password_reset_temp` WHERE `email`='" . $email . "';";
            $stmt = $connPdo->prepare($del);
            if ($stmt->execute()) {
                $msg['error'] = false;

                $sel_query = "SELECT * FROM {$batch} WHERE active='1' AND email='" . $email . "'";
                $stmt = $connPdo->prepare($sel_query);
                $stmt->execute();
                $row_email = $stmt->fetch();

                $output = '<p>Hi <b>' . $row_email['name'] . '</b>,</p>';

                $output .= '<p>';
                $output .= 'Your login credentials is here:</p>';
                $output .= '<p>';
                $output .= '<b>Batch: </b>' . $row_email['batch'] . '<br>';
                $output .= '<b>Student ID: </b>' . $row_email['student_id'] . '<br>';
                $output .= '<b>Password: </b>' . $row_email['Password'] . '<br>';
                $output .= '</p>';

                $output .= '<p>Thanks,<br>AIS Family Database Admin<br></p>';
                $body = $output;
                $subject = "AIS Family Password Changed Confirmation";
                $mail = $mailSend->sendMail($email, $body, $subject);

                $msg['message'] = "You have successfully changed your password.";
                $details_activity = $row_email['name'] . ' reset his/her own login password.';
                $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
            }
        } else {
            $msg['error'] = true;
            $msg['message'] = "Something went wrong, please try again.";
        }
    }
} elseif (isset($_POST['sendMailCustom']) && isset($_POST['batch']) && isset($_POST['email'])) {

    $mailBody = $_POST['mailBody'];
    $mailSub = $_POST['mailSub'];
    $batch = $_POST['batch'];
    $email = $_POST['email'];

    $sel_query = "SELECT * FROM {$batch} WHERE active='1' AND email='" . $email . "'";
    $stmt = $connPdo->prepare($sel_query);
    $stmt->execute();
    $row_email = $stmt->fetch();

    $output = '<p>Hi <b>' . $row_email['name'] . '</b>,</p>';

    $output .= '<p>';
    $output .= $mailBody;
    $output .= "</p>";

    $output .= '<p>Thanks,<br>AIS Family Database Admin<br></p>';
    $body = $output;
    $subject = "AIS Family Login Credentials";
    $mail = $mailSend->sendMail($email, $body, $mailSub);

    if ($mail == 1) {
        $msg['error'] = false;
        $msg['message'] = "Customize email send successfully to " . $email;
        $details_activity = 'Customize email send to ' . $email;
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, please try again.";
    }
} elseif (isset($_POST["add_info_users_req"]) && isset($_POST["email"]) && isset($_POST["batch"]) && isset($_POST["student_id"]) && isset($_POST["action"]) && $_POST["action"] == "add") {
    $return = $data->addInfo($_POST);
    if ($return == 0) {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, please try again later.";
    } elseif ($return == 1) {
        $msg['error'] = true;
        $msg['message'] = "Confirm password not matched, please enter password carefully.";
    } elseif ($return == 2) {
        $batch = $_POST['batch'];
        $email = $_POST['email'];

        $sel_query = "SELECT * FROM {$batch} WHERE active='1' AND email='" . $email . "'";
        $stmt = $connPdo->prepare($sel_query);
        $stmt->execute();
        $row_email = $stmt->fetch();

        $output = '<p>Hi <b>' . $row_email['name'] . '</b>,</p>';

        $output .= '<p> Your details information submitted successfully. Here is your login credentials:</p>';
        $output .= '<p>';
        $output .= '<b>Batch: </b>' . $row_email['batch'] . '<br>';
        $output .= '<b>Student ID: </b>' . $row_email['student_id'] . '<br>';
        $output .= '<b>Password: </b>' . $row_email['Password'] . '<br>';
        $output .= '</p>';
        $output .= "<p style='color:red'> <b>N.B.: Don't share your login credentials with anyone.</b></p>";

        $output .= '<p>Thanks,<br>AIS Family Database Admin<br></p>';
        $body = $output;
        $subject = "AIS Family Registration Confirmation";
        $mail = $mailSend->sendMail($email, $body, $subject);

        $details_activity = '<b>(' . $row_email['name'] . '-' . $row_email['student_id'] . '-' . $batch . ')</b> Initially updated his/her profile details.';
        $loggedinInfoInsert = array(
            'name' => $row_email['name'],
            'batch' => $batch,
            'student_id' => $row_email['student_id']
        );

        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);

        if ($mail == 1) {
            $msg['error'] = false;
            $msg['message'] = "You data updated successfully and mail confirmation send to you with login credentials. Thank you.";
        } else {
            $msg['warning'] = true;
            $msg['message'] = "Your data updated successfully, but mail confirmation not send to you. You can login and browse database. Thank you.";
        }
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, please contact to database administration.";
    }
} elseif (isset($_POST['sqlCodeExecute']) && ($loggedin['role'] == 'dev')) {
    $sqltable = $_POST['code'];
    $sql = "" . $sqltable . "";
    // $sql = str_replace(chr(39),"`",$sql);
    $stmt = $connPdo->prepare($sql);
    if ($stmt->execute()) {
        $sqlvalue = addslashes($sql);
        $date = date("Y-m-d H:i:s");
        $sql1 = "INSERT INTO sqlvalue (text, date) VALUES ('$sqlvalue', '$date')";
        $stmt1 = $connPdo->prepare($sql1);
        $stmt1->execute();
        $msg['error'] = false;
        $msg['message'] = 'SQL executed successfully.';
        $details_activity = 'SQL code executed by ' . $loggedin['name'];
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, Please try again later.";
    }
} elseif (isset($_POST['deleteSqlBackup']) && ($loggedin['role'] == 'dev') && isset($_POST['file'])) {
    $file = $_POST['file'];
    $path    = __DIR__ . '/../backup/log';
    // $path    = './backup/log';
    $fileDir = $path . "/" . $file;
    $date = date("d-m-Y h:i A", filemtime($fileDir));
    $size = number_format(filesize($fileDir) / 1024, 2);
    if (is_file($fileDir) && unlink($fileDir)) {
        $details_activity = 'SQL Backup (' . $file . ' || ' . $size . 'KB || ' . $date . ') deleted by ' . $loggedin_name . '.';
        $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
        $msg['error'] = false;
        $msg['message'] = 'SQL Backup (' . $size . 'KB || ' . $date . ') deleted successfully.';
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, please try again later.";
    }
} elseif (isset($_POST['createFaq']) && ($loggedin['role'] == 'dev')) {
    $serial = $_POST['serial'];
    $title = $_POST['title_faq'];
    $details = addslashes($_POST['details']);
    $for_whom = $_POST['for_whom'];
    $name = $loggedin['name'];
    $student_id = $loggedin['student_id'];
    $active = $_POST['active'];
    $date = date("Y-m-d H:i:s");
    if (isset($_POST['faqin'])) {
        $sql_in = "INSERT INTO faq (serial, title, details, for_whom, name, student_id, active, date) VALUES ('$serial','$title','$details','$for_whom','$name','$student_id','$active','$date')";
        $stmt = $connPdo->prepare($sql_in);
        $in = $stmt->execute();
        if ($in) {
            $details_activity = 'New FAQs (' . $title . ') added by ' . $loggedin_name . '.';
            $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
        }
    } elseif (isset($_POST['faqup'])) {
        $sql_up = "UPDATE faq SET serial='$serial',title='$title',details='$details',for_whom='$for_whom',active='$active',date='$date' WHERE id='" . $_POST['id'] . "'";
        $stmt = $connPdo->prepare($sql_up);
        $up = $stmt->execute();
        if ($up) {
            $details_activity = 'FAQs (' . $title . ') updated by ' . $loggedin_name . '.';
            $insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
        }
    }
    if ($up) {
        $msg['message'] = 'FAQ (' . $title . ') updated successfully.';
    } elseif ($in) {
        $msg['message'] = "New FAQ (" . $title . ") added successfully.";
    } else {
        $msg['error'] = true;
        $msg['message'] = "Something went wrong, please try again later.";
    }
} else {
    $msg['error'] = $msg['warning'] = true;
    $msg['message'] = "Sorry ! you are not authorised.";
    // echo "Ha Ha Ha !!! You are fool.";
}
echo json_encode($msg);
$connPdo = null;
