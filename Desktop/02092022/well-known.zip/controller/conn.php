<?php
class Database
{

	// private $username = "root";
	// private $password = "";
	// private $server = "mysql:host=localhost;dbname=ais";

	private $username = "aismyweb_family";
	private $password = "&^$%ekjdfhsdkjfg1b2Kx";
	private $server = "mysql:host=localhost;dbname=aismyweb_ais";

	private $css = "<style>
	@media only screen and (max-width: 860px) {
		.error-conn {
			width: 90%!important;
		}
			.error-conn .error_reload_btn{
				width: 100px!important;
			}
		}
		</style>
		<script>
		setTimeout(function(){
			window.location.reload(1);
		 }, 1000);
		</script>
	<div class='error-conn' style='
position: absolute;
left: 50%;
transform: translate(-50%,-50%);
text-align: center;
top: 50%;
width: 54%;
padding: 25px 10px 25px 10px;'>
<strong>HTTP 502 Bad Gateway</strong>
<br> <small>© AIS Family</small></div>";

	private $options  = array(PDO::ATTR_PERSISTENT => true, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',);
	protected $conn;

	public function open()
	{
		try {
			$this->conn = new PDO($this->server, $this->username, $this->password, $this->options);
			return $this->conn;
		} catch (PDOException $e) {
			echo $this->css;
		}
	}

	// public function mysqli()
	// {
	// 	try {
	// 		$conn = new mysqli($this->servername, $this->username, $this->password, $this->dbname);
	// 		mysqli_query($conn, 'SET CHARACTER SET utf8mb4');
	// 		mysqli_query($conn, "SET SESSION collation_connection ='utf8mb4_general_ci'");
	// 		return $conn;
	// 	} catch (Exception $e) {
	// 		echo $this->css;
	// 	}
	// }

	public function close()
	{
		$this->conn =null;
	}
}

$pdo = new Database();
