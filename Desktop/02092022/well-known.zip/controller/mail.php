<?php
class Mail
{

    public function __construct()
    {
        $this->conn = new Database();
        $this->conn = $this->conn->open();

    }

    public function getMailInfo()
    {
        $stmt = $this->conn->prepare("SELECT * FROM sys_mail_setup WHERE status=1 LIMIT 1");
        $stmt->execute();
        $this->data = $stmt->fetch();
        return $this->data;
    }

    public function sendMail($email, $message, $subject)
    {
        $this->getMailInfo();
        $host = $this->data['host'];
        $port = $this->data['port'];;
        $from = $this->data['email'];;
        $password = $this->data['password'];;
        $smtp = $this->data['smtp'];;
        
        $fromName = 'AIS Family Database';
        $bccMail = 'aisfamilyru@gmail.com';
        //Load phpmailer
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->CharSet = ('UTF-8');
            $mail->Host = $host;
            $mail->SMTPAuth = true;
            $mail->Username = $from;
            $mail->Password = $password;
            $mail->SMTPOptions = array(
                'ssl' => array(
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                    'allow_self_signed' => true
                )
            );
            $mail->SMTPSecure = $smtp;
            $mail->Port = $port;
            $mail->IsHTML(true);
            $mail->From = $from;
            $mail->FromName = $fromName;
            $mail->Sender = $from; 
            // $mail->setFrom($from);
            $mail->addAddress($email);
            $mail->addReplyTo($from);
            // $mail->addBCC($bccMail);
            $mail->WordWrap = 50;
            $mail->Subject = $subject;
            $mail->Body  = $message;
            if ($mail->send()) {
                $response = 1;
            } else {
                $response = 0;
            }
            return $response;
        } catch (Exception $e) {
            $_SESSION['error'] = $mail->ErrorInfo;
        }
    }

    
}

?>