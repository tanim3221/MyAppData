<?php
session_start();
ini_set('display_errors', 0);
ini_set('display_startup_errors', 0);
error_reporting(0);
date_default_timezone_set("Asia/Dhaka");
require __DIR__.'/controller/conn.php';
require __DIR__.'/controller/others.php';
require __DIR__.'/controller/mobile_detect.php';
$detect = new Mobile_Detect;
$others = new Others;

$action = "Logout";
$uip = $others->get_client_ip();
$in = $others->insertLoginInfo($action, $detect, $uip);
if ($in) {
	session_destroy();
	unset($_SESSION['batch']);
	unset($_SESSION['student_id']);
	unset($_COOKIE['SECURE_LOG']);
	setcookie("SECURE_LOG", "", time() - 3600,"/");
}
header('Location: index.php');
