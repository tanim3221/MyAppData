<div class="search_results_view">
	<?php
	// ini_set('display_errors', 1);
	// ini_set('display_startup_errors', 1);
	// error_reporting(E_ALL);
	//session_start();
	//require 'connect.php';
	if (isset($_REQUEST['category'])) {
		$search_batch = $_REQUEST['category'];
		$numRows = 0;
		if (!empty($_REQUEST['query'])) {
			$search  = $_REQUEST['query'];

			$searchTerms = explode(' ', $search);
			$searchTermBits = array();
			foreach ($searchTerms as $term) {
				$term = trim($term);
				if (!empty($term)) {
					if ($search_batch == 'office_stuff') {
						$searchTermBits[] = "name LIKE '%$term%' OR phone LIKE '%$term%' OR email LIKE '%$term%' OR designation LIKE '%$term%'";
					} elseif ($search_batch == 'teachers') {
						$searchTermBits[] = "name LIKE '%$term%' OR phone LIKE '%$term%' OR email LIKE '%$term%' OR designation LIKE '%$term%' OR edu LIKE '%$term%'";
					} else {
						$searchTermBits[] = "student_id LIKE '%$term%' OR batch LIKE '%$term%' OR name_bangla LIKE '%$term%' OR name LIKE '%$term%' OR phone LIKE '%$term%' OR blood LIKE '%$term%' OR district LIKE '%$term%' OR hall LIKE '%$term%'";
					}
				}
			}
			$searchSys = implode(' OR ', $searchTermBits);
			if ($search_batch == 'teachers') {
				$selectTerm = "name,phone,email, fb_id,photo, designation, edu,id";
				$sql = "SELECT {$selectTerm} FROM teacher WHERE (" . $searchSys . ")";
				$sql .= "ORDER BY LOCATE ('$term', name) ASC, LOCATE ('$term', phone) ASC";
			} elseif ($search_batch == 'office_stuff') {
				$selectTerm = "name,phone,email, fb_id,photo, designation,id";
				$sql = "SELECT {$selectTerm} FROM office_stuff WHERE (" . $searchSys . ")";
				$sql .= "ORDER BY LOCATE ('$term', name) ASC, LOCATE ('$term', phone) ASC";
			} else {
				$selectTerm = "student_id,name_bangla,name,batch,phone,blood,district, email, fb_id, photo, address, address_bangla,id";
				if ($search_batch == 'any_batch') {
					$sql_array = [];
					$sql = "SELECT * FROM batch WHERE active='1' ORDER by batch DESC";
					$stmt = $connPdo->prepare($sql);
					$stmt->execute();
					foreach ($stmt as $row) {
						$row_batch = $row['batch'];
						if (($loggedin['batch'] == $row_batch) || ($loggedin['role'] == 'dev')) {
							$th . $row_batch = "SELECT {$selectTerm} FROM {$row_batch} WHERE active='1' AND (" . $searchSys . ")";
						} else {
							$th . $row_batch = "SELECT {$selectTerm} FROM {$row_batch} WHERE active='1' AND showing ='1' AND (" . $searchSys . ")";
						}

						$sql_array[] = $th . $row_batch;
					}
					$sql = '';
					foreach ($sql_array as $sql_query) {
						$sql .= $sql_query;
						if (next($sql_array)) {
							$sql .= ' UNION ';
						}
					}
				} else {
					if (($loggedin['batch'] == $search_batch) || ($loggedin['role'] == 'dev')) {
						$sql = "SELECT {$selectTerm} FROM {$search_batch} WHERE active='1' AND (" . $searchSys . ")";
					} else {
						$sql = "SELECT {$selectTerm} FROM {$search_batch} WHERE active='1' AND showing ='1' AND (" . $searchSys . ")";
					}
				}
				$sql .= "ORDER BY LOCATE ('$term', name) ASC, LOCATE ('$term', student_id) ASC, LOCATE ('$term', phone) ASC";
			}
			$stmtss = $connPdo->prepare($sql);
			$stmtss->execute();
			$numRows = $stmtss->rowCount();

			$date = date("Y-m-d H:i:s");
			$date_chk = date("Y-m-d");

			#Check double search keywords
			// $duplicate = "SELECT * FROM search WHERE keywords='$search' AND student_id='$student_id' AND key_cat='$search_batch' AND DATE_FORMAT(date, '%Y-%m-%d') = '$date_chk'";
			// $stmt = $connPdo->prepare($duplicate);
			// $stmt->execute();
			// $numRows = $stmtss->rowCount();
			// if ($numRows < 1) {
			// 	$key_sql = "INSERT INTO search (keywords, key_cat, batch, name, student_id, date) VALUES ('$search','$search_batch', '{$loggedin['batch']}', '{$loggedin['name']}','$student_id', '$date')";
			// 	$stmt = $connPdo->prepare($key_sql);
			// 	$stmt->execute();
			// }

			# Update search info
			$key_sql = "INSERT INTO search (keywords, key_cat, batch, name, student_id, date) VALUES ('$search','$search_batch', '{$loggedin['batch']}', '{$loggedin['name']}','$student_id', '$date')";
			$stmt = $connPdo->prepare($key_sql);
			$stmt->execute();

			$details_activity = 'Searching with keywords - <b><i><u>' . $search . ' (' . $search_batch . ')</u></i></b>.';
			$insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
		}
		if ($numRows > 0) {
			echo "<div class='alert alert-success home_all_search'>There seem <b>" . $numRows . "</b> search result(s) for - <b> " . $_REQUEST['query'] . " (" . str_replace('_', ' ', $_REQUEST['category']) . ")</b>. <span class='explore_more_search_btn text-primary' style='cursor:pointer'  id='explore_moreMenu'>View more</span> </div>";
	?>
			<?php if ($search_batch == 'office_stuff') { ?>
				<table id='ais_family' class='table' style='width:100%'>
					<thead>
						<tr>
							<th><b>Photo</th>
							<th><b>Name</th>
							<th><b>Designation</th>
							<th><b>Mobile </th>
							<th><b>Email</th>
							<th><b>Action</th>
						</tr>
					</thead>
					<?php
					foreach ($stmtss as $row) { ?>
						<tr>
							<td>
								<div class='avatar'><a class='fb_id' target='_blank' href='https://www.facebook.com/<?= $row['fb_id'] ?>'><img src='image/<?= $row['photo'] ?>'><img class='img-top' src='ais-assets/icon/fb.png'></a></div>
							</td>
							<td data-label='Name' style='font-weight:bold;'><?= $row['name'] ?></td>
							<td data-label='Designation'><?= $row['designation'] ?></td>
							<td data-label='Mobile'><a href='tel:<?= $row['phone'] ?>'><?= $row['phone'] ?></a></td>
							<td data-label='Email'><a href='mailto:<?= $row['email'] ?>'><?= $row['email'] ?></a></td>
							<td>
								<div class='btn-group'>
									<button type="button" data-id="<?= $row['id'] ?>" class='view_btn btn btn-success btn-sm' id='view_btn_office_stuff'><i class='fas fa-eye'></i></button>
								</div>
							</td>
						</tr>
					<?php } ?>
				</table>
			<?php $connPdo = null;
			} elseif ($search_batch == 'teachers') { ?>
				<table id='ais_family' class='table' style='width:100%'>
					<thead>
						<tr>
							<th><b>Photo</th>
							<th><b>Name</th>
							<th><b>Designation</th>
							<th><b>Mobile </th>
							<th><b>Email</th>
							<th><b>Action</th>
						</tr>
					</thead>
					<?php
					foreach ($stmtss as $row) { ?>
						<tr>
							<td>
								<div class='avatar'><a class='fb_id' target='_blank' href='https://www.facebook.com/<?= $row['fb_id'] ?>'><img src='image/<?= $row['photo'] ?>'><img class='img-top' src='ais-assets/icon/fb.png'></a></div>
							</td>
							<td data-label='Name' style='font-weight:bold;'><?= $row['name'] ?></td>
							<td data-label='Designation'><?= $row['designation'] ?></td>
							<td data-label='Mobile'><a href='tel:<?= $row['phone'] ?>'><?= $row['phone'] ?></a></td>
							<td data-label='Email'><a href='mailto:<?= $row['email'] ?>'><?= $row['email'] ?></a></td>
							<td>
								<div class='btn-group'>
									<button type="button" data-id="<?= $row['id'] ?>" class='view_btn btn btn-success btn-sm' id='view_btn_tea'><i class='fas fa-eye'></i></button>
								</div>
							</td>
						</tr>
					<?php } ?>
				</table>
			<?php $connPdo = null;
			} else { ?>
				<table id='ais_family_std_search' class='table' style='width:100%'>
					<thead>
						<tr>
							<th width="70"><b>Photo</th>
							<th width="120"><b>Student ID</th>
							<th><b>Name</th>
							<th width="60"><b>Batch</th>
							<th width="100"><b>Mobile</th>
							<th width="70"><b>Blood</th>
							<th><b>Email</th>
							<th width="50"><b>View</th>
						</tr>
					</thead>
				</table>

			<?php }  
		} else {
			$input =  $_REQUEST['query'];
			$search_batch = $_REQUEST['category'];

			if ($search_batch == 'office_stuff') {
				$sqlclosest = "SELECT * FROM office_stuff";
			} elseif ($search_batch == 'teachers') {
				$sqlclosest = "SELECT * FROM teacher";
			} else {

				if ($search_batch == 'any_batch') {
					$sql_array = [];
					$sqlsearch = "SELECT * FROM batch WHERE active='1' ORDER by batch ASC";
					$stmt = $connPdo->prepare($sqlsearch);
					$stmt->execute();
					foreach ($stmt as $rowsss) {
						$row_batch = $rowsss['batch'];
						if (($loggedin['batch'] == $row_batch) || ($loggedin['role'] == 'dev')) {
							$th . $row_batch = "SELECT name FROM {$row_batch} WHERE active='1'";
						} else {
							$th . $row_batch = "SELECT name FROM {$row_batch} WHERE active='1' AND showing ='1'";
						}

						$sql_array[] = $th . $row_batch;
					}
					$sqlclosest = '';
					foreach ($sql_array as $sql_query) {
						$sqlclosest .= $sql_query;
						if (next($sql_array)) {
							$sqlclosest .= ' UNION ';
						}
					}
				} else {
					if (($loggedin['batch'] == $search_batch) || ($loggedin['role'] == 'dev')) {
						$sqlclosest = "SELECT * FROM {$search_batch} WHERE active='1'";
					} else {
						$sqlclosest = "SELECT * FROM {$search_batch} WHERE active='1' AND showing ='1'";
					}
				}
				$sqlclosest .= " ORDER BY name ASC";
			}
			# Get value as Array
			// print_r($sqlclosest);
			$stmt = $connPdo->prepare($sqlclosest);
			$stmt->execute();
			$words = $closest = array();
			foreach ($stmt as $rowclosest) {
				$words[] = $rowclosest['name'];
			}

			$shortest = -1;
			foreach ($words as $word) {
				$lev = levenshtein($input, $word);
				if ($lev == 0) {
					$closest = $word;
					$shortest = 0;
					break;
				}
				if ($lev <= $shortest || $shortest < 0) {
					$closest[] = $word;
					$shortest = $lev;
				}
			}

			$connPdo = null;

		?>

			<div class="error card-section" style="margin-bottom: 100px;">
				<p class="suggestion_main alert alert-danger">
					<?php if (empty($_REQUEST['query'])) { ?>
						No search keywords input.
					<?php } else { ?>
						Your search - <b><em><?= $_REQUEST['query'] ?><?php echo " (" . str_replace('_', ' ', $_REQUEST['category']) . ")" ?></em></b> - did not match any information. <span class='explore_more_search_btn text-primary' style='cursor:pointer' id="explore_moreMenu">View more</span>
					<?php } ?>
				</p>
				<p class="suggestion_head" class="mt-2"><b>Suggestions:</b></p>
				<ul class="suggestion_item">
					<?php if (empty($_REQUEST['query'])) { ?>
						<li class="text-danger">Please input something and select search category to find information</li>
					<?php } else if (empty($_REQUEST['category'])) { ?>
						<li class="text-danger">Please select search category to find information.</li>
					<?php } else {
						echo '<div class="mb-3">';
						$replaceValue = array('md.', 'Md', 'Md.', 'md. ', 'Md. ', 'Md .', 'md .', 'Md . ', 'md . ', ' .', 'Dr. ', 'M. ', 'M.', 'Mst. ', 'Mst.', ' . ', '. ');
						foreach ($closest as $value) {
							$value = str_replace($replaceValue, '', $value);
							$dataView =  '
							<a href="home.php?query=' . str_replace(" ","+",$value) . '&category=' . $search_batch . '&ref=search_suggetion#search_results" class="mr-2">' . $value . '</a>| ';
							echo $dataView;
						}

						echo '</div>';
					?>
						<li>Make sure that all words are spelled correctly.</li>
						<li>Try different keywords.</li>
						<li>Try more general keywords.</li>
						<li>Try with single or short keywords.</li>
					<?php } ?>


				</ul>
			</div>

	<?php }
	}
	?>
</div>