<?php
if (isset($_POST['hall_submit'])) {
	$hall = $_POST['hall'];
	if (isset($_SESSION['student_id'])) {
		$key_sql = "UPDATE {$batch} SET hall='" . $hall . "' WHERE student_id ='" . $loggedin['student_id'] . "'";
        $stmt = $connPdo->prepare($key_sql);
	    $stmt->execute();
		$msg = 'Hall name succesfully added to your profile.';
		$details_activity = 'Hall ('.str_replace('_' ,' ',$hall).') added.';
		$insertLog = $others->activity_log_save($details_activity, $loggedinInfoInsert);
		echo "<script>window.history.go(-1);</script>";
	} else {
		$error = 'Sorry! You are not loggedin.';
	}
}

$student_id = $loggedin['student_id'];
$hall_chk = $others->getHallName(substr($student_id, 2, 3));
$hall = $loggedin['hall'];
if (($hall_chk=='0')) { 
    if ($hall=='') { ?>
    <div class="hall_name_wrapper">
        <div class="hall_name_body">
            <div class="mobile_nav_head_hall">
                <div class="mobile_nav_title_hall modal-header p-0">
                    <h4>
                        Complete your profile
                    </h4>
                </div>
            </div>
            <form action="" method="POST">
                   <div class="form-group">
                <label for="">Hall Name</label>
                <select class="selectpicker form-control" data-live-search="true" id="hall_name_select" name="hall" required>
                    <option value="">Choose your hall</option>
                    <option value="Bangabandhu_Sheikh_Mujibur_Rahman_Hall"> Bangabandhu Sheikh Mujibur Rahman Hall – বঙ্গবন্ধু শেখ মুজিবুর রহমান হল </option>
                    <option value="Bangamata _Fazilatunnesa _Hall"> Bangamata  Fazilatunnesa  Hall – বঙ্গমাতা ফজিলাতুন্নেসা হল </option>
                    <option value="Begum_Khaleda_Zia_Hall"> Begum Khaleda Zia Hall – বেগম খালেদা জিয়া হল </option>
                    <option value="Madar_Bux_Hall"> Madar Bux Hall – মাদার বখ্‌শ হল </option>
                    <option value="Mannujan_Hall"> Mannujan Hall – মুন্নুজান হল </option>
                    <option value="Matihar_Hall">  Matihar Hall – মতিহার হল </option>
                    <option value="Nawab_Abdul_Latif_Hall	"> Nawab Abdul Latif Hall – নবাব আব্দুল লতিফ হল </option>
                    <option value="Rahamatunnesa_Hall"> Rahamatunnesa Hall – রহমতুন্নেসা হল </option>
                    <option value="Rokeya_Hall"> Rokeya Hall -রোকেয়া হল </option>
                    <option value="Shah_Mukhdum_Hall"> Shah Mukhdum Hall – শাহ্‌ মখদুম হল </option>
                    <option value="Shaheed_Habibur_Rahman_Hall"> Shaheed Habibur Rahman Hall – শহীদ হবিবুর রহমান হল </option>
                    <option value="Shaheed_Shamsuzzoha_Hall"> Shaheed Shamsuzzoha Hall – শহীদ শামসুজ্জোহা হল </option>
                    <option value="Shaheed_Suhrawardy_Hall"> Shaheed Suhrawardy Hall – শহীদ সোহ্‌রাওয়ার্দী হল </option>
                    <option value="Shaheed_Ziaur_Rahman_Hall"> Shaheed Ziaur Rahman Hall – শহীদ জিয়াউর রহমান হল </option>
                    <option value="Sher-e_Bangla_Fazlul_Haque_Hall"> Sher-e Bangla Fazlul Haque Hall –  শের-ই-বাংলা ফজলুল হক হল </option>
                    <option value="Syed_Amer_Ali_Hall"> Syed Amer Ali Hall – সৈয়দ আমীর আলী হল </option>
                    <option value="Tapashi_Rabeya_Hall"> Tapashi Rabeya Hall – তাপসী রাবেয়া হল </option>
                </select>
            </div>
            <div class="form-group">
                <button class="border-0 btn-block block-main-btn btn btn-sm btn-success" type="submit"  id="hall_submit" name="hall_submit">Save</button>
            </div>
        
            </form>
         </div>
    </div>
<?php }} ?>