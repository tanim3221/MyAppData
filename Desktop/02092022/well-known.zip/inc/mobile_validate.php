<?php
function validate_mobile_number($mobile)
{
    // Allow +, - and . in mobile number
    $filtered_mobile_number = filter_var($mobile, FILTER_SANITIZE_NUMBER_INT);
    // Remove "-" from number
    //$mobile_to_check = str_replace("-", "", $filtered_mobile_number);
    $mobile_to_check = str_replace(array(' ', '-', '_', '+'), '', $filtered_mobile_number);
    // Check the lenght of number
    // This can be customized if you want mobile number from a specific country
    if (strlen($mobile_to_check) < 11 || strlen($mobile_to_check) > 11) {
        return false;
    } else {
        return true;
    }
}
