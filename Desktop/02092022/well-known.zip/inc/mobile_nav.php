   <div class="mobile_nav_wrapper">
   	<div class="mobile_nav_head">
   		<div class="mobile_nav_title">Title</div>
   		<div class="mobile_nav_close">
   			<i class="mdi mdi-close"></i>
   		</div>
   	</div>
   	<div class="mobile_nav_body">
	   <div class="spinner_log" style="display: none;">
			<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
		</div>
	  </div>
   </div>

<?php /*
   <div class="mobile_nav_wrapper_search">
   	<div class="mobile_nav_head">
   		<input type="text" name="search" placeholder="Search here..." id="search_nav_movile" class="mobile_nav_title_search">
   		<div class="mobile_nav_close">
   			<i class="mdi mdi-close"></i>
   		</div>
   	</div>
   	<div class="mobile_nav_body search">
   		<?php foreach ($search_data as $search_data) { ?>
   			<div class="history_view item_view_nav">
   				<div class="mobile_nav_content_icon">
   					<i class="mdi mdi-history"></i>
   				</div>
   				<div class="mobile_nav_content_middle" id="direct_key_search" data-key="<?= $search_data['keywords'] ?>" data-cat="<?= $search_data['key_cat'] ?>">
   					<div class="middle_title">
   						<?= $search_data['keywords'] ?>
   					</div>
   					<div class="middle_text_hints">
   						<?= $search_data['key_cat'] ?>
   					</div>
   				</div>
   				<div class="mobile_nav_content_icon_last" id="insert_pre_key" data-key="<?= $search_data['keywords'] ?>">
   					<i class="mdi mdi-arrow-top-left"></i>
   				</div>
   			</div>
   		<?php } ?>

   	</div>
   </div>
*/ ?>

<?php if ($detect->isMobile()){ ?>
	<div class="main_footer_mobile navbar fixed-bottom">
   	<nav class="mobile-bottom-nav">
   		<div class="search_nav mobile-bottom-nav__item home_mobile_button mobile-bottom-nav__item--active">
   			<div class="mobile-bottom-nav__item-content">
   				<i class="icon mdi mdi-account-search-outline"></i>
   				Search
   			</div>
   		</div>
   		<!-- <div class="gallery_nav mobile-bottom-nav__item category_view_mobile">
   			<div class="mobile-bottom-nav__item-content">
   				<i class="icon mdi mdi-camera-burst"></i>
   				Gallery
   			</div>
   		</div> -->

   		
   		<div class="document_nav mobile-bottom-nav__item cart_mobile_btn">
   			<div class="mobile-bottom-nav__item-content">
   				<i class="icon mdi mdi-file-document-multiple-outline"></i>
   				Document
   			</div>
   		</div>
		   <div class="explore_nav mobile-bottom-nav__item category_view_mobile">
   			<div class="mobile-bottom-nav__item-content">
   				<i class="icon mdi mdi-compass-outline"></i>
   				Explore
   			</div>
   		</div>
		   <div class="mobile-bottom-nav__item category_view_mobile" onclick="location.href='others.php?faq_view'">
   			<div class="mobile-bottom-nav__item-content">
   				<i class="icon mdi mdi-help-circle-outline"></i>
   				FAQs
   			</div>
   		</div>

   		<div class="more_nav mobile-bottom-nav__item notification_mobile_menu_btn">
   			<div class="mobile-bottom-nav__item-content">
   				<i class="icon mdi mdi-cube-outline"></i>
   				More
   			</div>
   		</div>
   	</nav>
   </div>
<?php } ?>
 