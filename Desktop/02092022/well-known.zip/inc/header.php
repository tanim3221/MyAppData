<?php
// header("Location: under_construction.php");
error_reporting(0);
session_start();
ini_set('display_errors', "off");
ini_set('display_startup_errors', 0);
date_default_timezone_set('Asia/Dhaka');
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);
// echo date_default_timezone_get();

$actual_link = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]";
define('BASE_URL', $actual_link.'/');
define('BASE_DIR', '/');
require_once __DIR__. '/../controller/conn.php';
require __DIR__.'/../inc/head.php';
require __DIR__.'/../inc/mobile_validate.php';
include __DIR__.'/../PHPMailer/PHPMailerAutoload.php';
require_once __DIR__.'/../controller/mobile_detect.php';
require_once __DIR__. '/../controller/data.php';
require_once __DIR__. '/../controller/others.php';
require_once __DIR__. '/../controller/mail.php';
require_once __DIR__. '/../controller/photo.php';
require_once __DIR__. '/../controller/file.php';
require_once __DIR__. '/../controller/notification.php';
$connPdo = $pdo->open();
$notification = new Notification();
$data = new Data();
$othersData = new Data();
$others = new Others();
$mailSend = new Mail();
$photoData = new Photo();
$filesData = new Files();
$detect = new Mobile_Detect();
$batch = $_SESSION['batch'];
$get_batch = isset($_GET['batch']) ?  $_GET['batch'] : '';
$get_session = isset($_GET['session']) ?  $_GET['session'] : '';

$visitorTotal = $data->visitTotal();
$visitToday = $data->visitToday();
// $birth_data = $others->getBirthdayDate();
// $birth_coming = $others->getUpcomingBirthdayDate();
// $course_year = $others->getCourseYear();

$search_data = $others->getSearchHistory($batch, $_SESSION['student_id']);
$batchData =$others->getBatch();
$batchDataAll =$others->getBatchAll(); //get only Batch Name
$AllStdInfo =$data->getAllBatch(); // get all student info of all batch
$getActivityLog =$others->getLog('activity_log', 'id DESC');
$getsearchLog =$others->getLog('search', 'id DESC');
$getNotice =$others->getLog('notice', 'id DESC');
$sqlvalue =$others->getLog('sqlvalue', 'id DESC');
$mega_menuAll =$others->getLog('mega_menu', 'id DESC');
$course_listAll =$others->getLog('course_list', 'course_code ASC');
$districtAll =$others->getLog('district', 'name ASC');
$BloodList =$others->getLog('blood', 'short_text ASC');
$hallNames =$others->getLog('hall', 'name_en ASC');
$faqView =$others->getLog('faq', 'id DESC');
$reportIssue =$others->getLog('report_issue', 'id DESC');
$title_text = $data->batchData('batch', $batch,'batch');
$megaMenu = $others->getMegaMenu();
$getAlbum = $photoData->getAlbum();
$getMaintenance = $others->getMaintenance();

if (isset($_GET['batch']) && $_GET['batch'] !== "all_batch") {
	$title_text_others = $data->batchData('batch', $get_batch, 'batch');
	$title_others = $title_text_others['title'];
} else {
	$title_text_others = "All Batch Info";
	$title_others = $title_text_others;
}


if ($_SESSION['student_id']) {
	$loggedin = $data->batchData($batch, $_SESSION['student_id'], 'student_id');
	require_once __DIR__ . '/../inc/check_hall.php';

	$loggedChecklist = json_decode($loggedin['checklist'],true);

	//Maintenance Mode
	$maintenance_status = $getMaintenance['status'];
	if (($maintenance_status == 1 && $loggedin['role'] !== 'dev')) {
		echo "<script>window.location.replace('maintenance.php')</script>";
	}
	//Maintenance Mode
}


$loggedinInfoInsert = array(
	'name' => $loggedin['name'],
	'batch' => $loggedin['batch'],
	'student_id' => $loggedin['student_id']
);



$title= $title_text['title'];

if (($loggedin['batch']==$_GET['batch']) && $_GET['batch'] !== "all_batch"){
	$titleCustomize = $title_text['title'];
} else if ($_GET['batch'] == "all_batch") {
	$titleCustomize = "All Batch Info";
} else {
	$titleCustomize = $title_text_others['title'];
}

if (isset($_POST['upload_gallery']) && isset($_SESSION['student_id'])) {	

	$in = $photoData->insertPhoto($_POST, $_FILES, $loggedinInfoInsert);
	if ($in ==1){
		$msg = "Image successfully uploaded.";
        echo "<script>window.setTimeout(function(){ window.location='index_gallery.php?my_view_gallery' }, 1000); </script>";
	} else {
		$error = "Something went wrong. Please try again later.";
	}
}
if (isset($_GET['batch'])  && $_GET['batch'] !== "all_batch") {
	if (($loggedin['role'] == 'admin') && isset($_GET['inactive_view']) && $loggedin['batch'] == $get_batch) {
		$count = $data->batchCount($get_batch, "WHERE active='0'");
	} else if (($loggedin['role'] == 'dev') && isset($_GET['inactive_view']) && $loggedin['batch'] == $get_batch) {
		$count = $data->batchCount($get_batch, "WHERE active='0'");
	} elseif (($loggedin['role'] == 'dev')) {
		$count = $data->batchCount($get_batch, "");
	} elseif (($loggedin['role'] == 'admin') && $loggedin['batch'] == $get_batch) {
		$count = $data->batchCount($get_batch, "WHERE active='1'");
	} else if ($loggedin['batch'] == $get_batch) {
		$count = $data->batchCount($get_batch, "WHERE active='1'");
	} else {
		$count = $data->batchCount($get_batch, "WHERE active='1' AND showing='1'");
	}

	$cnt = $count == 0 ? 0 : $count;
} else {
	$count= "";
}

?>
<div class="body_wrapper_custom">
	<div class="card loogedin_info_edit_top">
		<nav class="navbar navbar-expand-md navbar-dark ais_member_nav">
			<div class="pro">
				<?php
				//$class = $detect->isMobile() ? 'dropbtn_nav' : '';
				if (empty($loggedin['photo'])) { ?>
					<img onclick="myFunction()" class="dropbtn" data-name="<?= ucwords(strtolower($loggedin['name'])) ?>" src="ais-assets/icon/demo.png">
				<?php	} else { ?>
					<img onclick="myFunction()" data-name="<?= ucwords(strtolower($loggedin['name'])) ?>" class="dropbtn" src="image/<?= $loggedin['photo'] ?>">
				<?php	}    ?>
			</div>

			<h3 class="header_title"><?= $title ?></h3>

			<div id="notifications">
				<i class="mdi mdi-bell-ring-outline mdi-24px mdi-light"></i>
			</div>

			<div class="collapse navbar-collapse" id="collapsibleNavbar">
				<ul class="navbar-nav member-db ml-auto">
				<?php if (($loggedin['role'] == 'dev')) { ?>
						<li class="nav-item"><a class="nav-link" href="controller.php?only_for_controller">
								<i class="fas fa-code nav_icon"></i>
								<span class="nav_title text-warning">
									
								Controller
									</span></a></li>

					<?php }	?>
					
					<?php  if (($loggedin['student_id'] == '1510233221')) { ?>

									<li class="nav-item"><a class="nav-link" href="only-for-me.php">
								<i class="fas fa-code nav_icon"></i>
								<span class="nav_title text-warning">
									
								My Admin
									</span></a></li>
					<?php }	?>
					<li class="nav-item">
						<a class="nav-link" href="home.php">
							<i class="fas fa-search nav_icon"></i>
							<span class="nav_title">
							Home
							</span>
						</a>
					</li>
					
					<li class="nav-item">
						<a class="nav-link" href="#">
							<i class="fas fa-search nav_icon"></i>
							<span id="view_btn_stds" data-id="<?=$loggedin['id']?>" data-batch="<?=$loggedin['batch']?>" class="nav_title">
								My Profile
							</span>
						</a>
					</li>
					<?php if ($loggedin['frnds'] == '1') { ?>

						<li class="nav-item">
							<a class="nav-link" href="my_friends.php?only_my_friends">
								<i class="fas fa-heart nav_icon"></i>
								<span class="nav_title">
									My Friends</span>
							</a>
						</li>
					<?php } ?>
					
					<li class="nav-item">
						<a class="nav-link" href="#" data-student_id="<?=$loggedin['student_id']?>" id="activity_log_view">
							<i class="fas fa-history nav_icon"></i>
							<span class="nav_title">
							My Activity Log
							</span>
						</a>
					</li>

					<li class="nav-item dropdown has-megamenu">
						<a class="nav-link" href="#" id="dropdownMegaMenu">
							<i class="fas fa-globe nav_icon"></i>
							<span class="nav_title">Important Links</span>
						</a>
						<div class="dropdown-menu megamenu" id="megaMenuHolder" role="menu">
						<div class="spinner_log">
						<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
					</div>
						</div> 
					</li>


					<li class="nav-item dropdown">
						<a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
							<i class="fas fa-th nav_icon"></i>
							<span class="nav_title">More</span>
						</a>
						<div class="dropdown-menu gallery_more_menu">
							<a class="dropdown-item" href="#" id="course_view_title">
								<i class="fas fa-cake nav_icon"></i>
								<span class="nav_title">
									AIS Courses</span>
								</span>
							</a>
							<a class="dropdown-item" href="#" id="birthday_view_title">
								<i class="fas fa-cake nav_icon"></i>
								<span class="nav_title">
									Birthday</span>
								</span>
							</a>
							
							<a class="dropdown-item" href="learning.php?view_files_book&all_files">
								<i class="fas fa-file nav_icon"></i>
								<span class="nav_title">
								Documents</span>
								</span>
							</a>
							
							<?php if (($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')) { ?>
								<a class="dropdown-item" href="#" onclick="location.href='dataview.php?view_batch&inactive_view&batch=<?= $batch ?>&session=<?= $loggedin['session'] ?>'" id="addemail">
									<i class="fas fa-bug nav_icon"></i>
									<span class="nav_title">
										Inactive Info</span>
									</span>
								</a>
								<a class="dropdown-item" href="dataview.php?login_info_batch&batch=<?= $batch ?>">
									<i class="fas fa-bell nav_icon"></i>
									<span class="nav_title">Login Info</a>
									
									<a class="dropdown-item" href="dataview.php?see_all_notice&batch=<?= $batch ?>">
									<i class="fas fa-bell nav_icon"></i>
									<span class="nav_title">All Notice</a>

								<a class="dropdown-item" href="others.php?database_settings">
									<i class="fas fa-cog nav_icon"></i>
									<span class="nav_title">Settings</a>
							<?php } ?>
							<a class="dropdown-item" href="others.php?faq_view">
								<i class="fas fa-question-circle nav_icon"></i>
								<span class="nav_title">FAQs</a>
								
							<a class="dropdown-item" href="others.php?report_info">
								<i class="fas fa-exclamation-circle nav_icon"></i>
								<span class="nav_title">Report</a>
						</div>
					</li>
				</ul>
			</div>
		</nav>

		<div class="dropdown main_header">
			<div id="myDropdown" class="dropdown-content users_loggedin_info">
			<div class="spinner_log">
						<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
					</div>
			</div>
		</div>
		<div style="clear: both;"></div>


		<div class="public_btn">
			<?php
			/*
			if ($loggedin['showing'] == '1') { ?>
            <a href="dataview.php?private=true&id=<?= $loggedin['id'] ?>&batch=<?= $loggedin['batch'] ?>"
                class="btn btn-success btn-sm">Public</a>
            <?php } else { ?>
            <a href="dataview.php?public=true&id=<?= $loggedin['id'] ?>&batch=<?= $loggedin['batch'] ?>"
                class="btn btn-danger btn-sm">Private</a>
            <?php } 
			*/ ?>

			<?php if ((isset($_GET['my_batch']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev') && $loggedin['batch'] == $get_batch  || isset($_GET['other_batch_view']) && $loggedin['role'] == 'dev') && $_GET['batch'] !== "all_batch") { ?>
				<a href="download.php?download&batch=<?php echo $get_batch ?>" type="button" class="btn btn-primary btn-sm">Download</a>
			<?php } elseif (isset($_GET['view_teacher']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')) { ?>
				<a href="download.php?downloadTeacher" type="button" class="btn btn-primary btn-sm">Download Teachers</a>
			<?php } elseif (isset($_GET['view_office_stuff']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')) { ?>
				<a href="download.php?downloadStuff" type="button" class="btn btn-primary btn-sm">Download Stuff</a>
			<?php }?>
		</div>
		<div class="admin_notice_btn">

			<div class="dropdown">
				<button type="button" class="btn btn-primary btn-sm dropdown-toggle" data-toggle="dropdown">
					Add New
				</button>
				<div class="dropdown-menu">
					<?php if (($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')) { ?>
						<a class="dropdown-item" href="#"  id="addeMailFriends">Add Batch Friends</a>
						<a class="dropdown-item" href="#" id="addNewTeachers">Add Teachers</a>
						<a class="dropdown-item" href="#" id="addNewStaff">Add Office Stuff</a>
						<a class="dropdown-item" href="#" data-batch ="<?= $loggedin['batch'] ?>" id="myModalNotice">Add Notice</a>
					<?php } ?>
					<a class="dropdown-item" href="#" id="myModalFileUpload">Upload
						File</a>
					<!-- <a class="dropdown-item" href="#" id="myModalGallery">Upload Photo to gallery
					</a> -->
				</div>
			</div>
			
		</div>
		<!-- <div class="otherBtn">
		<button type="button" id="customize_view" class="btn btn-dark btn-sm">Customize View</button>
		</div> -->
		<div class="others_batch_btn">
			<div class="dropdown">
				<button type="button" id="explore_moreMenu" class="btn btn-success btn-sm">
					Explore
				</button>
			</div>
		</div>
		<?php 
		$url =basename($_SERVER['PHP_SELF']); 
		if ($url=='controller.php') {?>
		<div class="others_controller">
			<div class="dropdown">
				<span id="shortcut_menu">
					<i class="fas fa-bars"></i>
				</span>
			</div>
		</div>
		<?php } ?>

		<div class="card-body text-center loogedin_info_edit_title">
			<p class="card-text text-white text-uppercase text_title_loggedin">
				<?php
				if (isset($_GET['users_password_change'])) {
					echo "Update My Password";
				} elseif (isset($_GET['home_view_gallery'])) {
					echo "Gallery <br><small>" . (isset($_GET['album']) ? $_GET['album'] : '') . "</small>";
				} elseif (isset($_GET['update_files_info'])) {
					echo "UPDATE File <br><small>" . str_replace('-', ' ', $_GET['title']) . "</small";
				} elseif (isset($_GET['book_files_up'])) {
					echo "Add New File";
				} elseif (isset($_GET['view_files_book'])) {
					echo "Necessary Files";
				}elseif (isset($_GET['report_issue'])) {
					echo "Issued Report";
				}elseif (isset($_GET['backup-sql'])) {
					echo "SQL Backup";
				} elseif (isset($_GET['users_photo_change'])) {
					echo "Change My Photo";
				} else if (isset($_GET['view_teacher'])) {
					echo "Teachers Info";
				} else if (isset($_GET['view_office_stuff'])) {
					echo "Office Stuff Info";
				} elseif (isset($_GET['my_batch_update']) && isset($_GET['name'])) {
					echo str_replace('_', ' ', $_GET['name']);
				} elseif (isset($_GET['teachers_update'])) {
					echo str_replace('_', ' ', $_GET['name']);
				} elseif (isset($_GET['office_stuff_update'])) {
					echo str_replace('_', ' ', $_GET['name']);
				} elseif (isset($_GET['view_batch']) && isset($_GET['inactive_view'])) {
					echo "" . $title_others . " <br><small>Inactive Info</small><br><small>" . $loggedin['session'] . "</small>";
				} elseif (isset($_GET['view_batch']) && isset($_GET['my_batch'])) {
					echo "" . $title_others . " <br><small>My Batch</small><br><small>" . $loggedin['session'] . "</small>";
				} elseif (isset($_GET['view_batch']) && isset($_GET['other_batch_view'])) {
					echo "" . $title_others . " <br><small>Students Info</small><br><small>" . $get_session . "</small>";
				} elseif (isset($_GET['new_teachers_add'])) {
					echo 'Add New Teachers';
				} elseif (isset($_GET['admin_view_gallery'])) {
					echo "Gallery " . $title . "<br><small>Only for Admin</small>";
				} elseif (isset($_GET['faq_view'])) {
					echo "Frequently Asked Questions";
				} elseif (isset($_GET['only_my_friends'])) {
					echo "Friends Empire";
				} elseif (isset($_GET['my_view_gallery'])) {
					echo "My Gallery";
				} elseif (isset($_GET['database_settings'])) {
					echo "Database Settings";
				} elseif (isset($_GET['hall-names'])) {
					echo "Hall Names";
				} elseif (isset($_GET['see_all_notice'])) {
					echo "Notice<br><small>by<br>" . $title . "</small>";
				} elseif (isset($_GET['only_for_controller'])) {
					echo 'Controller';
				} elseif (isset($_GET['controller_view_update'])) {
					echo "" . $title_others . " <br><small>Controller may update info</small>";
				} elseif (isset($_GET['view_batch']) && isset($_GET['controller_view'])) {
					echo "" . $title_others . " <br><small>Controller View</small><br><small>" . $get_session . "</small>";
				} elseif (isset($_GET['report_info'])) {
					echo "Report Info <br> <small>Contact to your admin</small>";
				} elseif (isset($_GET['users_info_modify'])) {
					echo $loggedin['name'];
				} elseif (isset($_GET['sql-execute'])) {
					echo 'SQL Execute';
				} elseif (isset($_GET['faqs'])) {
					echo 'FAQs';
				} elseif (isset($_GET['login-info'])) {
					echo 'Login Info';
				} elseif (isset($_GET['admin-list'])) {
					echo 'Admin Info';
				} elseif (isset($_GET['important-link'])) {
					echo 'Important Links';
				} elseif (isset($_GET['files'])) {
					echo 'Files';
				} elseif (isset($_GET['notice'])) {
					echo 'Notice';
				} elseif (isset($_GET['district-values'])) {
					echo 'District values';
				} elseif (isset($_GET['blood-list'])) {
					echo 'Blood Groups';
				} elseif (isset($_GET['activity-log'])) {
					echo 'Activity Log';
				} elseif (isset($_GET['income-revenue-statement'])) {
					echo 'Income Revenue Statement';
				} elseif (isset($_GET['sys-email-setup'])) {
					echo 'System Email Setup';
				} elseif (isset($_GET['search-history'])) {
					echo 'Search History';
				} elseif (isset($_GET['login-credentials'])) {
					echo 'Login Credentials';
				} elseif (isset($_GET['gallery'])) {
					echo 'Gallery';
				} elseif (isset($_GET['ais-course'])) {
					echo "AIS Courses";
				} elseif (isset($_GET['login_info_batch'])) {
					echo "Login Info " . $title;
				} elseif (isset($_GET['update_info_batch'])) {
					echo  "Up to date Info " . $title;
				} elseif (isset($_GET['customize_data_view']) && isset($_GET['district']) && (!empty($_GET['district']))) {
					echo "" . $titleCustomize . " <br><small>" . $_GET['district'] . " District Only</small>";
				} elseif (isset($_GET['customize_data_view']) && isset($_GET['hall_code']) && (!empty($_GET['hall_code']))) {
					echo "" . $titleCustomize . " <br><small>" . 	$others->getHallName($_GET['hall_code']). "</small>";
				} elseif (isset($_GET['customize_data_view']) && isset($_GET['blood']) && (!empty($_GET['blood']))) {
					$blood = urlencode($_GET['blood']);
					$signBlood = ["+", "-"];
					$textBlood  = [" Positive", " Negetive"];
					$newBlood = str_replace($signBlood, $textBlood, $blood);

					echo "" . $titleCustomize . " <br><small>'" . $newBlood. "' Blood Only</small>";
				} else {
					echo "Hi, " . $loggedin['name'] . "<br><small>Welcome to " . $title . "<br>" . $loggedin['session'] . "</small>";
				}
				?>
			</p>
		</div>
		<?php if (isset($_GET['view_batch'])) { ?>
			<div class="count_student_batch">
				<span class="h1 text-white text-bold"> <?= $cnt ?></span>
			</div>

		<?php } ?>
	</div>
	
	<script>
		// $('.scroll_text').AcmeTicker({
		// 	type: 'marquee',
		// 	/*horizontal/horizontal/Marquee/type*/
		// 	direction: 'left',
		// 	/*up/down/left/right*/
		// 	speed: 0.05,
		// 	/*true/false/number*/
		// 	/*For vertical/horizontal 600*/
		// 	/*For marquee 0.05*/
		// 	/*For typewriter 50*/
		// 	controls: {
		// 		toggle: $('.acme-news-ticker-pause'),
		// 		/*Can be used for horizontal/horizontal/typewriter*/
		// 		/*not work for marquee*/
		// 	}
		// });
	</script>


	<?php 
	if ($detect->isMobile()) {
		$centerModal = "";
	} else {
		$centerModal = "modal-dialog-centered";
	}
	?>
	
	<div class="modal fade" id="myModalInfo" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog modal-lg  <?=$centerModal?>">
			<div class="modal-header view_std">
				<span style="cursor: pointer;" data-dismiss="modal"><i class="mdi mdi-close mdi-24px"></i></span>
			</div>
			<div class="modal-content ">
				<div id="web_content_info" class="modal-body">
					<div class="spinner_log">
						<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
					</div>
				</div>
				<div class="modal-footer qr_code" style="border-top:0">
					<button type="button" class="btn btn-danger btn-sm" data-dismiss="modal">Close</button>
				</div>
			</div>
		</div>
	</div>

	<div id="myModalLoginInfo" class="modal fade" tabindex="-1" aria-hidden="true" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog modal-dialog-scrollable <?=$centerModal?> modal-xl login_modal_view">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title modal_login_info_title">Loading...</h4>
					<!-- <div class="spinner_log">
						<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
					</div> -->
					<span style="cursor: pointer;" data-dismiss="modal"><i class="mdi mdi-close mdi-24px"></i></span>
				</div>
				<div class="modal-body" id='login_view_info'>
					<div class="spinner_log">
						<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
					</div>
				</div>

			</div>
		</div>
	</div>
	<!-- <div id="myModalActivityInfo" class="modal fade" role="dialog" data-backdrop="static" data-keyboard="false">
		<div class="modal-dialog modal-dialog-scrollable modal-lg">
			<div class="modal-content">
				<div class="modal-header">
					<h4 class="modal-title modal_activity_view_info">My Activity Log</h4>
					<span data-dismiss="modal"><i class="mdi mdi-close mdi-24px"></i></span>
				</div>
				<div class="modal-body" id='activity_view_info'>
					<div class="spinner_log">
						<i class="mdi mdi-36px mdi-spin mdi-loading"></i>
					</div>
				</div>
			</div>
		</div>
	</div> -->
