<?php
// require 'connect.php';
// require 'functions.php';

// $birth_data = getBirthdayDate();
// $courseYear = getCourseYear();
// $year = '1st Year';
// $cnt =1;
// /*
// foreach ($birth_data as $birth_data) {
//     $std = substr($birth_data['student_id'], 2, 3);
//     echo $cnt.' - ';
//     echo $birth_data['birth'].' ';
//     echo $birth_data['name'].'<br>';
//     echo $std.'<br>';
//     $student_id = $birth_data['student_id'];
//     $hall_chk = getHallName($student_id);
//     echo $hall_chk;
//     $cnt = $cnt+1;
// }
// */


// if(sizeof($birth_data)==0){
//     echo 'its empty';
// } else {
//     echo 'not empty';
// }
// $course = 'ggggg ** yyyyy';
// $course = explode('**', $course);
// echo  $course[1];
// 	foreach($course as $course){
//         $course_name = $course;
//         echo $course_name;
// 	}

//     $fb_id ='https://www.facebook.com/profile.php?id=100009531963344';
//     $facebook_url = get_facebook_url($fb_id);

//     echo $facebook_url ;
/*
$cnt =1;
foreach ($courseYear as $courseYear) {
    echo $cnt.' - ';
    echo $courseYear['year'].'<br>';
    $cnt = $cnt+1;
}
*/


/*
$fb_id = '';
if (strpos($_SERVER['REQUEST_URI'], "car") !== false){

}
if (url.startsWith("https://web.facebook.com") || url.startsWith("https://www.facebook.com") || url.startsWith("https://m.me") || url.startsWith("https://facebook.com") || url.startsWith("https://m.facebook.com") || url.startsWith("https://mobile.facebook.com") || url.startsWith("fb:")) {
    String urlReplace = url;
    String url_view;
    urlReplace = urlReplace.replaceAll("https://facebook.com/|https://m.facebook.com/|https://www.facebook.com/|https://mobile.facebook.com/|https://www.facebook.com/profile.php?id=|https://m.facebook.com/profile.php?id=|https://web.facebook.com/profile.php?id=|https://web.facebook.com/|https://m.me/", "");

    if (url.startsWith("https://m.me")) {
        url_view = "https://m.me/" + urlReplace;
    } else {
        url_view = "fb://facewebmodal/f?href=https://www.facebook.com/" + urlReplace;
    }

}

$message = 'This domain.com has strpos';
$links = array('domain.com', 'do.main');
$safe = array();
foreach($links as $key=>$result){
    if(strpos($message, $result) != false){
      $safe[$result] = "String is available";   
    } else{
      $safe[$result] = "String is not available";       
    }

}
print_r($safe);


// $phrase  = "You should eat fruits, vegetables, and fiber every day.";
// $healthy = ["fruits", "vegetables", "fiber"];
// $yummy   = ["pizza", "beer", "ice cream"];

// $newPhrase = str_replace($healthy, $yummy, $phrase);

// echo $newPhrase;*/

require __DIR__ . '/../controller/conn.php';

$connPdo = $pdo->open();

$sql = "Select * from 19th Order by name";
$stmtss = $connPdo->prepare($sql);
$stmtss->execute();
$numRows = $stmtss->rowCount();


// $resultss = $stmtss->fetchAll();
// $numRows = count($resultss);
// $row = $stmt->fetch();
echo $numRows ."<br>";  
foreach ($stmtss as $row){
  echo $row ['name']."<br>";  
}
