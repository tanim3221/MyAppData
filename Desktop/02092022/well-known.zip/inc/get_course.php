<?php 
  require __DIR__. '/../controller/conn.php';
  $connPdo = $pdo->open();
  $output = '';
  
if(isset($_GET['year'])){
	$year = $_GET['year'];
}
  $sql = "SELECT * FROM course_list WHERE year= '".$year."' ORDER by course_code ASC";
  $stmt = $connPdo->prepare($sql);
  $stmt->execute();
  foreach ($stmt as $row) {
      $output .= '			
      <div class="course_more_view_year course_info_view item_view_nav" data-year="'.$row['year'].'"  data-coursename="'.$row['course_name'].'" id="course_view_list">	
      <div class="mobile_nav_content_icon">
      <i class="mdi mdi-book-open-page-variant"></i>
  </div>
  <div class="mobile_nav_content_middle">
      <div class="middle_title">
          '.$row['course_name'].' ('.$row['course_code'].')
      </div>
      <div class="middle_text_hints">
      '.$row['year'].' ('.$row['semester'].')
      </div>
  </div>
  <div class="mobile_nav_content_icon_last">
      <i class="mdi mdi-chevron-right"></i>
  </div></div>';
  }  
  echo  $output;
  $connPdo = null;

?>