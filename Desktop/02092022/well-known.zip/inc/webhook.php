<?php
include('connect.php');	
/* validate verify token needed for setting up web hook */ 
if (isset($_GET['hub_verify_token'])) { 
    if ($_GET['hub_verify_token'] === '43876RGFIEWUYTWEEIHDIUDSGFYUT') {
        echo $_GET['hub_challenge'];
        return;
    } else {
        echo 'Invalid Verify Token';
        return;
    }
}

/* receive and send messages */
$input = json_decode(file_get_contents('php://input'), true);
if (isset($input['entry'][0]['messaging'][0]['sender']['id'])) {

    $sender = $input['entry'][0]['messaging'][0]['sender']['id']; //sender facebook id
    $message = $input['entry'][0]['messaging'][0]['message']['text']; //text that user sent

    $url = 'https://graph.facebook.com/v2.6/me/messages?access_token=EAANnsr5MkqgBAPlcsRH0JpXsmQlEZAItyNYzcnhqwZBfCSILLM7HD1YpT2bKu2SZAK5ExygJ1uTahZADIFELRmuYrnXpZASxNTaUrD6eZAZA1i4MIxA6TRWNfAPcN8iZA6dVzRz3z62MM96rdnU0YZCICmZCy2ZBybtXBwqdgdoPqAQZAXK1d24tJgIF';

    /*initialize curl*/
    $ch = curl_init($url);
	
	$name='';
	/*
	$searchTerms = explode(' ', $message);
	$searchTermBits = array();
	foreach ($searchTerms as $term) {
		$term = trim($term);
		if (!empty($term)) {
				$searchTermBits[] = "Name LIKE '%{$term}%'";
			}
		}
	$searchSys= implode(' OR ', $searchTermBits);
	*/
	$sql = "SELECT * FROM 19th WHERE name LIKE '%{$message}%'";
    $stmt = $connPdo->prepare($sql);
	$stmt->execute();
	foreach ($stmt as $row) {
		$name .=$row['name']." (".$row['student_id']."),";
	}
	
    /*prepare response*/
    $jsonData = '{
    "recipient":{
        "id":"' . $sender . '"
        },
        "message":{
            "text":"Search Results:  ' . $name . '"
        }
    }';
    /* curl setting to send a json post data */
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
    curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
    if (!empty($message)) {
        $result = curl_exec($ch); // user will get the message
    }
    $connPdo = null;
}

?>