<!--
<button onclick="topFunction()" id="myBtn" title="Go to top"><i class="fas fa-arrow-up"></i></button>
-->
<div class="footer-bottom">
    <div class="row">
        <div class="col-md-4" id="browser" style="text-align:left">
            <span class="copyright"> ইচ্ছে &copy; <?php echo date("Y"); ?></span>
        </div>

        <div class="col-md-4" id="middle-text" style="text-align:center;">
            <span class="visitor_count">
                <span class="today_visitor_count text-bold mr-3"><i class="fas fa-calendar-day mr-2"></i>Visits Today: <?= $visitToday['nth_now'] ?> </span>
                <span class="total_visitor_count text-bold"><i class="fas fa-calculator mr-2"></i>Total Visitors: <?= $visitorTotal['nth_t'] ?> </span>
            </span>
        </div>

        <div class="col-md-4" id="name-pro" style="text-align:right;">
            Design & Developed by &nbsp;<a href="https://www.linkedin.com/in/saklayen"> Saklayen Ahmed</a>
        </div>

    </div>

</div>
<?php
include 'mobile_nav.php';
$connPdo = null;
?>
</div>