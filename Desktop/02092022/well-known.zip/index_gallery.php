<?php
error_reporting(0);
session_start();
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

if (isset($_SESSION['student_id'])) {
    require __DIR__ . '/inc/header.php';
    $batch = $_SESSION['batch'];


    if (isset($_GET['del_img'])) {
        if (isset($_GET['image_id'])) {
            $sql = "SELECT * FROM gallery WHERE image_id =" . $_GET['image_id'];
            $stmt1 = $connPdo->prepare($sql);
            $stmt1->execute();
            $row = $stmt1->fetch();
        }

        $role = $loggedin['role'];
        if (isset($_SESSION['student_id'])) {
            if ($row['student_id'] == $loggedin['student_id'] || ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')) {
                if (isset($_GET['image_id'])) {
                    $delete = 'files/' . $row['image_name'];
                    unlink($delete);
                    $del = "DELETE FROM gallery WHERE image_id=" . $_GET['image_id'];
                    $stmt1 = $connPdo->prepare($del);
                    if ($stmt1->execute()) {
                        $msg = "Photo deleted successfully";
                        if (isset($_GET['controller-view'])) {
                            echo "<script>window.setTimeout(function(){ window.location='controller.php?batch_login_info_gallery=" . $_GET['batch'] . "';}, 2000); </script>";
                        } else {
                            echo "<script>window.setTimeout(function(){ window.location='index_gallery.php?my_view_gallery';}, 2000); </script>";
                        }
                    } else {
                        $error = "Something went wrong. Please try again later.";
                    }
                } else {
                    $error = "Something went wrong. Please try again later.";
                }
            } else {
                header('Location: home.php');
            }
        } else {
            header('Location: index.php');
        }
        $connPdo = null;
    }


    if ((isset($_POST['my_view_gallery']) || isset($_POST['admin_view_gallery']) || (isset($_POST['controller-view']) && $loggedin['role'] == 'dev')) && isset($_GET['update'])) {
        $image_date = $_POST['image_date'];
        $image_place = $_POST['image_place'];
        $hide = $_POST['hide'];
        $album = $_POST['album'];
        $album = empty($_POST['album']) ? $_POST['album_new'] : (empty($_POST['album_new']) ? $_POST['album'] : ($_POST['album'] !== $_POST['album_new'] ? $_POST['album_new'] : $_POST['album']));
 
        $pinned = $_POST['pinned'];
        $image_description = $_POST['image_description'];

        $sql = "SELECT * FROM gallery WHERE image_id =" . $_GET['image_id'];
        $stmt1 = $connPdo->prepare($sql);
        $stmt1->execute();
        $row = $stmt1->fetch();

        $upload = "UPDATE gallery SET image_date='$image_date', album='$album', image_place='$image_place', hide='$hide', pinned='$pinned', image_description='$image_description' WHERE image_id=" . $_GET['image_id'];
        $stmt1 = $connPdo->prepare($upload);
        if ($stmt1->execute()) {
            $msg = "Image details updated successfully.";
            if (isset($_POST['controller-view'])) {
                // controller.php?gallery=controller-view&batch_login_info_gallery=20th
                echo "<script>window.setTimeout(function(){ window.location='controller.php?gallery=controller-view&batch_login_info_gallery=" . $row['batch'] . "';}, 2000); </script>";
            } elseif (isset($_POST['my_view_gallery'])) {
                echo "<script>window.setTimeout(function(){ window.location='index_gallery.php?my_view_gallery' }, 2000); </script>";
            } elseif (isset($_POST['admin_view_gallery'])) {
                echo "<script>window.setTimeout(function(){ window.location='index_gallery.php?admin_view_gallery' }, 2000); </script>";
            } else {
                echo "<script>window.setTimeout(function(){ window.location='index_gallery.php?my_view_gallery' }, 2000); </script>";
            }
        } else {
            $error = "Something went wrong. Please try again later.";
        }

        $connPdo = null;
    }

?>
    <link href="ais-assets/css/index.min.css" rel="stylesheet">
    <link rel="stylesheet" href="ais-assets/css/lc_lightbox.min.css" />
    <link rel="stylesheet" href="ais-assets/css/minimal.min.css" />
    <div class="container ais_family">
        <?php
        if (isset($_GET['home_view_gallery'])) {
            echo "<a class='album_name' href='index_gallery.php?home_view_gallery'> All Photo</a>";
            $sql = "SELECT DISTINCT(album) FROM gallery WHERE album != '' AND batch='".$loggedin['batch']."' ORDER BY album";
            $stmt = $connPdo->prepare($sql);
            $stmt->execute();
            foreach ($stmt as $rowa) {
                echo "<a class='album_name ml-2' href='index_gallery.php?home_view_gallery&album=" . $rowa['album'] . "'> " . $rowa['album'] . "</a>";
            }
            if (isset($_GET['album'])) {
                $album_view  = " AND gallery.album='" . $_GET['album'] . "'";
                $contain = "container";
            } else {
                $contain ="";
            }

            if ($detect->isMobile()) {
                include 'mobile_gallery.php';
            } else {
                include 'desktop_gallery.php';
            }
        } elseif (isset($_GET['admin_view_gallery']) && ($loggedin['role'] == 'admin' || $loggedin['role'] == 'dev')) { ?>
            <div class="admin_gallery_view container">
                <table id='ais_family_gallery' class='table' style='width:100%'>
                    <thead>
                        <tr>
                            <th>Photo</th>
                            <th>Image capture place</th>
                            <th width="110">Image capture date</th>
                            <th>Image caption</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                </table>
            </div>
        <?php } elseif (isset($_GET['my_view_gallery'])) { ?>
            <div class="my_gallery_view container">
                <table id='ais_family_gallery' class='table' style='width:100%'>
                    <thead>
                        <tr>
                            <th>
                                Photo
                            </th>
                            <th>
                                Image capture place
                            </th>
                            <th>
                                Image capture date
                            </th>
                            <th>
                                Image caption
                            </th>
                            <th>
                                Action
                            </th>
                        </tr>
                    </thead>
                   
                </table>
            </div>
    </div>


<?php     } else {
    echo "<script>window.location='index_gallery.php?my_view_gallery'; </script>";

} ?>
<script src="ais-assets/js/lc_lightbox.lite.min.js" type="text/javascript"></script>
<script src="ais-assets/js/alloy_finger.min.js" type="text/javascript"></script>
<script src="ais-assets/js/pagShrink.min.js"></script>

<script>
	function getUrlVars() {
		var vars = [],
			hash;
		var hashes = window.location.href.slice(window.location.href.indexOf('?') + 1).split('&');
		for (var i = 0; i < hashes.length; i++) {
			hash = hashes[i].split('=');
			vars.push(hash[0]);
			vars[hash[0]] = hash[1];
		}
		return vars;
	}

	$(document).ready(function() {
		var urlParam = getUrlVars()[0];
        var dTable = "gallery";
        var urlBatch = "<?=$loggedin['batch']?>";
		$('#ais_family_gallery').DataTable({
			"processing": true,
			"serverSide": true,
			'ajax': {
				'type': 'POST',
				'url': 'controller/loadData_gallery.php',
				'data': {
					'dTable': dTable,
					'urlParam': urlParam,
					'urlBatch': urlBatch
				}
			},
			"lengthMenu": [
				[10, 20, 30, 50, 100, 200, 300, 500, 1000000],
				[10, 20, 30, 50, 100, 200, 300, 500,"All Logs"]
			],
			"order": [
				[0, "desc"]
			],

			'columns': [{
					data: 'image_name'
				},
				{
					data: 'image_place'
				},
				{
					data: 'image_date'
				},
				{
					data: 'image_description'
				},
				{
					data: 'action'
				}
			],
			"createdRow": function(row, data, index) {
				$('td', row).eq(0).attr('data-label', 'Image');
				$('td', row).eq(1).attr('data-label', 'Image Place');
				$('td', row).eq(2).attr('data-label', 'Image Date');
				$('td', row).eq(3).attr('data-label', 'Image Details');
				$('td', row).eq(4).attr('data-label', 'Action');
			}
		});
	});
</script>

</div>

<?php
    include 'inc/footer.php';
?>
<?php if ($error) { ?>
    <script>
        toastr.error('<?php echo htmlentities($error); ?>');
    </script>
<?php } else if ($msg) { ?>
    <script>
        toastr.success('<?php echo htmlentities($msg); ?>');
    </script>
<?php } ?>

<?php } else {
    echo "<script>window.location='index.php'; </script>";
} ?>