// ⟁ \\

//All of code done in HTML and CSS(SCSS).

//Code by ARiyou2000