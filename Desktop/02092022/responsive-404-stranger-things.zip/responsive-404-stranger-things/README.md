# Responsive 404 Stranger things

A Pen created on CodePen.io. Original URL: [https://codepen.io/ARiyou2000/pen/VwvMeae](https://codepen.io/ARiyou2000/pen/VwvMeae).

I know there are a ton of Stranger Things 404 pages out there, but none of them looked right to me!

here a nice looking page with RESPONSIVE display.