# Blue Screen of Death (Windows 95 Version)

A Pen created on CodePen.io. Original URL: [https://codepen.io/ark3tek/pen/EBwpyW](https://codepen.io/ark3tek/pen/EBwpyW).

A blue screen of death with a little additional filtering :)