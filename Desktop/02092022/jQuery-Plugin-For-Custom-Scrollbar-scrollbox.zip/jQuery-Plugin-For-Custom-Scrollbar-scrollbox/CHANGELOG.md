# [v4.0.0](https://github.com/Invis1ble/scrollbox/compare/v3.0.1...v4.0.0)

### Features

* Added table of contents to README.
* Created CHANGELOG.

### Bug Fixes

* Fixed error in IE 7-8.

### Breaking changes from v3

* Default settings are now available via `$.fn.scrollbox.Constructor.getDefault()` instead of `$.fn.scrollbox.Constructor.Default`.
