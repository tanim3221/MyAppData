# CSS Train 404 Page

A Pen created on CodePen.io. Original URL: [https://codepen.io/ckroll17/pen/MzWgLo](https://codepen.io/ckroll17/pen/MzWgLo).

SVG 404 error page CSS only.