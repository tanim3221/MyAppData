#### 0.1.3 - 22 January 2016
* Added affiliate ID filter.

#### 0.1.2 - 22 January 2016
* Cleaned up recommended plugins.
* Fixed duplicated SiteOrigin menu items.

#### 0.1.1 - 22 January 2016
* Added WooCommerce to recommended plugins.

#### 0.1 - 20 January 2016
* Initial plugin release
