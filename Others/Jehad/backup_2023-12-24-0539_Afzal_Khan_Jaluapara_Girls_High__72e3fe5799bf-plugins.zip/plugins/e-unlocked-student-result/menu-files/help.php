<?php
DEFINED('ABSPATH') or die("You can't access this file.");

?>
<div class=" span12 alert alert-info" style="margin-top:20px;">
<h2>Help & Guide</h2>
<hr/>
<h4><strong>E-Unlocked : Student Result</strong></h4> <br/>To Create a Marksheet, just follow the following Steps : <br/><br/>
Step 1 : Add Class <br/>
Step 2 : Add subject to the class added in step 1 <br/>
Step 3 : Add Student <br/>
Step 4 : Add Marks<br/>
Step 5 : Paste Shortcode in the Post or Page to let students search by Roll Number and Class<br/>
Shortcode : [eusr_show_result]<br/>
Step 6 : Select Full Width Template option while Publishing Post/Page from the right side corner options. See the image below.<br/><br/>
<center><img  src="<?php echo plugins_url('/e-unlocked-student-result/images/pagewidth.png');?>"></center><br/>
<strong id="premium">*NOTE :</strong> You may see some <strong>error</strong> at the time of publishing your page/post with the shortcode. But don't worry just go to All Pages/Posts and you will be able to see your page/post.
<hr/>
<strong>Regarding Support : </strong><br/><br/>
In case of any support : <br/>
1. You can send us mail at <strong><em>business.purna@gmail.com</em></strong><br/>
2. Or You can Simply contact us if you want any more features at the same email id.<br/>
3. To support our work, <em><b><a style="text-decoration:underline;" target="_blank" href="https://www.paypal.com/paypalme/purnaps34834">Donate here</a></b></em>
<br/><br/>
<strong id="import">How to Import CSV Records? : </strong>  
<br/><br/>
1) First of all Download the CSV Format from Add Student Page<br/>
2) After Adding Classes and Subjects, Go to Subject Information area on Dashboard Page<br/>
3) Now note down the Class Id and Subject Id provided on the Class and Subject Field as these Ids are very important for adding data through CSV<br/>
4) In the CSV file, there is a column named Class Id and many columns named Subject & Mark<br/>
For example, suppose I add a class and the class Id is 2 . And I also added two subjects in that class and the subjects' ids are 3 & 4 . So the Subject ids(3 & 4) are under Class id(2).<br/>
5) Now Follow the Image Below.<br/>
6) <strong>Note : </strong>The Gender field can only be capital 'MALE' , 'FEMALE' or 'OTHERS' .<br/>
7) In this way you can add upto 10 Subjects per Student/Class.<br/><br/>
<img width="100%" src="<?php echo plugins_url('/e-unlocked-student-result/images/subjectinfo.jpg');?>"><br/><br/>
Don't worry it's very easy. For any support, feel free to contact me.
</div>
