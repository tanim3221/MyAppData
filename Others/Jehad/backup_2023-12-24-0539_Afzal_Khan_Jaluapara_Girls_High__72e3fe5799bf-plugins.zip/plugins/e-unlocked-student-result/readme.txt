=== E Unlocked - Student Result ===
Contributors: Purna Chandra Sarkar
Tags: student result, wordpress student result , wordrepss result plugin , wordpress student ,academic, academic result, student, student result, student result management system, result management system, education, result system, create marksheet online, online marksheet, online marksheet creator, result, easy student result,e unlocked, school, college, university, school result, college result, university result, create marksheet online, emarksheet , wordpress database , student result, student, result, result management system,  academic, academic result, university, education, student result management system, employee, university, education, result, result system, student, academic, employee entry, database, employee management system
Requires at least: 4.1
Tested up to: 5.7
Stable tag: 1.0.4
License: licensed under “GPLv2 or later”

This is a plugin specially made for showing results with a marksheet, add students using CSV, Full Customizable.

== Description ==

This is a plugin specially made for showing results with a marksheet, add students using CSV, Full Customizable. You can easily add , update and delete student result and some more stuff.

1) Some Important Features : Students or Admin can print result or save it as pdf if they want with just one click.
2) You can customize full marksheet. You have the option to hide any field if you want to or rename it.

To Create a Marksheet, just follow the following Steps :

Step 1 : Add Class
Step 2 : Add subject to the class added in step 1
Step 3 : Add Student
Step 4 : Add Marks
Step 5 : Paste Shortcode in the Post or Page to let students search by Roll Number and Class

Shortcode : [eusr_show_result]

== Installation ==

Simple instructions, instant!

- Log on to your wp-admin
- Click "Plugins", then "Add New"
- Type in „E-Unlocked-Student-Result” and click "Search Plugins"
- Download and install the Plugin
- Click on the "Activate Plugin" button

You will find 'EU Student Result' menu in your WordPress icon in the left hand menu in admin panel.

or

1. Upload the entire `e-unlocked-student-result` zip file to the `/wp-content/plugins/` directory.
2. Unzip the Zip file by Right Click on it and Click 'Extract' and type a '/'(slash) after 'Plugins' to the window box.
3. Activate the plugin through the 'Plugins' menu in WordPress.

== Screenshots ==
1. Frontend Marksheet
2. Dashboard
3. Add Class
4. Add Subject
5. Add Student
6. Import Records Using CSV
7. Add Marks
8. Setting for the school
9. See All Students
10. Edit Marksheet Fields


== Frequently Asked Questions ==
Question : Can I edit/hide marksheet fields?<br>
Ans: Yes, you can edit or rename them by going to the settings page and 'Edit Marksheet Fields' option. You can also hide them if you want so.

Question : Can I print marksheet?<br>
Ans: Yes, you can. There is an option below the marksheet in marksheet page to Print Result or you can save it as Pdf.

Question : Can I use this plugin to show Employee Performance?<br>
Ans: Yes, you can. As I mentioned you can customize any thing you want with the marksheet fields, you just have to rename the fields according to your need.

 == Changelog ==
 1.0.0 This is first version of this plugin.
 1.0.1 Some minor bug fixes.
 1.0.2 Added Watermark Feature, Added a new style frontent result.
 1.0.3 Fixed some bugs.
 1.0.4 Added Csv Import Feature, Added Export Csv Feature, Added option to add remark for each students, fixed some bugs.
 
 == Upgrade Notice ==
 will have more features soon.